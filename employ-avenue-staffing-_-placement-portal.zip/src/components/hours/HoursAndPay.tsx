import React, { useState } from 'react';
import { useWorkforce } from '../../context/WorkforceContext';
import {
  Clock,
  DollarSign,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  FileText,
  Upload,
  ArrowRight,
  ShieldAlert,
  HelpCircle,
} from 'lucide-react';

export const HoursAndPay: React.FC = () => {
  const { hours, assignment, disputes, flagHoursDispute } = useWorkforce();
  const [disputeModalOpen, setDisputeModalOpen] = useState(false);
  const [selectedEntryId, setSelectedEntryId] = useState<string>(hours[0]?.id || '');
  const [reportedHours, setReportedHours] = useState<number>(8.0);
  const [expectedHours, setExpectedHours] = useState<number>(8.5);
  const [reason, setReason] = useState<string>('');
  const [disputeSuccess, setDisputeSuccess] = useState(false);

  const hourlyRate = assignment?.hourlyRate || 23.5;

  const totalSubmitted = hours.reduce((acc, h) => acc + h.hoursSubmitted, 0);
  const totalApproved = hours.reduce((acc, h) => acc + h.hoursApproved, 0);
  const expectedGrossPay = totalApproved * hourlyRate;

  const handleDisputeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const entry = hours.find((h) => h.id === selectedEntryId);
    if (!entry) return;

    flagHoursDispute({
      entryId: entry.id,
      date: entry.date,
      siteName: entry.site,
      reportedHours,
      expectedHours,
      reason,
      supervisorNotes: 'Pending review by payroll audit desk.',
    });

    setDisputeSuccess(true);
    setTimeout(() => {
      setDisputeSuccess(false);
      setDisputeModalOpen(false);
      setReason('');
    }, 1500);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner: Pay period & Next Payday */}
      <div className="bg-[#0E2652] border border-[#1E4383] rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span className="text-xs font-poppins text-[#C9A227] uppercase tracking-widest font-bold">
              Timesheet & Payroll Ledger
            </span>
            <h2 className="text-2xl font-horizon font-bold text-white tracking-wider">
              My Hours & Pay Summary
            </h2>
            <p className="mt-1 text-xs font-oswald text-white/70">
              Work Week: Monday, Oct 26 – Sunday, Nov 1, 2026
            </p>
          </div>

          {/* Next Payday Callout */}
          <div className="bg-[#06132B] px-5 py-3 rounded-xl border border-[#C9A227]/50 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#C9A227]/20 border border-[#C9A227] flex items-center justify-center text-[#C9A227]">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-oswald uppercase text-white/60 block">
                Next Scheduled Payday
              </span>
              <p className="font-poppins font-bold text-sm text-white">Friday, Nov 6, 2026</p>
              <p className="text-[11px] font-oswald text-emerald-400">Direct Deposit Authorized</p>
            </div>
          </div>
        </div>

        {/* Totals Metric Strip */}
        <div className="mt-6 pt-5 border-t border-[#1E4383] grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-[#06132B] p-4 rounded-xl border border-[#1E4383]">
            <span className="text-[11px] font-oswald text-white/60 uppercase block">
              Hours Submitted
            </span>
            <span className="font-horizon text-2xl font-bold text-white">
              {totalSubmitted.toFixed(1)}{' '}
              <span className="text-xs font-oswald text-white/60">hrs</span>
            </span>
          </div>

          <div className="bg-[#06132B] p-4 rounded-xl border border-[#1E4383]">
            <span className="text-[11px] font-oswald text-white/60 uppercase block">
              Hours Approved
            </span>
            <span className="font-horizon text-2xl font-bold text-emerald-400">
              {totalApproved.toFixed(1)}{' '}
              <span className="text-xs font-oswald text-white/60">hrs</span>
            </span>
          </div>

          <div className="bg-[#06132B] p-4 rounded-xl border border-[#C9A227]/40">
            <span className="text-[11px] font-oswald text-white/60 uppercase block">
              Expected Gross Pay (Base: ${hourlyRate.toFixed(2)}/hr)
            </span>
            <span className="font-horizon text-2xl font-bold text-[#C9A227]">
              ${expectedGrossPay.toFixed(2)}
            </span>
          </div>
        </div>
      </div>

      {/* Week's Table & Dispute Action */}
      <div className="bg-[#0E2652] border border-[#1E4383] rounded-2xl shadow-xl overflow-hidden">
        <div className="p-5 border-b border-[#1E4383] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-[#06132B]/80">
          <div>
            <h3 className="font-poppins font-bold text-base text-white">
              Daily Breakdown: Current Week
            </h3>
            <p className="font-oswald text-xs text-white/60">
              Recorded via punch turnstiles and RF mobile timecards.
            </p>
          </div>

          {/* FLAG A PROBLEM BUTTON */}
          <button
            onClick={() => setDisputeModalOpen(true)}
            className="px-4 py-2 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/40 text-rose-300 font-oswald font-bold text-xs uppercase tracking-wider transition flex items-center gap-1.5 shadow"
          >
            <AlertTriangle className="w-4 h-4 text-rose-400" />
            <span>Flag A Problem With My Hours</span>
          </button>
        </div>

        {/* Responsive Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left font-oswald">
            <thead className="bg-[#06132B] text-white/70 uppercase text-xs border-b border-[#1E4383]">
              <tr>
                <th className="px-5 py-3 font-semibold">Day & Date</th>
                <th className="px-5 py-3 font-semibold">Client Site</th>
                <th className="px-5 py-3 font-semibold">Shift Times</th>
                <th className="px-5 py-3 font-semibold">Punch In / Out</th>
                <th className="px-5 py-3 font-semibold text-right">Submitted</th>
                <th className="px-5 py-3 font-semibold text-right">Approved</th>
                <th className="px-5 py-3 font-semibold text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1E4383]/60 text-xs">
              {hours.map((entry) => (
                <tr key={entry.id} className="hover:bg-[#13336E]/40 transition">
                  <td className="px-5 py-3.5 whitespace-nowrap">
                    <span className="font-poppins font-bold text-white block">
                      {entry.dayOfWeek}
                    </span>
                    <span className="text-white/60 text-[11px]">{entry.date}</span>
                  </td>
                  <td className="px-5 py-3.5 text-white/90 font-medium">{entry.site}</td>
                  <td className="px-5 py-3.5 text-white/70">{entry.shiftName}</td>
                  <td className="px-5 py-3.5 text-white/80 whitespace-nowrap">
                    {entry.clockIn} – {entry.clockOut}
                  </td>
                  <td className="px-5 py-3.5 text-right font-semibold text-white">
                    {entry.hoursSubmitted.toFixed(1)} hrs
                  </td>
                  <td className="px-5 py-3.5 text-right font-semibold text-emerald-400">
                    {entry.hoursApproved.toFixed(1)} hrs
                  </td>
                  <td className="px-5 py-3.5 text-center">
                    {entry.status === 'Approved' && (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-semibold border border-emerald-500/30">
                        <CheckCircle2 className="w-3 h-3" />
                        <span>Approved</span>
                      </span>
                    )}
                    {entry.status === 'Pending Review' && (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/30">
                        <span>Pending Review</span>
                      </span>
                    )}
                    {entry.status === 'Disputed' && (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 font-semibold border border-rose-500/30">
                        <AlertTriangle className="w-3 h-3" />
                        <span>Dispute Open</span>
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* DISPUTES SECTION IF ANY */}
      {disputes.length > 0 && (
        <div className="bg-[#0E2652] border border-rose-500/30 rounded-2xl p-5 shadow-lg space-y-3">
          <div className="flex items-center gap-2 text-rose-400">
            <AlertTriangle className="w-5 h-5" />
            <h3 className="font-poppins font-bold text-sm text-white">
              Active Hours Disputes Under Investigation ({disputes.length})
            </h3>
          </div>
          <div className="space-y-2">
            {disputes.map((disp) => (
              <div
                key={disp.id}
                className="p-3 bg-[#06132B] rounded-xl border border-[#1E4383] text-xs font-oswald flex flex-col sm:flex-row justify-between gap-3"
              >
                <div>
                  <span className="text-[#C9A227] font-semibold">
                    Ticket #{disp.id} • {disp.date} at {disp.siteName}
                  </span>
                  <p className="text-white/80 mt-1">
                    Worker reported <strong>{disp.expectedHours} hrs</strong> (Recorded was{' '}
                    {disp.reportedHours} hrs). Reason: "{disp.reason}"
                  </p>
                </div>
                <div className="text-right sm:self-center">
                  <span className="px-2.5 py-1 rounded bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                    {disp.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* DISPUTE MODAL */}
      {disputeModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#0E2652] border-2 border-rose-500/50 rounded-2xl max-w-lg w-full p-6 shadow-2xl relative">
            <div className="flex justify-between items-start pb-3 border-b border-[#1E4383]">
              <div className="flex items-center gap-2 text-rose-400">
                <AlertTriangle className="w-5 h-5" />
                <h3 className="font-horizon text-lg font-bold text-white uppercase tracking-wider">
                  Flag A Problem With My Hours
                </h3>
              </div>
              <button
                onClick={() => setDisputeModalOpen(false)}
                className="text-white/60 hover:text-white"
              >
                ✕
              </button>
            </div>

            {disputeSuccess ? (
              <div className="py-8 text-center space-y-3">
                <div className="w-12 h-12 mx-auto rounded-full bg-emerald-500/20 border border-emerald-400 flex items-center justify-center text-emerald-400">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h4 className="font-poppins font-bold text-white text-base">
                  Dispute Ticket Dispatched
                </h4>
                <p className="text-xs font-oswald text-white/70">
                  Sent to Payroll Audit Desk & Site Supervisor Dave Miller. You will see adjustments
                  reflected within 24 hours.
                </p>
              </div>
            ) : (
              <form onSubmit={handleDisputeSubmit} className="mt-4 space-y-4">
                <div>
                  <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                    Select Shift / Date with Issue *
                  </label>
                  <select
                    value={selectedEntryId}
                    onChange={(e) => setSelectedEntryId(e.target.value)}
                    className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-xs focus:border-[#C9A227] outline-none"
                  >
                    {hours.map((h) => (
                      <option key={h.id} value={h.id}>
                        {h.dayOfWeek} ({h.date}) — {h.site} (Logged: {h.hoursApproved} hrs)
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                      Logged Hours
                    </label>
                    <input
                      type="number"
                      step="0.25"
                      value={reportedHours}
                      onChange={(e) => setReportedHours(parseFloat(e.target.value) || 0)}
                      className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                      Actual Hours Worked *
                    </label>
                    <input
                      type="number"
                      step="0.25"
                      required
                      value={expectedHours}
                      onChange={(e) => setExpectedHours(parseFloat(e.target.value) || 0)}
                      className="w-full px-3 py-2 bg-[#06132B] border border-[#C9A227] rounded-lg text-white font-oswald text-xs"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                    Explanation / Reason for Discrepancy *
                  </label>
                  <textarea
                    required
                    rows={3}
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    placeholder="e.g. Scanners went down during 30-min overtime stay authorized by Dave Miller; or lunch clock-out registered 60 mins instead of 30 mins."
                    className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-xs focus:border-[#C9A227] outline-none"
                  />
                </div>

                <div className="p-3 bg-[#06132B] rounded-xl border border-dashed border-[#1E4383] text-center">
                  <Upload className="w-5 h-5 text-white/40 mx-auto mb-1" />
                  <span className="text-xs font-oswald text-white/70 block">
                    Attach Timesheet Photo / Supervisor Written Sign-off (Optional)
                  </span>
                  <input type="file" accept="image/*,.pdf" className="text-[11px] text-white/40 mt-1" />
                </div>

                <div className="pt-2 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setDisputeModalOpen(false)}
                    className="px-4 py-2 rounded-lg bg-[#06132B] text-white font-oswald text-xs uppercase"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2 rounded-lg bg-rose-500 hover:bg-rose-400 text-white font-oswald font-bold text-xs uppercase tracking-wider"
                  >
                    Submit Dispute Ticket
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
