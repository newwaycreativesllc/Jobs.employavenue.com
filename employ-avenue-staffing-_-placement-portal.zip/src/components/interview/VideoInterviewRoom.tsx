import React, { useState } from 'react';
import { useWorkforce } from '../../context/WorkforceContext';
import {
  Video,
  VideoOff,
  Mic,
  MicOff,
  X,
  ShieldCheck,
  CheckCircle2,
  FileText,
  UserCheck,
  Sparkles,
} from 'lucide-react';

interface VideoInterviewRoomProps {
  isOpen: boolean;
  onClose: () => void;
}

export const VideoInterviewRoom: React.FC<VideoInterviewRoomProps> = ({ isOpen, onClose }) => {
  const { user, setUserStatus, uploadDocument } = useWorkforce();
  const [cameraOn, setCameraOn] = useState(true);
  const [micOn, setMicOn] = useState(true);
  const [idInspectionStage, setIdInspectionStage] = useState<'prompt' | 'held_up' | 'verified'>('prompt');
  const [recruiterSpeaking, setRecruiterSpeaking] = useState(true);

  if (!isOpen) return null;

  const handleHoldUpId = () => {
    setIdInspectionStage('held_up');
    setTimeout(() => {
      setIdInspectionStage('verified');
      setUserStatus('On the Roster');
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/90 backdrop-blur-md">
      <div className="bg-[#0E2652] border-2 border-[#C9A227] rounded-2xl max-w-4xl w-full h-[88vh] flex flex-col shadow-2xl overflow-hidden relative">
        {/* Top Header */}
        <div className="bg-[#06132B] px-6 py-3 border-b border-[#1E4383] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="w-3 h-3 rounded-full bg-red-500 animate-pulse"></span>
            <div>
              <h3 className="font-horizon text-base sm:text-lg font-bold text-white uppercase tracking-wider">
                Live Video Interview & Document Verification Room
              </h3>
              <p className="font-oswald text-xs text-[#C9A227]">
                Encrypted Session • Recruiter: Sarah Jenkins
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded-lg bg-rose-500/20 text-rose-300 hover:bg-rose-500/30 text-xs font-oswald uppercase"
          >
            Leave Call
          </button>
        </div>

        {/* Video Canvas Grid */}
        <div className="flex-1 p-4 grid grid-cols-1 md:grid-cols-2 gap-4 bg-[#0A1F44] overflow-hidden">
          {/* Recruiter Stream (Simulated) */}
          <div className="relative rounded-2xl overflow-hidden bg-[#06132B] border-2 border-[#1E4383] flex flex-col items-center justify-center">
            <img
              src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=800&auto=format&fit=crop&q=80"
              alt="Recruiter Sarah"
              className="w-full h-full object-cover"
            />
            <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-md px-3 py-1 rounded-full text-xs font-oswald text-white flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              <span>Sarah Jenkins (Senior Placement)</span>
            </div>

            {/* Recruiter Live Speech Caption */}
            <div className="absolute bottom-4 left-4 right-4 bg-black/75 backdrop-blur-md p-3 rounded-xl text-xs font-oswald text-white border border-[#C9A227]/40">
              {idInspectionStage === 'prompt' &&
                '“Hi Marcus! Great to connect. I see your signed W-4 and I-9 section 1. Please hold your physical photo ID up to the camera so I can verify Section 2.”'}
              {idInspectionStage === 'held_up' &&
                '“Hold steady right there... verifying holographic seal, DOB, and physical issue dates...”'}
              {idInspectionStage === 'verified' &&
                '“Perfect match! Both sides verified. You are now officially On the Roster and cleared for active assignment dispatch!”'}
            </div>
          </div>

          {/* Worker Self-View Stream */}
          <div className="relative rounded-2xl overflow-hidden bg-[#06132B] border-2 border-[#1E4383] flex flex-col items-center justify-center">
            {cameraOn ? (
              <div className="w-full h-full bg-gradient-to-tr from-[#0A1F44] via-[#13336E] to-[#0E2652] flex flex-col items-center justify-center relative">
                {/* Simulated worker silhouette or avatar preview */}
                <div className="w-28 h-28 rounded-full bg-[#1E4383] border-4 border-[#C9A227] flex items-center justify-center text-[#C9A227] text-3xl font-poppins font-bold">
                  {user?.fullName
                    ?.split(' ')
                    .map((n) => n[0])
                    .join('') || 'MV'}
                </div>
                <p className="mt-3 text-sm font-poppins font-semibold text-white">
                  {user?.fullName || 'Worker Self-View'}
                </p>
                <p className="text-xs font-oswald text-[#C9A227]">Camera Feed Active (720p HD)</p>

                {/* Simulated document overlay when holding up ID */}
                {idInspectionStage === 'held_up' && (
                  <div className="absolute inset-x-8 bottom-12 bg-white/10 backdrop-blur-md border-2 border-emerald-400 p-4 rounded-xl text-center animate-pulse">
                    <p className="font-horizon text-xs font-bold text-emerald-300 uppercase">
                      Physical ID Document Positioned in Viewfinder
                    </p>
                    <p className="text-[11px] font-oswald text-white/80">
                      Scanning MRZ barcode & security seals...
                    </p>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center p-6 text-white/50 font-oswald">
                <VideoOff className="w-12 h-12 mx-auto mb-2 text-white/30" />
                <p>Camera is muted</p>
              </div>
            )}

            <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-md px-3 py-1 rounded-full text-xs font-oswald text-white">
              You ({user?.fullName || 'Worker'})
            </div>
          </div>
        </div>

        {/* Live Document Verification Control Bar */}
        <div className="bg-[#06132B] px-6 py-4 border-t border-[#1E4383] flex flex-wrap items-center justify-between gap-3">
          {/* Audio/Video toggles */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setMicOn(!micOn)}
              className={`p-3 rounded-xl border transition ${
                micOn
                  ? 'bg-[#13336E] text-white border-[#1E4383]'
                  : 'bg-rose-500/20 text-rose-400 border-rose-500/40'
              }`}
              title={micOn ? 'Mute Microphone' : 'Unmute Microphone'}
            >
              {micOn ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
            </button>
            <button
              onClick={() => setCameraOn(!cameraOn)}
              className={`p-3 rounded-xl border transition ${
                cameraOn
                  ? 'bg-[#13336E] text-white border-[#1E4383]'
                  : 'bg-rose-500/20 text-rose-400 border-rose-500/40'
              }`}
              title={cameraOn ? 'Turn Camera Off' : 'Turn Camera On'}
            >
              {cameraOn ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
            </button>
          </div>

          {/* Interactive Document Inspection Trigger */}
          <div className="flex items-center gap-3">
            {idInspectionStage === 'prompt' && (
              <button
                onClick={handleHoldUpId}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#C9A227] to-[#DBB535] hover:from-[#DBB535] hover:to-[#C9A227] text-[#0A1F44] font-oswald font-bold text-xs uppercase tracking-wider transition shadow flex items-center gap-2"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>Hold Up Physical ID to Camera</span>
              </button>
            )}

            {idInspectionStage === 'held_up' && (
              <div className="px-4 py-2 rounded-xl bg-[#13336E] border border-[#C9A227] text-[#C9A227] font-oswald text-xs flex items-center gap-2">
                <span className="w-3.5 h-3.5 border-2 border-[#C9A227] border-t-transparent rounded-full animate-spin" />
                <span>Recruiter is inspecting physical document live...</span>
              </div>
            )}

            {idInspectionStage === 'verified' && (
              <div className="flex items-center gap-2">
                <div className="px-4 py-2 rounded-xl bg-emerald-500/20 border border-emerald-400 text-emerald-300 font-oswald text-xs flex items-center gap-1.5 font-bold">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>I-9 Section 2 Verified • Placed "On the Roster"</span>
                </div>
                <button
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl bg-[#C9A227] text-[#0A1F44] font-oswald font-bold text-xs uppercase"
                >
                  Return to Dashboard
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
