import React, { useState } from 'react';
import { useWorkforce } from '../../context/WorkforceContext';
import { Calendar, Clock, Video, CheckCircle2, UserCheck, X } from 'lucide-react';
import { InterviewSlot } from '../../types';

interface InterviewScheduleModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenVideoRoom: () => void;
}

export const InterviewScheduleModal: React.FC<InterviewScheduleModalProps> = ({
  isOpen,
  onClose,
  onOpenVideoRoom,
}) => {
  const { scheduleInterview, user } = useWorkforce();

  const recruiter = {
    name: 'Sarah Jenkins',
    title: 'Senior Placement Recruiter & Dispatch Coordinator',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
  };

  const availableSlots = [
    { date: 'Monday, Nov 2, 2026', time: '09:00 AM EST' },
    { date: 'Monday, Nov 2, 2026', time: '10:30 AM EST' },
    { date: 'Monday, Nov 2, 2026', time: '02:00 PM EST' },
    { date: 'Tuesday, Nov 3, 2026', time: '11:00 AM EST' },
    { date: 'Tuesday, Nov 3, 2026', time: '03:30 PM EST' },
    { date: 'Wednesday, Nov 4, 2026', time: '10:00 AM EST' },
    { date: 'Wednesday, Nov 4, 2026', time: '01:15 PM EST' },
  ];

  const [selectedSlotIndex, setSelectedSlotIndex] = useState<number>(1);
  const [confirmed, setConfirmed] = useState(false);

  if (!isOpen) return null;

  const handleConfirm = () => {
    const chosen = availableSlots[selectedSlotIndex];
    const newSlot: InterviewSlot = {
      id: `int-${Date.now()}`,
      recruiterName: recruiter.name,
      recruiterTitle: recruiter.title,
      date: chosen.date,
      time: chosen.time,
      meetingLink: `https://employavenue.work/meet/v-${Date.now()}`,
      confirmed: true,
    };
    scheduleInterview(newSlot);
    setConfirmed(true);
    setTimeout(() => {
      onClose();
      setConfirmed(false);
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-[#0E2652] border-2 border-[#1E4383] rounded-2xl max-w-lg w-full p-6 shadow-2xl relative">
        <div className="flex items-center justify-between pb-3 border-b border-[#1E4383]">
          <div className="flex items-center gap-2">
            <Video className="w-5 h-5 text-[#C9A227]" />
            <h3 className="font-horizon text-lg font-bold text-white uppercase tracking-wider">
              Schedule Recruiter Video Call
            </h3>
          </div>
          <button onClick={onClose} className="text-white/60 hover:text-white p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        {confirmed ? (
          <div className="py-8 text-center space-y-3">
            <div className="w-14 h-14 mx-auto rounded-full bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center text-emerald-400">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h4 className="font-poppins font-bold text-lg text-white">Video Interview Booked!</h4>
            <p className="font-oswald text-xs text-white/70">
              The meeting link has been placed on your dashboard with an active "Join Video Room"
              button.
            </p>
          </div>
        ) : (
          <div className="mt-4 space-y-4">
            {/* Recruiter Profile Banner */}
            <div className="p-3 bg-[#06132B] rounded-xl border border-[#1E4383] flex items-center gap-3">
              <img
                src={recruiter.avatar}
                alt={recruiter.name}
                className="w-12 h-12 rounded-full border-2 border-[#C9A227] object-cover"
              />
              <div>
                <p className="font-poppins font-bold text-sm text-white">{recruiter.name}</p>
                <p className="font-oswald text-xs text-[#C9A227]">{recruiter.title}</p>
                <p className="font-oswald text-[11px] text-white/60">
                  15-min call: Live photo ID check & placement site matching
                </p>
              </div>
            </div>

            {/* Slot Picker */}
            <div>
              <label className="block text-xs font-poppins font-bold uppercase text-[#C9A227] tracking-wider mb-2">
                Select Your Preferred Time Slot:
              </label>
              <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                {availableSlots.map((slot, idx) => {
                  const isSelected = selectedSlotIndex === idx;
                  return (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setSelectedSlotIndex(idx)}
                      className={`w-full p-3 rounded-xl border text-left text-xs font-oswald flex items-center justify-between transition ${
                        isSelected
                          ? 'bg-[#13336E] border-[#C9A227] text-white font-bold ring-1 ring-[#C9A227]'
                          : 'bg-[#06132B] border-[#1E4383] text-white/80 hover:text-white'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <Calendar className="w-4 h-4 text-[#C9A227]" />
                        <span>{slot.date}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="w-3.5 h-3.5 text-white/60" />
                        <span>{slot.time}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="p-3 bg-[#13336E]/40 rounded-xl border border-[#1E4383] text-[11px] font-oswald text-white/80">
              <strong className="text-[#C9A227]">Preparation Note:</strong> Have your physical
              government ID (Driver's License or Passport) ready to hold up to your camera during
              this call for USCIS I-9 verification.
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-lg bg-[#06132B] hover:bg-[#13336E] text-white font-oswald text-xs uppercase"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirm}
                className="px-6 py-2 rounded-lg bg-[#C9A227] hover:bg-[#DBB535] text-[#0A1F44] font-oswald font-bold text-xs uppercase tracking-wider transition shadow-md"
              >
                Confirm Time Slot
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
