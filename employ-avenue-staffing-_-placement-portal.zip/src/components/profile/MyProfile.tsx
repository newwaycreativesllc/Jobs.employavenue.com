import React, { useState } from 'react';
import { useWorkforce } from '../../context/WorkforceContext';
import {
  User,
  CreditCard,
  Building,
  Phone,
  Mail,
  ShieldCheck,
  CheckCircle2,
  Bell,
  Save,
  Award,
  AlertCircle,
} from 'lucide-react';

export const MyProfile: React.FC = () => {
  const { user, application, updatePayMethod, updateProfileInfo } = useWorkforce();

  // Contact info state
  const [fullName, setFullName] = useState(user?.fullName || 'Marcus Vance');
  const [phone, setPhone] = useState(user?.phone || '(555) 234-8910');
  const [email, setEmail] = useState(user?.email || 'marcus.vance@employavenue.com');
  const [tradeTitle, setTradeTitle] = useState(
    user?.tradeTitle || 'Lead Assembler & Forklift Operator'
  );

  // Pay method state
  const [bankName, setBankName] = useState(user?.bankName || 'First Horizon National Bank');
  const [accountType, setAccountType] = useState<'Checking' | 'Savings'>(
    user?.accountType || 'Checking'
  );
  const [routingNumber, setRoutingNumber] = useState(user?.routingNumber || '121000358');
  const [accountNumber, setAccountNumber] = useState('4819');

  // Notification prefs state
  const [smsAlerts, setSmsAlerts] = useState(true);
  const [dailyTimesheetSummary, setDailyTimesheetSummary] = useState(true);
  const [paydayAlerts, setPaydayAlerts] = useState(true);

  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Profile picture state
  const [profilePic, setProfilePic] = useState<string>(user?.profilePic || '');

  const handleSaveContact = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfileInfo(fullName, phone, email, tradeTitle, profilePic);
    setToastMessage('Contact profile and photo updated and synced across all client badges.');
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result as string;
      setProfilePic(base64String);
      updateProfileInfo(fullName, phone, email, tradeTitle, base64String);
      setToastMessage('New profile picture uploaded and saved successfully.');
      setTimeout(() => setToastMessage(null), 3000);
    };
    reader.readAsDataURL(file);
  };

  const handleSavePayMethod = (e: React.FormEvent) => {
    e.preventDefault();
    if (!routingNumber.trim() || !accountNumber.trim()) return;
    updatePayMethod(bankName, accountType, routingNumber, accountNumber);
    setToastMessage('Direct deposit pay method encrypted and verified.');
    setTimeout(() => setToastMessage(null), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-[#0E2652] border border-[#1E4383] rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="relative group w-16 h-16 rounded-2xl bg-[#06132B] border-2 border-[#C9A227] flex items-center justify-center text-[#C9A227] text-2xl font-horizon font-bold shadow-lg overflow-hidden shrink-0">
              {profilePic ? (
                <img src={profilePic} alt={fullName} className="w-full h-full object-cover" />
              ) : (
                fullName
                  .split(' ')
                  .map((n) => n[0])
                  .join('')
                  .toUpperCase()
                  .slice(0, 2)
              )}
            </div>
            <div>
              <span className="text-xs font-poppins text-[#C9A227] uppercase tracking-widest font-bold">
                Permanent Worker Profile
              </span>
              <h2 className="text-2xl font-horizon font-bold text-white tracking-wider">
                {fullName}
              </h2>
              <p className="text-xs font-oswald text-white/70">
                {tradeTitle} • Placement Status: <span className="text-[#C9A227]">{user?.status}</span>
              </p>
            </div>
          </div>

          <div className="bg-[#06132B] px-4 py-2.5 rounded-xl border border-[#1E4383] text-left md:text-right">
            <span className="text-[10px] font-oswald text-white/60 uppercase block">Profile ID</span>
            <span className="font-mono text-xs text-[#C9A227]">{user?.id || 'EA-8921'}</span>
          </div>
        </div>
      </div>

      {toastMessage && (
        <div className="p-4 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-oswald text-xs flex items-center gap-2 shadow-lg">
          <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Grid: Contact Information & Direct Deposit Pay Method */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Contact Info Card */}
        <div className="bg-[#0E2652] border border-[#1E4383] rounded-2xl p-6 shadow-xl">
          <h3 className="font-poppins font-bold text-base text-white flex items-center gap-2 mb-1">
            <User className="w-5 h-5 text-[#C9A227]" />
            <span>Contact Information & Photo</span>
          </h3>
          <p className="text-xs font-oswald text-white/70 mb-4">
            Changes sync across all active site badges and emergency dispatch cards.
          </p>

          <form onSubmit={handleSaveContact} className="space-y-4">
            {/* Profile Picture Upload Section */}
            <div className="bg-[#06132B] border border-[#1E4383] rounded-xl p-4 flex items-center gap-4">
              <div className="relative w-16 h-16 rounded-xl bg-slate-800 border border-[#C9A227] overflow-hidden flex items-center justify-center shrink-0">
                {profilePic ? (
                  <img src={profilePic} alt="Profile" className="w-full h-full object-cover" />
                ) : (
                  <User className="w-8 h-8 text-[#C9A227]" />
                )}
              </div>
              <div className="flex-1 space-y-1">
                <label className="block text-xs font-oswald uppercase text-white/90 font-bold">
                  Worker Badge Photo
                </label>
                <p className="text-[11px] text-white/60 font-oswald">
                  Upload a clear headshot for your digital gate badge & profile.
                </p>
                <label className="inline-block mt-1 cursor-pointer px-3 py-1.5 rounded-lg bg-[#C9A227] hover:bg-[#DBB535] text-[#0A1F44] font-oswald font-bold text-xs uppercase tracking-wide transition shadow-xs">
                  <span>Upload Photo</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </label>
              </div>
            </div>

            <div>
              <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                Full Name *
              </label>
              <input
                type="text"
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-xs focus:border-[#C9A227] outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                Primary Trade Title
              </label>
              <input
                type="text"
                value={tradeTitle}
                onChange={(e) => setTradeTitle(e.target.value)}
                className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-xs focus:border-[#C9A227] outline-none"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                  Mobile Phone *
                </label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-xs focus:border-[#C9A227] outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                  Email Address *
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-xs focus:border-[#C9A227] outline-none"
                />
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-[#C9A227] hover:bg-[#DBB535] text-[#0A1F44] font-oswald font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 shadow"
              >
                <Save className="w-4 h-4" />
                <span>Save Contact Info</span>
              </button>
            </div>
          </form>
        </div>

        {/* PAY METHOD: DIRECT DEPOSIT BANK DETAILS */}
        <div className="bg-[#0E2652] border border-[#1E4383] rounded-2xl p-6 shadow-xl">
          <div className="flex items-center justify-between mb-1">
            <h3 className="font-poppins font-bold text-base text-white flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-[#C9A227]" />
              <span>Direct Deposit Pay Method</span>
            </h3>
            <span className="text-[10px] font-oswald uppercase px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-semibold border border-emerald-500/40">
              ACH Verified
            </span>
          </div>
          <p className="text-xs font-oswald text-white/70 mb-4">
            Paychecks are automatically deposited every Friday morning at 05:00 AM EST.
          </p>

          <form onSubmit={handleSavePayMethod} className="space-y-4">
            <div>
              <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                Financial Institution / Bank Name *
              </label>
              <input
                type="text"
                required
                value={bankName}
                onChange={(e) => setBankName(e.target.value)}
                placeholder="e.g. First Horizon National, Chase, Wells Fargo"
                className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-xs focus:border-[#C9A227] outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                Account Type *
              </label>
              <div className="grid grid-cols-2 gap-2">
                {(['Checking', 'Savings'] as const).map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setAccountType(t)}
                    className={`py-2 rounded-lg font-oswald text-xs uppercase font-semibold transition ${
                      accountType === t
                        ? 'bg-[#C9A227] text-[#0A1F44]'
                        : 'bg-[#06132B] text-white/70 border border-[#1E4383]'
                    }`}
                  >
                    {t} Account
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                  Routing Number (9 Digits) *
                </label>
                <input
                  type="text"
                  required
                  maxLength={9}
                  value={routingNumber}
                  onChange={(e) => setRoutingNumber(e.target.value)}
                  placeholder="121000358"
                  className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-mono text-xs focus:border-[#C9A227] outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                  Account Number *
                </label>
                <input
                  type="text"
                  required
                  value={accountNumber}
                  onChange={(e) => setAccountNumber(e.target.value)}
                  placeholder="••••4819"
                  className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-mono text-xs focus:border-[#C9A227] outline-none"
                />
              </div>
            </div>

            <div className="p-3 bg-[#06132B] rounded-xl border border-[#1E4383] flex items-center gap-2 text-[11px] font-oswald text-white/70">
              <ShieldCheck className="w-4 h-4 text-[#C9A227] flex-shrink-0" />
              <span>
                Encrypted with NACHA and PCI-DSS compliance standards. Payments remit via Federal
                Reserve ACH.
              </span>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#C9A227] to-[#DBB535] text-[#0A1F44] font-oswald font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 shadow"
              >
                <Save className="w-4 h-4" />
                <span>Save Pay Method</span>
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Skills, Certifications & Emergency Contact Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Skills List */}
        <div className="bg-[#0E2652] border border-[#1E4383] rounded-2xl p-5 shadow-xl">
          <h4 className="font-poppins font-bold text-sm text-white mb-3 flex items-center gap-2">
            <Award className="w-4 h-4 text-[#C9A227]" />
            <span>Verified Trade Skills</span>
          </h4>
          <div className="flex flex-wrap gap-1.5">
            {application.skills.map((skill) => (
              <span
                key={skill}
                className="px-2.5 py-1 rounded-md bg-[#06132B] text-white font-oswald text-xs border border-[#1E4383]"
              >
                {skill}
              </span>
            ))}
          </div>
        </div>

        {/* Emergency Contact */}
        <div className="bg-[#0E2652] border border-[#1E4383] rounded-2xl p-5 shadow-xl">
          <h4 className="font-poppins font-bold text-sm text-white mb-3 flex items-center gap-2">
            <Phone className="w-4 h-4 text-[#C9A227]" />
            <span>Emergency Contact</span>
          </h4>
          <div className="space-y-1.5 text-xs font-oswald text-white/80">
            <p>
              Name: <strong className="text-white">{application.emergencyName || 'Brenda Vance'}</strong>
            </p>
            <p>
              Relation: <span className="text-white/70">{application.emergencyRelation || 'Spouse'}</span>
            </p>
            <p>
              Phone: <span className="text-[#C9A227] font-semibold">{application.emergencyPhone || '(555) 912-3344'}</span>
            </p>
          </div>
        </div>

        {/* Notification Preferences */}
        <div className="bg-[#0E2652] border border-[#1E4383] rounded-2xl p-5 shadow-xl">
          <h4 className="font-poppins font-bold text-sm text-white mb-3 flex items-center gap-2">
            <Bell className="w-4 h-4 text-[#C9A227]" />
            <span>Alert Preferences</span>
          </h4>
          <div className="space-y-2 text-xs font-oswald">
            <label className="flex items-center justify-between cursor-pointer">
              <span className="text-white/80">SMS Urgent Shift Alerts</span>
              <input
                type="checkbox"
                checked={smsAlerts}
                onChange={(e) => setSmsAlerts(e.target.checked)}
                className="w-4 h-4 accent-[#C9A227]"
              />
            </label>
            <label className="flex items-center justify-between cursor-pointer">
              <span className="text-white/80">Daily Timesheet Dispatches</span>
              <input
                type="checkbox"
                checked={dailyTimesheetSummary}
                onChange={(e) => setDailyTimesheetSummary(e.target.checked)}
                className="w-4 h-4 accent-[#C9A227]"
              />
            </label>
            <label className="flex items-center justify-between cursor-pointer">
              <span className="text-white/80">Payday Direct Deposit Notices</span>
              <input
                type="checkbox"
                checked={paydayAlerts}
                onChange={(e) => setPaydayAlerts(e.target.checked)}
                className="w-4 h-4 accent-[#C9A227]"
              />
            </label>
          </div>
        </div>
      </div>
    </div>
  );
};
