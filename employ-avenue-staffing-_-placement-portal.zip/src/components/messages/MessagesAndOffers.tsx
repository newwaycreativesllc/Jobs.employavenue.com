import React, { useState } from 'react';
import { useWorkforce } from '../../context/WorkforceContext';
import {
  Mail,
  Send,
  Briefcase,
  CheckCircle2,
  XCircle,
  Clock,
  MapPin,
  DollarSign,
  UserCheck,
  Sparkles,
  ArrowRight,
  ShieldAlert,
} from 'lucide-react';

export const MessagesAndOffers: React.FC = () => {
  const { messages, sendMessage, offers, acceptOffer, declineOffer, user } = useWorkforce();
  const [activeTab, setActiveTab] = useState<'messages' | 'offers'>('offers');
  const [inputMessage, setInputMessage] = useState('');

  const pendingOffersCount = offers.filter((o) => o.status === 'Pending').length;

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;
    sendMessage(inputMessage);
    setInputMessage('');
  };

  const quickReplies = [
    'Confirmed for my shift tomorrow morning!',
    'Question regarding PPE vest pickup at Bay 14.',
    'I have arrived at the facility security turnstile.',
    'Could you verify my direct deposit status?',
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-[#0E2652] border border-[#1E4383] rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span className="text-xs font-poppins text-[#C9A227] uppercase tracking-widest font-bold flex items-center gap-1.5">
              <Mail className="w-4 h-4" />
              <span>Agency Communications Hub</span>
            </span>
            <h2 className="text-2xl font-horizon font-bold text-white tracking-wider">
              Messages & Placement Offers
            </h2>
            <p className="mt-1 text-xs font-oswald text-white/70">
              Direct two-way dispatch thread with Employ Avenue recruiters and real-time job offer cards.
              Accepting an offer updates your active assignment card immediately.
            </p>
          </div>

          {/* Tab buttons */}
          <div className="flex items-center gap-2 bg-[#06132B] p-1.5 rounded-xl border border-[#1E4383]">
            <button
              onClick={() => setActiveTab('offers')}
              className={`px-4 py-2 rounded-lg font-oswald text-xs uppercase tracking-wider transition flex items-center gap-1.5 ${
                activeTab === 'offers'
                  ? 'bg-[#C9A227] text-[#0A1F44] font-bold shadow'
                  : 'text-white/70 hover:text-white'
              }`}
            >
              <Briefcase className="w-4 h-4" />
              <span>Offers Inbox</span>
              {pendingOffersCount > 0 && (
                <span className="w-4 h-4 rounded-full bg-emerald-500 text-[#0A1F44] text-[10px] font-bold flex items-center justify-center">
                  {pendingOffersCount}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('messages')}
              className={`px-4 py-2 rounded-lg font-oswald text-xs uppercase tracking-wider transition flex items-center gap-1.5 ${
                activeTab === 'messages'
                  ? 'bg-[#C9A227] text-[#0A1F44] font-bold shadow'
                  : 'text-white/70 hover:text-white'
              }`}
            >
              <Mail className="w-4 h-4" />
              <span>Dispatch Thread</span>
            </button>
          </div>
        </div>
      </div>

      {/* OFFERS INBOX VIEW */}
      {activeTab === 'offers' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between px-1">
            <h3 className="font-poppins font-bold text-base text-white">
              Official Shift Placement Offers ({offers.length})
            </h3>
            <span className="text-xs font-oswald text-[#C9A227]">
              Accepting an offer immediately assigns you to the site
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {offers.map((offer) => {
              const isAccepted = offer.status === 'Accepted';
              const isDeclined = offer.status === 'Declined';
              const isPending = offer.status === 'Pending';

              return (
                <div
                  key={offer.id}
                  className={`bg-[#0E2652] rounded-2xl border p-6 shadow-xl flex flex-col justify-between transition-all duration-300 ${
                    isAccepted
                      ? 'border-[#C9A227] ring-1 ring-[#C9A227]/50'
                      : isDeclined
                      ? 'border-gray-700 opacity-60'
                      : 'border-[#1E4383] hover:border-[#C9A227]'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[10px] font-poppins font-bold uppercase tracking-wider text-[#C9A227]">
                        Offer #{offer.id} • {offer.duration}
                      </span>
                      <span
                        className={`text-[10px] font-oswald uppercase px-2.5 py-0.5 rounded-full font-bold ${
                          isAccepted
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                            : isDeclined
                            ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                            : 'bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse'
                        }`}
                      >
                        {offer.status}
                      </span>
                    </div>

                    <h4 className="font-poppins font-bold text-lg text-white">{offer.title}</h4>
                    <p className="font-oswald text-xs text-[#C9A227] font-semibold">
                      {offer.clientName}
                    </p>

                    <div className="my-4 p-3 bg-[#06132B] rounded-xl border border-[#1E4383] space-y-1.5 text-xs font-oswald text-white/80">
                      <div className="flex items-center justify-between">
                        <span className="text-white/50">Pay Rate:</span>
                        <span className="font-horizon text-base font-bold text-[#C9A227]">
                          ${offer.hourlyRate.toFixed(2)}/hr
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-white/50">Shift Schedule:</span>
                        <span className="text-white font-medium">{offer.shift}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-white/50">Site Location:</span>
                        <span className="text-white font-medium truncate max-w-[200px]">
                          {offer.location}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-white/50">Report To:</span>
                        <span className="text-white font-medium">{offer.supervisor}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-white/50">Start Date:</span>
                        <span className="text-[#C9A227] font-semibold">{offer.startDate}</span>
                      </div>
                    </div>
                  </div>

                  {/* Actions: Accept / Decline */}
                  <div className="pt-3 border-t border-[#1E4383]">
                    {isPending ? (
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => declineOffer(offer.id)}
                          className="py-2.5 px-3 rounded-xl bg-[#06132B] hover:bg-[#13336E] text-rose-300 border border-rose-500/30 font-oswald font-semibold text-xs uppercase tracking-wider transition flex items-center justify-center gap-1.5"
                        >
                          <XCircle className="w-4 h-4" />
                          <span>Decline</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => acceptOffer(offer.id)}
                          className="py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#C9A227] to-[#DBB535] hover:from-[#DBB535] hover:to-[#C9A227] text-[#0A1F44] font-horizon font-bold text-xs uppercase tracking-wider transition shadow-md shadow-[#C9A227]/25 flex items-center justify-center gap-1.5 hover:scale-[1.02]"
                        >
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Accept & Assign</span>
                        </button>
                      </div>
                    ) : isAccepted ? (
                      <div className="p-2.5 bg-emerald-500/20 rounded-xl border border-emerald-400 text-emerald-300 text-center font-oswald text-xs flex items-center justify-center gap-1.5 font-bold">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Accepted • Active Assignment on Dashboard</span>
                      </div>
                    ) : (
                      <div className="p-2 bg-[#06132B] rounded-xl text-center text-white/50 font-oswald text-xs">
                        Offer Declined
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* DISPATCH THREAD VIEW */}
      {activeTab === 'messages' && (
        <div className="bg-[#0E2652] border border-[#1E4383] rounded-2xl shadow-xl flex flex-col h-[650px] overflow-hidden">
          {/* Thread Header */}
          <div className="p-4 bg-[#06132B] border-b border-[#1E4383] flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img
                src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80"
                alt="Sarah Jenkins"
                className="w-10 h-10 rounded-full border border-[#C9A227] object-cover"
              />
              <div>
                <h4 className="font-poppins font-bold text-sm text-white">
                  Sarah Jenkins & Employ Avenue Dispatch Desk
                </h4>
                <p className="text-[11px] font-oswald text-[#C9A227]">
                  Official Staffing Placement Coordinator • Active Online
                </p>
              </div>
            </div>
            <span className="text-[11px] font-oswald text-white/50 hidden sm:inline">
              Single Unified Agency Thread
            </span>
          </div>

          {/* Messages History (Scrollable) */}
          <div className="flex-1 p-5 overflow-y-auto space-y-4 bg-[#0A1F44]/50">
            {messages.map((msg) => {
              const isWorker = msg.sender === 'worker';
              const isSystem = msg.sender === 'system';

              if (isSystem) {
                return (
                  <div key={msg.id} className="flex justify-center my-2">
                    <div className="bg-[#06132B] border border-[#C9A227]/40 px-4 py-2 rounded-full text-xs font-oswald text-[#C9A227] flex items-center gap-2 shadow">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>{msg.content}</span>
                      <span className="text-[10px] text-white/40">{msg.timestamp}</span>
                    </div>
                  </div>
                );
              }

              return (
                <div
                  key={msg.id}
                  className={`flex items-end gap-2.5 ${isWorker ? 'justify-end' : 'justify-start'}`}
                >
                  {!isWorker && (
                    <img
                      src={
                        msg.avatar ||
                        'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80'
                      }
                      alt={msg.senderName}
                      className="w-7 h-7 rounded-full border border-[#C9A227] object-cover flex-shrink-0"
                    />
                  )}
                  <div
                    className={`max-w-md p-3.5 rounded-2xl text-xs font-oswald space-y-1 shadow ${
                      isWorker
                        ? 'bg-[#C9A227] text-[#0A1F44] rounded-br-none font-medium'
                        : 'bg-[#0E2652] text-white border border-[#1E4383] rounded-bl-none'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-3 text-[10px] opacity-75">
                      <span className="font-poppins font-bold">{msg.senderName}</span>
                      <span>{msg.timestamp}</span>
                    </div>
                    <p className="leading-relaxed text-sm font-oswald">{msg.content}</p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Quick Replies Strip */}
          <div className="px-4 py-2 bg-[#06132B] border-t border-[#1E4383] overflow-x-auto">
            <div className="flex items-center gap-1.5 whitespace-nowrap">
              <span className="text-[10px] font-oswald uppercase text-white/50 mr-1">Quick:</span>
              {quickReplies.map((qr, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => sendMessage(qr)}
                  className="px-2.5 py-1 rounded bg-[#0A1F44] hover:bg-[#13336E] text-[11px] font-oswald text-white/80 border border-[#1E4383] transition"
                >
                  {qr}
                </button>
              ))}
            </div>
          </div>

          {/* Message Input Bar */}
          <form
            onSubmit={handleSend}
            className="p-3 bg-[#06132B] border-t border-[#1E4383] flex items-center gap-2"
          >
            <input
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder="Type message to agency dispatcher or recruiter..."
              className="flex-1 px-4 py-2.5 bg-[#0A1F44] border border-[#1E4383] rounded-xl text-white font-oswald text-xs placeholder-white/40 focus:border-[#C9A227] outline-none"
            />
            <button
              type="submit"
              className="px-5 py-2.5 bg-[#C9A227] hover:bg-[#DBB535] text-[#0A1F44] font-horizon font-bold text-xs uppercase tracking-wider rounded-xl transition flex items-center gap-1.5 shadow"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Send</span>
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
