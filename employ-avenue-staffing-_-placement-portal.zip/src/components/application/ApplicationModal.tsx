import React, { useState } from 'react';
import { useWorkforce } from '../../context/WorkforceContext';
import {
  X,
  Save,
  ArrowRight,
  ArrowLeft,
  Upload,
  CheckCircle2,
  FileText,
  AlertCircle,
  Plus,
  Trash2,
  ShieldCheck,
  Camera,
  Signature,
  Calendar,
  Sparkles,
} from 'lucide-react';
import { WorkHistoryItem } from '../../types';

interface ApplicationModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialStep?: number;
}

export const ApplicationModal: React.FC<ApplicationModalProps> = ({
  isOpen,
  onClose,
  initialStep = 1,
}) => {
  const { application, saveApplicationStep, submitApplication } = useWorkforce();

  const [step, setStep] = useState<number>(initialStep || application.currentStep || 1);
  const [formData, setFormData] = useState(application);

  // Resume parse review state
  const [resumeParsing, setResumeParsing] = useState(false);
  const [resumeParsedReviewMode, setResumeParsedReviewMode] = useState(false);
  const [saveToast, setSaveToast] = useState(false);

  // If modal reopens, sync step
  React.useEffect(() => {
    if (initialStep) {
      setStep(initialStep);
    }
  }, [initialStep, isOpen]);

  if (!isOpen) return null;

  const handleSaveAndClose = () => {
    saveApplicationStep(formData, step);
    setSaveToast(true);
    setTimeout(() => {
      setSaveToast(false);
      onClose();
    }, 800);
  };

  const handleContinue = () => {
    saveApplicationStep(formData, step + 1);
    setStep((prev) => Math.min(prev + 1, 6));
  };

  const handleBack = () => {
    saveApplicationStep(formData, step - 1);
    setStep((prev) => Math.max(prev - 1, 1));
  };

  const handleSubmit = () => {
    saveApplicationStep(formData, 6);
    submitApplication();
    onClose();
  };

  // Simulated Resume Parser
  const simulateResumeParse = (fileName: string) => {
    setResumeParsing(true);
    setTimeout(() => {
      setResumeParsing(false);
      setResumeParsedReviewMode(true);

      const parsedHistory: WorkHistoryItem[] = [
        {
          id: `wh-${Date.now()}-1`,
          employer: 'Piedmont Distribution Hub',
          role: 'Senior Materials Handler & Forklift Driver',
          location: 'Atlanta, GA',
          startDate: '2023-03',
          endDate: '2026-08',
          responsibilities:
            'Operated high-reach stand-up forklifts to stage freight for outbound LTL carriers; logged 120+ pallets per shift with 99.8% barcode accuracy.',
        },
        {
          id: `wh-${Date.now()}-2`,
          employer: 'Carter Industrial Components',
          role: 'Mechanical Assembly Technician',
          location: 'Marietta, GA',
          startDate: '2020-01',
          endDate: '2023-02',
          responsibilities:
            'Assembled pneumatic valve manifolds using calibrated torque tools and safety lockouts. Adhered strictly to OSHA and 5S standards.',
        },
      ];

      const parsedSkills = [
        'Stand-up Forklift (OSHA Certified)',
        'Sub-assembly & Blueprint Reading',
        'Pallet Jack & Order Picking',
        'RF Scanner Operations',
        '5S Lean Manufacturing',
        'Quality Inspection (ISO 9001)',
      ];

      setFormData((prev) => ({
        ...prev,
        resumeFileName: fileName,
        resumeFileDate: new Date().toLocaleDateString('en-US', {
          month: 'short',
          day: 'numeric',
          year: 'numeric',
        }),
        skills: parsedSkills,
        workHistory: parsedHistory,
        parsedFromResume: true,
      }));
    }, 1200);
  };

  // Helper to add skill
  const handleAddSkill = (skillText: string) => {
    if (!skillText.trim() || formData.skills.includes(skillText.trim())) return;
    setFormData((prev) => ({
      ...prev,
      skills: [...prev.skills, skillText.trim()],
    }));
  };

  const handleRemoveSkill = (skillToRemove: string) => {
    setFormData((prev) => ({
      ...prev,
      skills: prev.skills.filter((s) => s !== skillToRemove),
    }));
  };

  // Helper to add work history item
  const handleAddWorkHistory = () => {
    const newItem: WorkHistoryItem = {
      id: `wh-${Date.now()}`,
      employer: '',
      role: '',
      location: '',
      startDate: '',
      endDate: '',
      responsibilities: '',
    };
    setFormData((prev) => ({
      ...prev,
      workHistory: [newItem, ...prev.workHistory],
    }));
  };

  const handleUpdateWorkHistory = (id: string, key: keyof WorkHistoryItem, val: string) => {
    setFormData((prev) => ({
      ...prev,
      workHistory: prev.workHistory.map((item) =>
        item.id === id ? { ...item, [key]: val } : item
      ),
    }));
  };

  const handleDeleteWorkHistory = (id: string) => {
    setFormData((prev) => ({
      ...prev,
      workHistory: prev.workHistory.filter((item) => item.id !== id),
    }));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-[#0E2652] border-2 border-[#1E4383] rounded-2xl max-w-4xl w-full my-auto shadow-2xl flex flex-col max-h-[92vh] overflow-hidden relative">
        {/* Save confirmation toast */}
        {saveToast && (
          <div className="absolute top-4 right-16 z-50 bg-[#C9A227] text-[#0A1F44] px-4 py-2 rounded-lg font-oswald font-bold text-sm shadow-xl flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4" />
            <span>Progress Saved Permanently!</span>
          </div>
        )}

        {/* Modal Top Header */}
        <div className="bg-[#06132B] px-6 py-4 border-b border-[#1E4383] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#C9A227]/20 border border-[#C9A227] flex items-center justify-center text-[#C9A227]">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-horizon text-lg sm:text-xl font-bold text-white uppercase tracking-wider">
                Permanent Worker Onboarding Application
              </h2>
              <p className="font-oswald text-xs text-[#C9A227] tracking-wider uppercase">
                Step {step} of 6 — All changes autosaved to your profile
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleSaveAndClose}
              className="px-3.5 py-1.5 rounded-lg bg-[#13336E] hover:bg-[#1E4383] text-[#C9A227] border border-[#C9A227]/40 font-oswald text-xs font-semibold uppercase tracking-wider transition flex items-center gap-1.5"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save & Close</span>
            </button>
            <button
              onClick={handleSaveAndClose}
              className="p-1.5 text-white/60 hover:text-white rounded-lg hover:bg-white/10"
              title="Save & Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* 6 Step Progress Pills */}
        <div className="bg-[#0A1F44] border-b border-[#1E4383] px-6 py-2.5 overflow-x-auto">
          <div className="flex items-center justify-between min-w-[580px] gap-2">
            {[
              { num: 1, title: 'Basic Info & SMS' },
              { num: 2, title: 'Resume Parser' },
              { num: 3, title: 'Job Interests' },
              { num: 4, title: 'W-4, I-9 & ID' },
              { num: 5, title: '4 Consents' },
              { num: 6, title: 'Review & Submit' },
            ].map((s) => {
              const isActive = step === s.num;
              const isDone = step > s.num;
              return (
                <button
                  key={s.num}
                  onClick={() => {
                    saveApplicationStep(formData, s.num);
                    setStep(s.num);
                  }}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg font-oswald text-xs uppercase tracking-wider transition ${
                    isActive
                      ? 'bg-[#C9A227] text-[#0A1F44] font-bold shadow'
                      : isDone
                      ? 'bg-[#13336E] text-white/90 border border-[#C9A227]/30'
                      : 'bg-[#06132B] text-white/50'
                  }`}
                >
                  <span
                    className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-bold ${
                      isActive
                        ? 'bg-[#0A1F44] text-[#C9A227]'
                        : isDone
                        ? 'bg-emerald-500 text-white'
                        : 'bg-white/20 text-white'
                    }`}
                  >
                    {isDone ? '✓' : s.num}
                  </span>
                  <span>{s.title}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Step Content Body (Scrollable) */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {/* STEP 1: BASIC INFO & SMS CONSENT */}
          {step === 1 && (
            <div className="space-y-5">
              <div className="border-b border-[#1E4383] pb-3">
                <h3 className="font-poppins text-lg font-bold text-white">
                  Step 1: Contact Information & Dispatch Messaging Consent
                </h3>
                <p className="font-oswald text-xs text-white/70">
                  This identity permanently anchors your staffing placement, direct deposit, and tax
                  records.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                    First Name *
                  </label>
                  <input
                    type="text"
                    value={formData.firstName}
                    onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                    className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-sm focus:border-[#C9A227] outline-none"
                    placeholder="Marcus"
                  />
                </div>
                <div>
                  <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                    Last Name *
                  </label>
                  <input
                    type="text"
                    value={formData.lastName}
                    onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                    className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-sm focus:border-[#C9A227] outline-none"
                    placeholder="Vance"
                  />
                </div>
                <div>
                  <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                    Preferred Name / Nickname
                  </label>
                  <input
                    type="text"
                    value={formData.preferredName}
                    onChange={(e) => setFormData({ ...formData, preferredName: e.target.value })}
                    className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-sm focus:border-[#C9A227] outline-none"
                    placeholder="Marc"
                  />
                </div>
                <div>
                  <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                    Primary Phone (Mobile) *
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-sm focus:border-[#C9A227] outline-none"
                    placeholder="(555) 234-8910"
                  />
                </div>
                <div>
                  <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-sm focus:border-[#C9A227] outline-none"
                    placeholder="marcus.vance@employavenue.com"
                  />
                </div>
                <div>
                  <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                    Date of Birth *
                  </label>
                  <input
                    type="date"
                    value={formData.dob}
                    onChange={(e) => setFormData({ ...formData, dob: e.target.value })}
                    className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-sm focus:border-[#C9A227] outline-none"
                  />
                </div>
              </div>

              {/* Physical Street Address */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                    Street Address *
                  </label>
                  <input
                    type="text"
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-sm focus:border-[#C9A227] outline-none"
                    placeholder="742 Evergreen Parkway, Apt 3B"
                  />
                </div>
                <div>
                  <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                    City *
                  </label>
                  <input
                    type="text"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-sm focus:border-[#C9A227] outline-none"
                    placeholder="Atlanta"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                      State *
                    </label>
                    <input
                      type="text"
                      value={formData.state}
                      onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                      className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-sm focus:border-[#C9A227] outline-none uppercase"
                      placeholder="GA"
                      maxLength={2}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                      Zip *
                    </label>
                    <input
                      type="text"
                      value={formData.zipCode}
                      onChange={(e) => setFormData({ ...formData, zipCode: e.target.value })}
                      className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-sm focus:border-[#C9A227] outline-none"
                      placeholder="30318"
                    />
                  </div>
                </div>
              </div>

              {/* Emergency Contact */}
              <div className="p-4 bg-[#06132B] rounded-xl border border-[#1E4383] space-y-3">
                <span className="text-xs font-poppins font-bold text-[#C9A227] uppercase tracking-wider block">
                  Emergency Contact Notification
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] font-oswald uppercase text-white/70 mb-1">
                      Contact Name
                    </label>
                    <input
                      type="text"
                      value={formData.emergencyName}
                      onChange={(e) => setFormData({ ...formData, emergencyName: e.target.value })}
                      className="w-full px-3 py-2 bg-[#0A1F44] border border-[#1E4383] rounded-lg text-white font-oswald text-sm"
                      placeholder="Brenda Vance"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-oswald uppercase text-white/70 mb-1">
                      Relationship
                    </label>
                    <input
                      type="text"
                      value={formData.emergencyRelation}
                      onChange={(e) =>
                        setFormData({ ...formData, emergencyRelation: e.target.value })
                      }
                      className="w-full px-3 py-2 bg-[#0A1F44] border border-[#1E4383] rounded-lg text-white font-oswald text-sm"
                      placeholder="Spouse / Parent / Sibling"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-oswald uppercase text-white/70 mb-1">
                      Emergency Phone
                    </label>
                    <input
                      type="tel"
                      value={formData.emergencyPhone}
                      onChange={(e) => setFormData({ ...formData, emergencyPhone: e.target.value })}
                      className="w-full px-3 py-2 bg-[#0A1F44] border border-[#1E4383] rounded-lg text-white font-oswald text-sm"
                      placeholder="(555) 912-3344"
                    />
                  </div>
                </div>
              </div>

              {/* MANDATORY TEXTING-CONSENT CHECKBOX */}
              <div className="p-4 bg-gradient-to-r from-[#06132B] to-[#13336E]/40 rounded-xl border-2 border-[#C9A227]/40 flex items-start gap-3">
                <input
                  type="checkbox"
                  id="smsConsentCheckbox"
                  checked={formData.smsConsent}
                  onChange={(e) => setFormData({ ...formData, smsConsent: e.target.checked })}
                  className="mt-1 w-5 h-5 accent-[#C9A227] rounded cursor-pointer"
                />
                <label htmlFor="smsConsentCheckbox" className="cursor-pointer text-xs font-oswald text-white leading-relaxed">
                  <strong className="text-[#C9A227] font-poppins uppercase block mb-0.5">
                    Consent to Texting & Shift Alert Dispatches *
                  </strong>
                  I hereby authorize Employ Avenue Staffing to send text messages (SMS) and automated dispatch notifications to the mobile number provided regarding urgent shift availability, dispatch time changes, emergency plant updates, and onboarding documents. Message frequency varies. Msg & data rates may apply. Reply STOP at any time to opt out.
                </label>
              </div>
            </div>
          )}

          {/* STEP 2: RESUME UPLOAD & PARSER WITH REVIEW-AND-CORRECT */}
          {step === 2 && (
            <div className="space-y-5">
              <div className="border-b border-[#1E4383] pb-3">
                <h3 className="font-poppins text-lg font-bold text-white">
                  Step 2: Resume Upload & Smart Skill Parsing
                </h3>
                <p className="font-oswald text-xs text-white/70">
                  Upload your resume. Our system automatically parses your work history, skills,
                  employers, and dates—and lets you review and correct everything before saving.
                  Your uploaded file is permanently stored on your profile.
                </p>
              </div>

              {/* Resume File Upload Box */}
              <div className="border-2 border-dashed border-[#C9A227]/60 hover:border-[#C9A227] bg-[#06132B]/80 rounded-2xl p-6 text-center transition">
                <div className="w-14 h-14 mx-auto rounded-full bg-[#C9A227]/15 flex items-center justify-center text-[#C9A227] mb-3">
                  <Upload className="w-7 h-7" />
                </div>
                <h4 className="font-poppins font-bold text-white text-base">
                  Drag & Drop Your Resume (PDF, DOCX, TXT)
                </h4>
                <p className="font-oswald text-xs text-white/60 mt-1 mb-4">
                  Max file size: 10 MB • Instant parsing into work history & certifications
                </p>

                <div className="flex flex-wrap items-center justify-center gap-3">
                  <label className="cursor-pointer px-4 py-2 rounded-xl bg-[#C9A227] hover:bg-[#DBB535] text-[#0A1F44] font-oswald font-bold text-xs uppercase tracking-wider transition">
                    <span>Browse Files</span>
                    <input
                      type="file"
                      className="hidden"
                      accept=".pdf,.docx,.doc,.txt"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) simulateResumeParse(file.name);
                      }}
                    />
                  </label>

                  <button
                    type="button"
                    onClick={() => simulateResumeParse('Marcus_Vance_Industrial_Resume_2026.pdf')}
                    className="px-4 py-2 rounded-xl bg-[#13336E] hover:bg-[#1E4383] text-[#C9A227] border border-[#C9A227]/40 font-oswald font-semibold text-xs uppercase tracking-wider transition flex items-center gap-1.5"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Auto-Parse Sample Resume</span>
                  </button>
                </div>

                {resumeParsing && (
                  <div className="mt-4 p-3 bg-[#13336E]/60 rounded-lg inline-flex items-center gap-2 text-xs font-oswald text-[#C9A227]">
                    <span className="w-4 h-4 border-2 border-[#C9A227] border-t-transparent rounded-full animate-spin"></span>
                    <span>Parsing work history, employers, dates, and trade skills...</span>
                  </div>
                )}

                {formData.resumeFileName && !resumeParsing && (
                  <div className="mt-4 inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-oswald">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>
                      Stored File: <strong>{formData.resumeFileName}</strong> (Saved to Vault)
                    </span>
                  </div>
                )}
              </div>

              {/* REVIEW AND CORRECT SCREEN */}
              <div className="bg-[#06132B] p-5 rounded-xl border border-[#1E4383] space-y-4">
                <div className="flex items-center justify-between border-b border-[#1E4383] pb-2">
                  <div>
                    <h4 className="font-poppins font-bold text-white text-sm flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-[#C9A227]" />
                      <span>Review & Correct: Parsed Skills</span>
                    </h4>
                    <p className="text-[11px] font-oswald text-white/60">
                      Click '✕' to remove or add additional tags that match your certifications.
                    </p>
                  </div>
                </div>

                {/* Skills tags */}
                <div className="flex flex-wrap gap-2">
                  {formData.skills.map((skill) => (
                    <span
                      key={skill}
                      className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-[#13336E] text-white font-oswald text-xs border border-[#1E4383]"
                    >
                      <span>{skill}</span>
                      <button
                        onClick={() => handleRemoveSkill(skill)}
                        className="text-white/60 hover:text-rose-400 text-xs ml-1"
                      >
                        ✕
                      </button>
                    </span>
                  ))}
                </div>

                {/* Add new skill inline */}
                <div className="flex gap-2">
                  <input
                    type="text"
                    id="newSkillInput"
                    placeholder="Add custom trade skill (e.g. Overhead Crane, CNC, First Aid)..."
                    className="flex-1 px-3 py-1.5 bg-[#0A1F44] border border-[#1E4383] rounded-lg text-white font-oswald text-xs outline-none focus:border-[#C9A227]"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddSkill((e.target as HTMLInputElement).value);
                        (e.target as HTMLInputElement).value = '';
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => {
                      const input = document.getElementById('newSkillInput') as HTMLInputElement;
                      if (input && input.value) {
                        handleAddSkill(input.value);
                        input.value = '';
                      }
                    }}
                    className="px-3 py-1.5 bg-[#C9A227] hover:bg-[#DBB535] text-[#0A1F44] font-oswald font-bold text-xs uppercase rounded-lg"
                  >
                    Add Skill
                  </button>
                </div>
              </div>

              {/* REVIEW AND CORRECT WORK HISTORY */}
              <div className="bg-[#06132B] p-5 rounded-xl border border-[#1E4383] space-y-4">
                <div className="flex items-center justify-between border-b border-[#1E4383] pb-2">
                  <div>
                    <h4 className="font-poppins font-bold text-white text-sm">
                      Review & Correct: Work History & Employers
                    </h4>
                    <p className="text-[11px] font-oswald text-white/60">
                      Double check parsed dates and role titles. Modify or add any jobs.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={handleAddWorkHistory}
                    className="px-2.5 py-1 rounded-lg bg-[#13336E] text-[#C9A227] border border-[#C9A227]/40 font-oswald text-xs font-semibold flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Prior Job</span>
                  </button>
                </div>

                <div className="space-y-4">
                  {formData.workHistory.map((item, idx) => (
                    <div
                      key={item.id}
                      className="p-4 rounded-xl bg-[#0A1F44] border border-[#1E4383] space-y-3 relative"
                    >
                      <button
                        type="button"
                        onClick={() => handleDeleteWorkHistory(item.id)}
                        className="absolute top-3 right-3 text-white/40 hover:text-rose-400 p-1"
                        title="Delete this job entry"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div>
                          <label className="block text-[11px] font-oswald uppercase text-white/70 mb-1">
                            Employer / Facility
                          </label>
                          <input
                            type="text"
                            value={item.employer}
                            onChange={(e) =>
                              handleUpdateWorkHistory(item.id, 'employer', e.target.value)
                            }
                            className="w-full px-2.5 py-1.5 bg-[#06132B] border border-[#1E4383] rounded text-white font-oswald text-xs"
                            placeholder="e.g. Piedmont Distribution Hub"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-oswald uppercase text-white/70 mb-1">
                            Role / Job Title
                          </label>
                          <input
                            type="text"
                            value={item.role}
                            onChange={(e) =>
                              handleUpdateWorkHistory(item.id, 'role', e.target.value)
                            }
                            className="w-full px-2.5 py-1.5 bg-[#06132B] border border-[#1E4383] rounded text-white font-oswald text-xs"
                            placeholder="e.g. Senior Materials Handler"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-oswald uppercase text-white/70 mb-1">
                            Location (City, State)
                          </label>
                          <input
                            type="text"
                            value={item.location}
                            onChange={(e) =>
                              handleUpdateWorkHistory(item.id, 'location', e.target.value)
                            }
                            className="w-full px-2.5 py-1.5 bg-[#06132B] border border-[#1E4383] rounded text-white font-oswald text-xs"
                            placeholder="Atlanta, GA"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="block text-[11px] font-oswald uppercase text-white/70 mb-1">
                              Start Date
                            </label>
                            <input
                              type="text"
                              value={item.startDate}
                              onChange={(e) =>
                                handleUpdateWorkHistory(item.id, 'startDate', e.target.value)
                              }
                              className="w-full px-2.5 py-1.5 bg-[#06132B] border border-[#1E4383] rounded text-white font-oswald text-xs"
                              placeholder="2023-03"
                            />
                          </div>
                          <div>
                            <label className="block text-[11px] font-oswald uppercase text-white/70 mb-1">
                              End Date
                            </label>
                            <input
                              type="text"
                              value={item.endDate}
                              onChange={(e) =>
                                handleUpdateWorkHistory(item.id, 'endDate', e.target.value)
                              }
                              className="w-full px-2.5 py-1.5 bg-[#06132B] border border-[#1E4383] rounded text-white font-oswald text-xs"
                              placeholder="2026-08 (or Present)"
                            />
                          </div>
                        </div>
                        <div>
                          <label className="block text-[11px] font-oswald uppercase text-white/70 mb-1">
                            Key Equipment & Responsibilities
                          </label>
                          <textarea
                            rows={2}
                            value={item.responsibilities}
                            onChange={(e) =>
                              handleUpdateWorkHistory(item.id, 'responsibilities', e.target.value)
                            }
                            className="w-full px-2.5 py-1.5 bg-[#06132B] border border-[#1E4383] rounded text-white font-oswald text-xs"
                            placeholder="High reach forklift operations, pallet jack, staging..."
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* STEP 3: JOB INTERESTS FOR RECRUITER MATCHING */}
          {step === 3 && (
            <div className="space-y-5">
              <div className="border-b border-[#1E4383] pb-3">
                <h3 className="font-poppins text-lg font-bold text-white">
                  Step 3: Placement Preferences & Shift Availability
                </h3>
                <p className="font-oswald text-xs text-white/70">
                  These choices feed our direct matchmaking algorithm so recruiters only propose
                  shifts that fit your schedule, pay expectations, and commute radius.
                </p>
              </div>

              {/* Industry / Role Selection */}
              <div>
                <label className="block text-xs font-poppins font-bold uppercase text-[#C9A227] tracking-wider mb-2">
                  Industries & Roles of Interest (Select all that apply) *
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
                  {[
                    'Warehouse & Distribution',
                    'Assembly & Manufacturing',
                    'Forklift & Heavy Equipment Operations',
                    'Quality Inspection & Testing',
                    'Event & Hospitality Staffing',
                    'Packaging & Fulfillment',
                    'General Labor & Staging',
                    'Cleanroom & Medical Packaging',
                    'Logistics & Cross-Dock Dispatch',
                  ].map((role) => {
                    const isChecked = formData.industryInterests.includes(role);
                    return (
                      <button
                        key={role}
                        type="button"
                        onClick={() => {
                          const nextInterests = isChecked
                            ? formData.industryInterests.filter((r) => r !== role)
                            : [...formData.industryInterests, role];
                          setFormData({ ...formData, industryInterests: nextInterests });
                        }}
                        className={`p-3 rounded-xl border text-left text-xs font-oswald transition flex items-center justify-between ${
                          isChecked
                            ? 'bg-[#13336E] border-[#C9A227] text-white font-bold shadow'
                            : 'bg-[#06132B] border-[#1E4383] text-white/70 hover:text-white'
                        }`}
                      >
                        <span>{role}</span>
                        {isChecked && <CheckCircle2 className="w-4 h-4 text-[#C9A227]" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Shift Preferences */}
              <div>
                <label className="block text-xs font-poppins font-bold uppercase text-[#C9A227] tracking-wider mb-2">
                  Preferred Shifts *
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {[
                    '1st Shift (Day)',
                    '2nd Shift (Swing)',
                    '3rd Shift (Graveyard)',
                    'Weekend Only',
                  ].map((shiftName) => {
                    const isChecked = formData.shiftPreferences.includes(shiftName);
                    return (
                      <button
                        key={shiftName}
                        type="button"
                        onClick={() => {
                          const nextShifts = isChecked
                            ? formData.shiftPreferences.filter((s) => s !== shiftName)
                            : [...formData.shiftPreferences, shiftName];
                          setFormData({ ...formData, shiftPreferences: nextShifts });
                        }}
                        className={`p-3 rounded-xl border text-center text-xs font-oswald uppercase tracking-wider transition ${
                          isChecked
                            ? 'bg-[#C9A227] text-[#0A1F44] font-bold border-[#C9A227]'
                            : 'bg-[#06132B] border-[#1E4383] text-white/70 hover:text-white'
                        }`}
                      >
                        {shiftName}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Hourly Rate & Commute Radius */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-[#06132B] p-4 rounded-xl border border-[#1E4383]">
                <div>
                  <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                    Minimum Desired Hourly Rate ($/hr)
                  </label>
                  <div className="flex items-center gap-3">
                    <input
                      type="number"
                      step="0.5"
                      min="15"
                      max="75"
                      value={formData.minHourlyRate}
                      onChange={(e) =>
                        setFormData({ ...formData, minHourlyRate: parseFloat(e.target.value) || 20 })
                      }
                      className="w-28 px-3 py-2 bg-[#0A1F44] border border-[#1E4383] rounded-lg text-white font-oswald text-base font-bold focus:border-[#C9A227] outline-none"
                    />
                    <span className="text-xs font-oswald text-white/60">
                      Standard agency base is $20.00 – $28.00/hr
                    </span>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                    Commute Radius: {formData.commuteRadiusMiles} Miles
                  </label>
                  <input
                    type="range"
                    min="5"
                    max="50"
                    step="5"
                    value={formData.commuteRadiusMiles}
                    onChange={(e) =>
                      setFormData({ ...formData, commuteRadiusMiles: parseInt(e.target.value) })
                    }
                    className="w-full accent-[#C9A227] cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] font-oswald text-white/50 mt-1">
                    <span>5 mi</span>
                    <span>25 mi</span>
                    <span>50 mi</span>
                  </div>
                </div>
              </div>

              {/* Transportation questions */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <label className="flex items-center gap-3 p-3 bg-[#06132B] rounded-xl border border-[#1E4383] cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.hasOwnTransportation}
                    onChange={(e) =>
                      setFormData({ ...formData, hasOwnTransportation: e.target.checked })
                    }
                    className="w-4 h-4 accent-[#C9A227]"
                  />
                  <span className="text-xs font-oswald text-white">
                    I have reliable personal transportation (car / motorcycle)
                  </span>
                </label>

                <label className="flex items-center gap-3 p-3 bg-[#06132B] rounded-xl border border-[#1E4383] cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.willingToTravel}
                    onChange={(e) =>
                      setFormData({ ...formData, willingToTravel: e.target.checked })
                    }
                    className="w-4 h-4 accent-[#C9A227]"
                  />
                  <span className="text-xs font-oswald text-white">
                    Willing to travel for regional client projects with per diem
                  </span>
                </label>
              </div>
            </div>
          )}

          {/* STEP 4: TAX & VERIFICATION (W-4, I-9, PHOTO ID) */}
          {step === 4 && (
            <div className="space-y-6">
              <div className="border-b border-[#1E4383] pb-3">
                <h3 className="font-poppins text-lg font-bold text-white">
                  Step 4: Statutory Tax Forms (W-4) & Federal Employment Eligibility (I-9)
                </h3>
                <p className="font-oswald text-xs text-white/70">
                  Completed in-app with digital signatures. Secure 256-bit encryption.
                </p>
              </div>

              {/* CRITICAL NOTE: DOCUMENTS GET CHECKED LIVE ON VIDEO CALL */}
              <div className="p-4 rounded-xl bg-[#0A1F44] border-2 border-[#C9A227] flex items-start gap-3 shadow-lg">
                <ShieldCheck className="w-6 h-6 text-[#C9A227] flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-poppins font-bold text-sm text-[#C9A227] uppercase tracking-wide">
                    Mandatory Live Video Verification Requirement
                  </h4>
                  <p className="text-xs font-oswald text-white/90 mt-0.5">
                    <strong>Note:</strong> Upload photos of your unexpired identity documents below.
                    Federal USCIS regulations require your identity documents to be held up and
                    physically checked live during your scheduled 1-on-1 video call with our
                    placement recruiter before your final roster activation.
                  </p>
                </div>
              </div>

              {/* FORM W-4 SECTION */}
              <div className="bg-[#06132B] p-5 rounded-xl border border-[#1E4383] space-y-4">
                <div className="flex items-center justify-between border-b border-[#1E4383] pb-2">
                  <h4 className="font-poppins font-bold text-white text-sm">
                    IRS Form W-4 (Employee's Withholding Certificate)
                  </h4>
                  <span className="text-[11px] font-oswald text-[#C9A227]">Tax Year 2026</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] font-oswald uppercase text-white/70 mb-1">
                      Filing Status *
                    </label>
                    <select
                      value={formData.w4FilingStatus}
                      onChange={(e) =>
                        setFormData({ ...formData, w4FilingStatus: e.target.value as any })
                      }
                      className="w-full px-3 py-2 bg-[#0A1F44] border border-[#1E4383] rounded-lg text-white font-oswald text-xs"
                    >
                      <option value="Single">Single or Married filing separately</option>
                      <option value="Married">Married filing jointly</option>
                      <option value="Head of Household">Head of household</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-oswald uppercase text-white/70 mb-1">
                      Number of Dependents Claimed
                    </label>
                    <input
                      type="number"
                      min="0"
                      max="10"
                      value={formData.w4DependentsClaimed}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          w4DependentsClaimed: parseInt(e.target.value) || 0,
                        })
                      }
                      className="w-full px-3 py-2 bg-[#0A1F44] border border-[#1E4383] rounded-lg text-white font-oswald text-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-oswald uppercase text-white/70 mb-1">
                      Extra Withholding Per Paycheck ($)
                    </label>
                    <input
                      type="number"
                      min="0"
                      value={formData.w4ExtraWithholding}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          w4ExtraWithholding: parseFloat(e.target.value) || 0,
                        })
                      }
                      className="w-full px-3 py-2 bg-[#0A1F44] border border-[#1E4383] rounded-lg text-white font-oswald text-xs"
                    />
                  </div>
                </div>

                {/* Digital Signature for W-4 */}
                <div className="p-3 bg-[#0A1F44] rounded-lg border border-[#1E4383] grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-oswald uppercase text-[#C9A227] mb-1 font-semibold">
                      Digital Signature for Form W-4 (Type Full Name) *
                    </label>
                    <input
                      type="text"
                      value={formData.w4Signature}
                      onChange={(e) => setFormData({ ...formData, w4Signature: e.target.value })}
                      placeholder="e.g. Marcus Vance"
                      className="w-full px-3 py-1.5 bg-[#06132B] border border-[#1E4383] rounded text-white font-oswald text-sm italic"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-oswald uppercase text-white/70 mb-1">
                      Signature Date
                    </label>
                    <input
                      type="date"
                      value={formData.w4SignDate || new Date().toISOString().split('T')[0]}
                      onChange={(e) => setFormData({ ...formData, w4SignDate: e.target.value })}
                      className="w-full px-3 py-1.5 bg-[#06132B] border border-[#1E4383] rounded text-white font-oswald text-xs"
                    />
                  </div>
                </div>
              </div>

              {/* FORM I-9 SECTION */}
              <div className="bg-[#06132B] p-5 rounded-xl border border-[#1E4383] space-y-4">
                <div className="flex items-center justify-between border-b border-[#1E4383] pb-2">
                  <h4 className="font-poppins font-bold text-white text-sm">
                    USCIS Form I-9 (Employment Eligibility Verification - Section 1)
                  </h4>
                  <span className="text-[11px] font-oswald text-[#C9A227]">Form OMB No. 1615-0047</span>
                </div>

                <div>
                  <label className="block text-xs font-oswald uppercase text-white/80 mb-2">
                    I attest, under penalty of perjury, that I am (select one): *
                  </label>
                  <div className="space-y-2">
                    {[
                      { key: 'citizen', label: '1. A citizen of the United States' },
                      {
                        key: 'noncitizen',
                        label: '2. A noncitizen national of the United States (as defined in 8 U.S.C. 1101(a)(22))',
                      },
                      {
                        key: 'permanent_resident',
                        label: '3. A lawful permanent resident (USCIS/Alien Registration Number)',
                      },
                      {
                        key: 'authorized_alien',
                        label: '4. An alien authorized to work with an expiration date',
                      },
                    ].map((attest) => (
                      <label
                        key={attest.key}
                        className={`flex items-start gap-2.5 p-2.5 rounded-lg border text-xs font-oswald cursor-pointer transition ${
                          formData.i9CitizenshipStatus === attest.key
                            ? 'bg-[#13336E] border-[#C9A227] text-white font-semibold'
                            : 'bg-[#0A1F44] border-[#1E4383] text-white/70 hover:text-white'
                        }`}
                      >
                        <input
                          type="radio"
                          name="i9Status"
                          checked={formData.i9CitizenshipStatus === attest.key}
                          onChange={() =>
                            setFormData({
                              ...formData,
                              i9CitizenshipStatus: attest.key as any,
                            })
                          }
                          className="mt-0.5 accent-[#C9A227]"
                        />
                        <span>{attest.label}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Digital Signature for I-9 */}
                <div className="p-3 bg-[#0A1F44] rounded-lg border border-[#1E4383] grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-oswald uppercase text-[#C9A227] mb-1 font-semibold">
                      Digital Signature for Form I-9 *
                    </label>
                    <input
                      type="text"
                      value={formData.i9Signature}
                      onChange={(e) => setFormData({ ...formData, i9Signature: e.target.value })}
                      placeholder="Type legal signature"
                      className="w-full px-3 py-1.5 bg-[#06132B] border border-[#1E4383] rounded text-white font-oswald text-sm italic"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-oswald uppercase text-white/70 mb-1">
                      Attestation Date
                    </label>
                    <input
                      type="date"
                      value={formData.i9SignDate || new Date().toISOString().split('T')[0]}
                      onChange={(e) => setFormData({ ...formData, i9SignDate: e.target.value })}
                      className="w-full px-3 py-1.5 bg-[#06132B] border border-[#1E4383] rounded text-white font-oswald text-xs"
                    />
                  </div>
                </div>
              </div>

              {/* PHOTO UPLOAD SLOTS FOR ID DOCUMENTS */}
              <div className="bg-[#06132B] p-5 rounded-xl border border-[#1E4383] space-y-4">
                <h4 className="font-poppins font-bold text-white text-sm flex items-center gap-2">
                  <Camera className="w-4 h-4 text-[#C9A227]" />
                  <span>Photo Upload Slots for ID Documents</span>
                </h4>
                <p className="text-[11px] font-oswald text-white/60">
                  Acceptable List A (US Passport) or List B + C (Driver's License / State ID + Social
                  Security Card). Snap photo or upload clear color image.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Slot 1: Primary ID */}
                  <div className="border border-[#1E4383] bg-[#0A1F44] p-4 rounded-xl flex flex-col justify-between">
                    <div>
                      <span className="text-xs font-poppins font-bold text-[#C9A227] block mb-1">
                        Primary ID (e.g. Driver's License / State ID)
                      </span>
                      <p className="text-[11px] font-oswald text-white/60 mb-3">
                        {formData.idDocumentUploaded
                          ? `Uploaded: ${formData.idDocumentName || 'State_DL_Photo.jpg'}`
                          : 'No photo selected yet'}
                      </p>
                    </div>

                    <label className="cursor-pointer py-2 px-3 rounded-lg bg-[#13336E] hover:bg-[#1E4383] text-white border border-[#C9A227]/30 text-center font-oswald text-xs uppercase flex items-center justify-center gap-1.5 transition">
                      <Camera className="w-3.5 h-3.5 text-[#C9A227]" />
                      <span>
                        {formData.idDocumentUploaded ? 'Replace Photo' : 'Upload ID Photo'}
                      </span>
                      <input
                        type="file"
                        accept="image/*,.pdf"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            setFormData({
                              ...formData,
                              idDocumentUploaded: true,
                              idDocumentName: file.name,
                            });
                          }
                        }}
                      />
                    </label>
                  </div>

                  {/* Slot 2: Secondary Document (SSN or Birth Cert) */}
                  <div className="border border-[#1E4383] bg-[#0A1F44] p-4 rounded-xl flex flex-col justify-between">
                    <div>
                      <span className="text-xs font-poppins font-bold text-[#C9A227] block mb-1">
                        Secondary Verification (e.g. Social Security Card)
                      </span>
                      <p className="text-[11px] font-oswald text-white/60 mb-3">
                        {formData.secondaryDocumentUploaded
                          ? `Uploaded: ${formData.secondaryDocumentName || 'SSN_Card_Photo.jpg'}`
                          : 'No photo selected yet'}
                      </p>
                    </div>

                    <label className="cursor-pointer py-2 px-3 rounded-lg bg-[#13336E] hover:bg-[#1E4383] text-white border border-[#C9A227]/30 text-center font-oswald text-xs uppercase flex items-center justify-center gap-1.5 transition">
                      <Camera className="w-3.5 h-3.5 text-[#C9A227]" />
                      <span>
                        {formData.secondaryDocumentUploaded ? 'Replace Photo' : 'Upload Secondary ID'}
                      </span>
                      <input
                        type="file"
                        accept="image/*,.pdf"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            setFormData({
                              ...formData,
                              secondaryDocumentUploaded: true,
                              secondaryDocumentName: file.name,
                            });
                          }
                        }}
                      />
                    </label>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* STEP 5: CONSENTS, EACH WITH ITS OWN SIGNATURE */}
          {step === 5 && (
            <div className="space-y-6">
              <div className="border-b border-[#1E4383] pb-3">
                <h3 className="font-poppins text-lg font-bold text-white">
                  Step 5: Agency Consents & Disclosures (Individual Signatures)
                </h3>
                <p className="font-oswald text-xs text-white/70">
                  Each consent below requires its own individual digital signature and timestamp.
                </p>
              </div>

              {/* 1. Background Check */}
              <div className="bg-[#06132B] p-4 rounded-xl border border-[#1E4383] space-y-3">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-[#C9A227]" />
                  <h4 className="font-poppins font-bold text-sm text-white">
                    1. Criminal Background Check Authorization (FCRA Compliant)
                  </h4>
                </div>
                <p className="text-xs font-oswald text-white/70 leading-relaxed">
                  I hereby authorize Employ Avenue Staffing and its designated background screening agents
                  to obtain consumer reports and criminal history checks in connection with my
                  staffing placement application. I understand I have rights under the Fair Credit
                  Reporting Act.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <div>
                    <label className="block text-[11px] font-oswald uppercase text-[#C9A227] mb-1">
                      Individual Digital Signature *
                    </label>
                    <input
                      type="text"
                      value={formData.backgroundSignature}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          backgroundSignature: e.target.value,
                          consentBackgroundCheck: Boolean(e.target.value),
                        })
                      }
                      placeholder="Type full legal name"
                      className="w-full px-3 py-1.5 bg-[#0A1F44] border border-[#1E4383] rounded text-white font-oswald text-sm italic"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-oswald uppercase text-white/70 mb-1">
                      Date
                    </label>
                    <input
                      type="date"
                      value={formData.backgroundSignDate || new Date().toISOString().split('T')[0]}
                      onChange={(e) =>
                        setFormData({ ...formData, backgroundSignDate: e.target.value })
                      }
                      className="w-full px-3 py-1.5 bg-[#0A1F44] border border-[#1E4383] rounded text-white font-oswald text-xs"
                    />
                  </div>
                </div>
              </div>

              {/* 2. Drug Test Consent */}
              <div className="bg-[#06132B] p-4 rounded-xl border border-[#1E4383] space-y-3">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-[#C9A227]" />
                  <h4 className="font-poppins font-bold text-sm text-white">
                    2. Pre-Employment & Random Drug & Alcohol Testing Consent
                  </h4>
                </div>
                <p className="text-xs font-oswald text-white/70 leading-relaxed">
                  I agree to submit to pre-placement and random safety drug/alcohol screenings in
                  accordance with Employ Avenue Staffing Substance Abuse Prevention Policy and client site
                  regulations.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <div>
                    <label className="block text-[11px] font-oswald uppercase text-[#C9A227] mb-1">
                      Individual Digital Signature *
                    </label>
                    <input
                      type="text"
                      value={formData.drugTestSignature}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          drugTestSignature: e.target.value,
                          consentDrugTest: Boolean(e.target.value),
                        })
                      }
                      placeholder="Type full legal name"
                      className="w-full px-3 py-1.5 bg-[#0A1F44] border border-[#1E4383] rounded text-white font-oswald text-sm italic"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-oswald uppercase text-white/70 mb-1">
                      Date
                    </label>
                    <input
                      type="date"
                      value={formData.drugTestSignDate || new Date().toISOString().split('T')[0]}
                      onChange={(e) =>
                        setFormData({ ...formData, drugTestSignDate: e.target.value })
                      }
                      className="w-full px-3 py-1.5 bg-[#0A1F44] border border-[#1E4383] rounded text-white font-oswald text-xs"
                    />
                  </div>
                </div>
              </div>

              {/* 3. No-Fees Acknowledgment */}
              <div className="bg-[#06132B] p-4 rounded-xl border border-[#1E4383] space-y-3">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-[#C9A227]" />
                  <h4 className="font-poppins font-bold text-sm text-white">
                    3. No Placement Fees Acknowledgment
                  </h4>
                </div>
                <p className="text-xs font-oswald text-white/70 leading-relaxed">
                  I acknowledge and confirm that Employ Avenue Staffing NEVER charges any applicant or
                  worker any placement fees, recruitment charges, or mandatory payroll deductions
                  for job assignments. All fees are 100% paid by the employer clients.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <div>
                    <label className="block text-[11px] font-oswald uppercase text-[#C9A227] mb-1">
                      Individual Digital Signature *
                    </label>
                    <input
                      type="text"
                      value={formData.noFeesSignature}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          noFeesSignature: e.target.value,
                          consentNoFees: Boolean(e.target.value),
                        })
                      }
                      placeholder="Type full legal name"
                      className="w-full px-3 py-1.5 bg-[#0A1F44] border border-[#1E4383] rounded text-white font-oswald text-sm italic"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-oswald uppercase text-white/70 mb-1">
                      Date
                    </label>
                    <input
                      type="date"
                      value={formData.noFeesSignDate || new Date().toISOString().split('T')[0]}
                      onChange={(e) =>
                        setFormData({ ...formData, noFeesSignDate: e.target.value })
                      }
                      className="w-full px-3 py-1.5 bg-[#0A1F44] border border-[#1E4383] rounded text-white font-oswald text-xs"
                    />
                  </div>
                </div>
              </div>

              {/* 4. Agency Policies & Safety Code */}
              <div className="bg-[#06132B] p-4 rounded-xl border border-[#1E4383] space-y-3">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-[#C9A227]" />
                  <h4 className="font-poppins font-bold text-sm text-white">
                    4. Agency Safety Code of Conduct & Shift Attendance Policies
                  </h4>
                </div>
                <p className="text-xs font-oswald text-white/70 leading-relaxed">
                  I commit to adhering to the Employ Avenue Staffing Code of Conduct: mandatory PPE wear
                  (steel-toe boots, vests), reporting late tickets at least 30 minutes before shift,
                  and immediately filing incident reports in this portal upon any near-miss or
                  hazard.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <div>
                    <label className="block text-[11px] font-oswald uppercase text-[#C9A227] mb-1">
                      Individual Digital Signature *
                    </label>
                    <input
                      type="text"
                      value={formData.policiesSignature}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          policiesSignature: e.target.value,
                          consentAgencyPolicies: Boolean(e.target.value),
                        })
                      }
                      placeholder="Type full legal name"
                      className="w-full px-3 py-1.5 bg-[#0A1F44] border border-[#1E4383] rounded text-white font-oswald text-sm italic"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-oswald uppercase text-white/70 mb-1">
                      Date
                    </label>
                    <input
                      type="date"
                      value={formData.policiesSignDate || new Date().toISOString().split('T')[0]}
                      onChange={(e) =>
                        setFormData({ ...formData, policiesSignDate: e.target.value })
                      }
                      className="w-full px-3 py-1.5 bg-[#0A1F44] border border-[#1E4383] rounded text-white font-oswald text-xs"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* STEP 6: REVIEW EVERYTHING & FINAL SUBMISSION */}
          {step === 6 && (
            <div className="space-y-6">
              <div className="border-b border-[#1E4383] pb-3">
                <h3 className="font-poppins text-lg font-bold text-white">
                  Step 6: Comprehensive Review & Official Submission
                </h3>
                <p className="font-oswald text-xs text-white/70">
                  Carefully review your information. Submitting flips your pipeline tracker to
                  <strong className="text-[#C9A227]"> "Applied"</strong> and initiates background
                  verification.
                </p>
              </div>

              {/* Summary Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Step 1 review */}
                <div className="bg-[#06132B] p-4 rounded-xl border border-[#1E4383]">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-xs font-poppins font-bold text-[#C9A227] uppercase">
                      1. Contact & Identity
                    </span>
                    <button
                      onClick={() => setStep(1)}
                      className="text-[11px] font-oswald text-white/60 hover:text-white underline"
                    >
                      Edit
                    </button>
                  </div>
                  <p className="font-oswald text-sm text-white font-semibold">
                    {formData.firstName} {formData.lastName} ({formData.preferredName})
                  </p>
                  <p className="font-oswald text-xs text-white/70">{formData.phone}</p>
                  <p className="font-oswald text-xs text-white/70">{formData.email}</p>
                  <p className="font-oswald text-xs text-white/70">
                    {formData.address}, {formData.city}, {formData.state} {formData.zipCode}
                  </p>
                  <p className="font-oswald text-xs text-emerald-400 mt-1">
                    ✓ SMS Dispatch Consent Active
                  </p>
                </div>

                {/* Step 2 review */}
                <div className="bg-[#06132B] p-4 rounded-xl border border-[#1E4383]">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-xs font-poppins font-bold text-[#C9A227] uppercase">
                      2. Resume & Skills
                    </span>
                    <button
                      onClick={() => setStep(2)}
                      className="text-[11px] font-oswald text-white/60 hover:text-white underline"
                    >
                      Edit
                    </button>
                  </div>
                  <p className="font-oswald text-xs text-white/80">
                    File: <strong>{formData.resumeFileName || 'Stored On Profile'}</strong>
                  </p>
                  <div className="mt-2 flex flex-wrap gap-1">
                    {formData.skills.slice(0, 4).map((s) => (
                      <span
                        key={s}
                        className="px-2 py-0.5 rounded bg-[#13336E] text-[11px] font-oswald text-white"
                      >
                        {s}
                      </span>
                    ))}
                    {formData.skills.length > 4 && (
                      <span className="text-[10px] text-white/50">
                        +{formData.skills.length - 4} more
                      </span>
                    )}
                  </div>
                  <p className="font-oswald text-xs text-white/70 mt-2">
                    {formData.workHistory.length} Prior Employment Records
                  </p>
                </div>

                {/* Step 3 review */}
                <div className="bg-[#06132B] p-4 rounded-xl border border-[#1E4383]">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-xs font-poppins font-bold text-[#C9A227] uppercase">
                      3. Job Preferences
                    </span>
                    <button
                      onClick={() => setStep(3)}
                      className="text-[11px] font-oswald text-white/60 hover:text-white underline"
                    >
                      Edit
                    </button>
                  </div>
                  <p className="font-oswald text-xs text-white/80">
                    Min Rate: <strong>${formData.minHourlyRate.toFixed(2)}/hr</strong> • Radius:{' '}
                    <strong>{formData.commuteRadiusMiles} miles</strong>
                  </p>
                  <div className="mt-1 text-xs font-oswald text-white/70">
                    Shifts: {formData.shiftPreferences.join(', ')}
                  </div>
                  <div className="text-xs font-oswald text-white/70">
                    Interests: {formData.industryInterests.slice(0, 2).join(', ')}...
                  </div>
                </div>

                {/* Step 4 & 5 review */}
                <div className="bg-[#06132B] p-4 rounded-xl border border-[#1E4383]">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-xs font-poppins font-bold text-[#C9A227] uppercase">
                      4 & 5. Tax Forms & Consents
                    </span>
                    <button
                      onClick={() => setStep(4)}
                      className="text-[11px] font-oswald text-white/60 hover:text-white underline"
                    >
                      Edit
                    </button>
                  </div>
                  <div className="space-y-1 text-xs font-oswald text-white/80">
                    <div className="flex items-center gap-1.5 text-emerald-400">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Form W-4 Signed ({formData.w4Signature || 'Recorded'})</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-emerald-400">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Form I-9 Signed ({formData.i9Signature || 'Recorded'})</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-emerald-400">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>
                        4 Agency Consents Digitally Signed (Background, Drug, No-Fees, Policies)
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 text-[#C9A227]">
                      <AlertCircle className="w-3.5 h-3.5" />
                      <span>Photo ID Ready for Live Video Check</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Official Attestation before Final Submit */}
              <div className="p-4 bg-[#06132B] rounded-xl border border-[#C9A227]/40 text-center">
                <p className="text-xs font-oswald text-white/90">
                  By clicking <strong>"Submit Application"</strong>, you certify that all statements
                  contained in this application are true and complete. Your application will be
                  transmitted to Employ Avenue Staffing Placement Coordinators.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Modal Bottom Footer: Back, Save & Close, Continue / Submit */}
        <div className="bg-[#06132B] px-6 py-4 border-t border-[#1E4383] flex flex-col sm:flex-row items-center justify-between gap-3">
          <button
            type="button"
            onClick={handleSaveAndClose}
            className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-[#0A1F44] hover:bg-[#13336E] border border-[#1E4383] text-white/90 font-oswald font-semibold text-xs uppercase tracking-wider transition flex items-center justify-center gap-2"
          >
            <Save className="w-4 h-4 text-[#C9A227]" />
            <span>Save & Close (Resume Anytime)</span>
          </button>

          <div className="w-full sm:w-auto flex items-center gap-2">
            {step > 1 && (
              <button
                type="button"
                onClick={handleBack}
                className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl bg-[#13336E] hover:bg-[#1E4383] text-white font-oswald font-semibold text-xs uppercase tracking-wider transition flex items-center justify-center gap-1.5"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back</span>
              </button>
            )}

            {step < 6 ? (
              <button
                type="button"
                onClick={handleContinue}
                className="flex-1 sm:flex-none px-6 py-2.5 rounded-xl bg-[#C9A227] hover:bg-[#DBB535] text-[#0A1F44] font-horizon font-bold text-xs uppercase tracking-wider transition flex items-center justify-center gap-1.5 shadow-md shadow-[#C9A227]/20"
              >
                <span>Continue</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                type="button"
                onClick={handleSubmit}
                className="flex-1 sm:flex-none px-8 py-2.5 rounded-xl bg-gradient-to-r from-[#C9A227] to-[#DBB535] hover:from-[#DBB535] hover:to-[#C9A227] text-[#0A1F44] font-horizon font-bold text-sm uppercase tracking-wider transition flex items-center justify-center gap-2 shadow-lg shadow-[#C9A227]/30"
              >
                <CheckCircle2 className="w-5 h-5" />
                <span>Submit Application</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
