import React, { useState, useEffect, useRef } from 'react';
import { useWorkforce } from '../../context/WorkforceContext';
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  MessageSquare,
  Check,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  Send,
  Languages,
  ShieldCheck,
  Lock,
} from 'lucide-react';

interface GoalStep {
  id: string;
  textEn: string;
  textEs: string;
}

interface SherpaGoal {
  id: string;
  type: 'long-term' | 'short-term';
  titleEn: string;
  titleEs: string;
  totalSteps: number;
  completedSteps: number;
  steps: GoalStep[];
  celebrationMessageEn: string;
  celebrationMessageEs: string;
}

export type SherpaPose = 'idle' | 'wave' | 'thinking' | 'coaching' | 'celebrating';

export interface SherpaPoseInfo {
  src: string;
  alt: string;
  labelEn: string;
  labelEs: string;
  tagEn: string;
  tagEs: string;
  badgeBg: string;
  accentColor: string;
}

export const SHERPA_POSES: Record<SherpaPose, SherpaPoseInfo> = {
  idle: {
    src: '/assets/aistudio/Business_Avatar_Cartoon_Woman_2bbcfed5.png',
    alt: 'Sherpa warm smile ready to guide Marcus',
    labelEn: 'Ready & Focused',
    labelEs: 'Lista y atenta',
    tagEn: 'Active Guide',
    tagEs: 'Guía Activa',
    badgeBg: 'bg-emerald-600',
    accentColor: '#10B981',
  },
  wave: {
    src: '/assets/aistudio/Business_Avatar_Cartoon_Woman__4__33cf7a8d.png',
    alt: 'Sherpa waving hello to Marcus',
    labelEn: 'Welcoming Marcus',
    labelEs: 'Saludando a Marcus',
    tagEn: 'Welcome!',
    tagEs: '¡Hola Marcus!',
    badgeBg: 'bg-[#C9A227]',
    accentColor: '#C9A227',
  },
  thinking: {
    src: '/assets/aistudio/Business_Avatar_Cartoon_Woman__3__8958355d.png',
    alt: 'Sherpa with hand on chin actively listening and planning',
    labelEn: 'Listening & Thinking...',
    labelEs: 'Escuchando y pensando...',
    tagEn: 'Listening...',
    tagEs: 'Pensando...',
    badgeBg: 'bg-indigo-600',
    accentColor: '#6366F1',
  },
  coaching: {
    src: '/assets/aistudio/Business_Avatar_Cartoon_Woman__1__76cf7fd7.png',
    alt: 'Sherpa holding notebook advising next career actions',
    labelEn: 'Coaching & Explaining',
    labelEs: 'Asesorando con tu plan',
    tagEn: 'Coaching',
    tagEs: 'Asesorando',
    badgeBg: 'bg-blue-600',
    accentColor: '#2563EB',
  },
  celebrating: {
    src: '/assets/aistudio/Business_Avatar_Cartoon_Woman__2__df505e42.png',
    alt: 'Sherpa giving double thumbs up celebrating Marcus milestone',
    labelEn: 'Celebrating your milestone!',
    labelEs: '¡Celebrando tu logro!',
    tagEn: 'Milestone Won! 🎉',
    tagEs: '¡Meta Lograda! 🎉',
    badgeBg: 'bg-amber-500',
    accentColor: '#F59E0B',
  },
};

interface ChatMessage {
  id: string;
  sender: 'user' | 'sherpa';
  text: string;
  time: string;
}

export const CareerGuide: React.FC = () => {
  // 1. Language state synchronized with top bar (English default)
  const { language, setLanguage } = useWorkforce();
  const lang = language;
  const setLang = (newLang: 'en' | 'es' | ((prev: 'en' | 'es') => 'en' | 'es')) => {
    if (typeof newLang === 'function') {
      setLanguage(newLang(language));
    } else {
      setLanguage(newLang);
    }
  };

  // 2. Sherpa Character Pose State & Controller
  const [currentPose, setCurrentPose] = useState<SherpaPose>('wave');
  const poseTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const triggerPose = (pose: SherpaPose, durationMs = 3500) => {
    if (poseTimeoutRef.current) {
      clearTimeout(poseTimeoutRef.current);
    }
    setCurrentPose(pose);
    if (pose !== 'idle' && durationMs > 0) {
      poseTimeoutRef.current = setTimeout(() => {
        setCurrentPose('idle');
      }, durationMs);
    }
  };

  // Preload character pose images on mount and ease into idle after initial greeting
  useEffect(() => {
    Object.values(SHERPA_POSES).forEach((item) => {
      const img = new Image();
      img.src = item.src;
    });

    // Wave for 3.5 seconds on initial load, then transition to idle
    poseTimeoutRef.current = setTimeout(() => {
      setCurrentPose('idle');
    }, 3500);

    return () => {
      if (poseTimeoutRef.current) {
        clearTimeout(poseTimeoutRef.current);
      }
    };
  }, []);

  // 3. Voice & Audio states
  const [isListening, setIsListening] = useState(false);
  const [voiceOutEnabled, setVoiceOutEnabled] = useState(true);
  const [isSpeaking, setIsSpeaking] = useState(false);

  // 4. Sherpa Speech Bubble text (top header)
  const [sherpaBubbleText, setSherpaBubbleText] = useState({
    en: "Hey Marcus! I'm Sherpa, your career & life guide. Every shift you work is building toward your next big milestone. What's our focus today?",
    es: '¡Hola Marcus! Soy Sherpa, tu guía de carrera y vida. Cada turno que trabajas construye tu próximo gran objetivo. ¿En qué nos enfocamos hoy?',
  });

  // 4. Sample goals data for Marcus exactly as specified
  const [goals, setGoals] = useState<SherpaGoal[]>([
    {
      id: 'lt-forklift',
      type: 'long-term',
      titleEn: 'Get my forklift certification',
      titleEs: 'Obtener mi certificación de montacargas',
      totalSteps: 4,
      completedSteps: 2,
      steps: [
        {
          id: 'fk-1',
          textEn: 'Review OSHA industrial materials handling fundamentals',
          textEs: 'Revisar los fundamentos de manejo de materiales de OSHA',
        },
        {
          id: 'fk-2',
          textEn: 'Pass facility safety checklist evaluation',
          textEs: 'Aprobar la evaluación de seguridad de la instalación',
        },
        {
          id: 'fk-3',
          textEn: 'Book the certification class for a Saturday morning.',
          textEs: 'Reservar la clase de certificación para un sábado por la mañana.',
        },
        {
          id: 'fk-4',
          textEn: 'Attend practical driving exam and receive operator badge',
          textEs: 'Asistir al examen práctico y recibir la credencial de operador',
        },
      ],
      celebrationMessageEn:
        'Outstanding achievement, Marcus! You finished all steps and unlocked your Forklift Operator Certification! Higher tier roles are now open to you.',
      celebrationMessageEs:
        '¡Logro sobresaliente, Marcus! ¡Completaste todos los pasos y desbloqueaste tu Certificación de Montacargas! Puestos de mayor nivel están listos para ti.',
    },
    {
      id: 'lt-car',
      type: 'long-term',
      titleEn: 'Save for a reliable car',
      titleEs: 'Ahorrar para un auto confiable',
      totalSteps: 5,
      completedSteps: 1,
      steps: [
        {
          id: 'car-1',
          textEn: 'Open dedicated car savings fund account',
          textEs: 'Abrir una cuenta de ahorros dedicada para el auto',
        },
        {
          id: 'car-2',
          textEn: "Put $40 from this week's pay into savings.",
          textEs: 'Poner $40 del pago de esta semana en ahorros.',
        },
        {
          id: 'car-3',
          textEn: 'Compare reliable certified pre-owned options and insurance quotes',
          textEs: 'Comparar opciones seminuevas confiables y cotizaciones de seguro',
        },
        {
          id: 'car-4',
          textEn: 'Reach 80% of vehicle purchase and title reserve',
          textEs: 'Alcanzar el 80% del fondo para compra y título',
        },
        {
          id: 'car-5',
          textEn: 'Finalize vehicle inspection and secure reliable personal commute',
          textEs: 'Finalizar la inspección y asegurar tu transporte personal independiente',
        },
      ],
      celebrationMessageEn:
        "Huge victory, Marcus! You reached your savings goal for a reliable car. Commute freedom means you can take any top-paying shift anytime!",
      celebrationMessageEs:
        '¡Gran victoria, Marcus! Lograste tu meta de ahorro para un auto confiable. ¡La independencia de transporte te permite tomar cualquier turno!',
    },
    {
      id: 'st-attendance',
      type: 'short-term',
      titleEn: 'Two weeks of perfect attendance',
      titleEs: 'Dos semanas de asistencia perfecta',
      totalSteps: 10,
      completedSteps: 6,
      steps: [
        { id: 'att-1', textEn: 'Shift 1 on-time punch', textEs: 'Turno 1 a tiempo' },
        { id: 'att-2', textEn: 'Shift 2 on-time punch', textEs: 'Turno 2 a tiempo' },
        { id: 'att-3', textEn: 'Shift 3 on-time punch', textEs: 'Turno 3 a tiempo' },
        { id: 'att-4', textEn: 'Shift 4 on-time punch', textEs: 'Turno 4 a tiempo' },
        { id: 'att-5', textEn: 'Shift 5 on-time punch', textEs: 'Turno 5 a tiempo' },
        { id: 'att-6', textEn: 'Shift 6 on-time punch', textEs: 'Turno 6 a tiempo' },
        {
          id: 'att-7',
          textEn: "Confirm tomorrow's 6 AM shift.",
          textEs: 'Confirmar el turno de mañana a las 6 AM.',
        },
        { id: 'att-8', textEn: 'Shift 8 on-time punch', textEs: 'Turno 8 a tiempo' },
        { id: 'att-9', textEn: 'Shift 9 on-time punch', textEs: 'Turno 9 a tiempo' },
        {
          id: 'att-10',
          textEn: 'Clock final shift to complete 10/10 perfect attendance streak',
          textEs: 'Registrar el último turno para completar la racha 10/10',
        },
      ],
      celebrationMessageEn:
        'Boom! 10 out of 10 shifts on time. Perfect attendance logged! Supervisors notice this first when picking team leads.',
      celebrationMessageEs:
        '¡Excelente! 10 de 10 turnos a tiempo. ¡Asistencia perfecta registrada! Los supervisores valoran esto al elegir líderes de equipo.',
    },
    {
      id: 'st-documents',
      type: 'short-term',
      titleEn: 'Finish my profile documents',
      titleEs: 'Completar los documentos de mi perfil',
      totalSteps: 3,
      completedSteps: 2,
      steps: [
        {
          id: 'doc-1',
          textEn: 'Complete electronic W-4 withholdings form',
          textEs: 'Completar el formulario de retención W-4 electrónico',
        },
        {
          id: 'doc-2',
          textEn: 'Sign Form I-9 employment eligibility section',
          textEs: 'Firmar la sección de elegibilidad de empleo del Formulario I-9',
        },
        {
          id: 'doc-3',
          textEn: 'Upload a photo of my ID.',
          textEs: 'Subir una foto de mi identificación.',
        },
      ],
      celebrationMessageEn:
        'Way to go, Marcus! Your profile documentation is 100% finished. Zero administrative holds on your roster status!',
      celebrationMessageEs:
        '¡Muy bien, Marcus! La documentación de tu perfil está 100% completa. ¡Cero retenciones administrativas en tu estado!',
    },
  ]);

  // 5. Topic chat row states
  type TopicKey = 'work' | 'money' | 'goals';
  const [activeTopic, setActiveTopic] = useState<TopicKey>('work');
  const [moneyConsentGranted, setMoneyConsentGranted] = useState(false);
  const [topicInput, setTopicInput] = useState('');
  const chatBottomRef = useRef<HTMLDivElement>(null);
  const chatSectionRef = useRef<HTMLDivElement>(null);

  const [topicThreads, setTopicThreads] = useState<Record<TopicKey, ChatMessage[]>>({
    work: [
      {
        id: 'w-1',
        sender: 'sherpa',
        text: 'Your attendance consistency is great this month. Showing up reliably puts you directly in line for machine operation and lead roles. How did today feel on the floor?',
        time: '9:15 AM',
      },
    ],
    money: [
      {
        id: 'm-1',
        sender: 'sherpa',
        text: 'Saving consistently each week creates true breathing room. We can build toward your vehicle fund step by step without stressing your daily routine.',
        time: '9:20 AM',
      },
    ],
    goals: [
      {
        id: 'g-1',
        sender: 'sherpa',
        text: 'Focusing on one small next step every morning turns big multi-month dreams into real achievements. Which goal feels most urgent today?',
        time: '9:25 AM',
      },
    ],
  });

  // 6. Ref trackers for No-Repeat Rotation & Thread Memory
  const lastVariantRef = useRef<Record<string, number>>({});
  const askedIntentsRef = useRef<Set<string>>(new Set());
  const lastGreetingIndexRef = useRef<number>(-1);

  // Calculate overall achievement across ALL goals
  const totalStepsAll = goals.reduce((acc, g) => acc + g.totalSteps, 0);
  const completedStepsAll = goals.reduce((acc, g) => acc + g.completedSteps, 0);
  const overallPercentage = Math.round((completedStepsAll / (totalStepsAll || 1)) * 100);

  // Text-to-speech voice readout helper
  const speakText = (text: string) => {
    if (!voiceOutEnabled || typeof window === 'undefined' || !('speechSynthesis' in window)) {
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = lang === 'es' ? 'es-ES' : 'en-US';
    utterance.rate = 1.0;
    utterance.pitch = 1.05;
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    window.speechSynthesis.speak(utterance);
  };

  // Trigger speech when message changes if voice output is active
  useEffect(() => {
    const currentMessage = lang === 'es' ? sherpaBubbleText.es : sherpaBubbleText.en;
    speakText(currentMessage);
  }, [sherpaBubbleText, lang, voiceOutEnabled]);

  // Dynamic Greeting Generator for speech bubble (varies on state & never repeats twice in a row)
  const generateDynamicGreeting = (currentGoals: SherpaGoal[]) => {
    const forklift = currentGoals.find((g) => g.id === 'lt-forklift') || currentGoals[0];
    const car = currentGoals.find((g) => g.id === 'lt-car') || currentGoals[1];
    const attendance = currentGoals.find((g) => g.id === 'st-attendance') || currentGoals[2];
    const docs = currentGoals.find((g) => g.id === 'st-documents') || currentGoals[3];

    const totSteps = currentGoals.reduce((acc, g) => acc + g.totalSteps, 0);
    const compSteps = currentGoals.reduce((acc, g) => acc + g.completedSteps, 0);
    const overallPct = Math.round((compSteps / (totSteps || 1)) * 100);

    const completedGoal = currentGoals.find((g) => g.completedSteps >= g.totalSteps);

    const pool: { en: string; es: string }[] = [];

    if (completedGoal) {
      pool.push({
        en: `Hey Marcus! Outstanding victory on completing "${completedGoal.titleEn}"! Your overall progress is at ${overallPct}%. What's our next target?`,
        es: `¡Hola Marcus! ¡Victoria sobresaliente al completar "${completedGoal.titleEs}"! Tu progreso general está en ${overallPct}%. ¿Cuál es nuestro siguiente objetivo?`,
      });
    }

    if (attendance && attendance.completedSteps > 0) {
      const streakCount = attendance.completedSteps;
      const attNextStepEn = attendance.steps[attendance.completedSteps]?.textEn || 'Maintain streak';
      const attNextStepEs = attendance.steps[attendance.completedSteps]?.textEs || 'Mantener la racha';
      pool.push({
        en: `Hey Marcus! Your attendance streak is looking strong at ${streakCount}/10 shifts (${Math.round((streakCount / 10) * 100)}%). Next step: "${attNextStepEn}".`,
        es: `¡Hola Marcus! Tu racha de asistencia luce impecable con ${streakCount}/10 turnos (${Math.round((streakCount / 10) * 100)}%). Siguiente paso: "${attNextStepEs}".`,
      });
    }

    const fkNextEn = forklift.steps[forklift.completedSteps]?.textEn || 'Certification complete';
    const fkNextEs = forklift.steps[forklift.completedSteps]?.textEs || 'Certificación completada';
    pool.push({
      en: `Hey Marcus! You're at ${overallPct}% overall achievement. Priority next step for forklift: "${fkNextEn}". Ready to tackle it?`,
      es: `¡Hola Marcus! Estás al ${overallPct}% de logro general. Paso prioritario de montacargas: "${fkNextEs}". ¿Listo para abordarlo?`,
    });

    const carNextEn = car.steps[car.completedSteps]?.textEn || 'Vehicle fund complete';
    const carNextEs = car.steps[car.completedSteps]?.textEs || 'Fondo de auto completado';
    pool.push({
      en: `Welcome Marcus! Overall progress is at ${overallPct}%. Your car savings next step: "${carNextEn}". Every shift brings you closer!`,
      es: `¡Bienvenido Marcus! Tu progreso general está al ${overallPct}%. Tu siguiente paso de ahorro para auto: "${carNextEs}". ¡Cada turno suma!`,
    });

    let nextIdx = (lastGreetingIndexRef.current + 1) % pool.length;
    if (nextIdx === lastGreetingIndexRef.current && pool.length > 1) {
      nextIdx = (nextIdx + 1) % pool.length;
    }
    lastGreetingIndexRef.current = nextIdx;

    return pool[nextIdx];
  };

  // Dynamic Journey Summary generated strictly from current goals state
  const getDynamicJourneySummary = () => {
    const forklift = goals.find((g) => g.id === 'lt-forklift');
    const car = goals.find((g) => g.id === 'lt-car');
    const attendance = goals.find((g) => g.id === 'st-attendance');
    const docs = goals.find((g) => g.id === 'st-documents');

    const forkliftDone = (forklift?.completedSteps || 0) >= (forklift?.totalSteps || 4);
    const carDone = (car?.completedSteps || 0) >= (car?.totalSteps || 5);
    const attendanceDone = (attendance?.completedSteps || 0) >= (attendance?.totalSteps || 10);
    const docsDone = (docs?.completedSteps || 0) >= (docs?.totalSteps || 3);

    const allDone = forkliftDone && carDone && attendanceDone && docsDone;

    if (lang === 'es') {
      if (allDone) {
        return 'Marcus ha completado exitosamente todas sus metas de carrera y personales. Está plenamente certificado, cuenta con transporte propio y tiene un récord de confiabilidad impecable para cualquier oportunidad de liderazgo.';
      }
      let whereNow = 'Marcus trabaja turnos constantes en logística ';
      if (docsDone && attendanceDone) {
        whereNow += 'con su documentación completa y una racha de asistencia perfecta registrada.';
      } else if (docsDone) {
        whereNow += 'con todos sus documentos en orden y una sólida racha de asistencia en marcha.';
      } else {
        whereNow += 'mientras avanza en sus registros de asistencia y verificación de documentos.';
      }

      let whereGoing = ' En el camino por delante, ';
      if (forkliftDone && carDone) {
        whereGoing += 'ha alcanzado sus dos metas principales y se proyecta hacia la supervisión de turno.';
      } else if (forkliftDone) {
        whereGoing += 'ha obtenido su certificación de montacargas y enfoca sus pasos restantes en completar su fondo para un auto confiable.';
      } else if (carDone) {
        whereGoing += 'ha asegurado su meta para el auto y se enfoca en completar su certificación práctica de montacargas.';
      } else {
        whereGoing += 'se prepara para su clase de montacargas de fin de semana y destina ahorros regulares para adquirir su auto independiente.';
      }

      return whereNow + whereGoing;
    }

    // English version
    if (allDone) {
      return 'Marcus has accomplished every milestone across his career and life roadmap. Fully certified, transport-independent, and holding a flawless reliability record, he is primed for site lead opportunities.';
    }

    let whereNow = 'Marcus is currently maintaining a steady logistics shift record ';
    if (docsDone && attendanceDone) {
      whereNow += 'with 100% of his compliance paperwork verified and two weeks of perfect attendance secured.';
    } else if (docsDone) {
      whereNow += 'with all profile documentation finalized and a strong on-time shift streak underway.';
    } else {
      whereNow += 'while advancing through his daily shift attendance and onboarding verification.';
    }

    let whereGoing = ' On the road ahead, ';
    if (forkliftDone && carDone) {
      whereGoing += 'he has achieved both long-term benchmarks and is looking toward shift lead advancement.';
    } else if (forkliftDone) {
      whereGoing += 'he has unlocked his forklift credentials and is directing his focus toward finishing his reliable car savings reserve.';
    } else if (carDone) {
      whereGoing += 'his vehicle fund is achieved, and he is driving toward final certified forklift operator status.';
    } else {
      whereGoing += 'he is booking his Saturday forklift certification and steadily setting aside weekly savings for personal commute independence.';
    }

    return whereNow + whereGoing;
  };

  // Complete one next step for a goal
  const handleCompleteNextStep = (goalId: string) => {
    setGoals((prev) => {
      const updated = prev.map((g) => {
        if (g.id !== goalId) return g;
        if (g.completedSteps >= g.totalSteps) return g;

        const nextCompleted = g.completedSteps + 1;
        const isNowFinished = nextCompleted === g.totalSteps;

        if (isNowFinished) {
          triggerPose('celebrating', 6000);
          setSherpaBubbleText({
            en: g.celebrationMessageEn,
            es: g.celebrationMessageEs,
          });
        } else {
          triggerPose('celebrating', 3500);
          setSherpaBubbleText({
            en: `Step logged, Marcus! Progress on "${g.titleEn}" is moving forward. Next action is ready.`,
            es: `¡Paso registrado, Marcus! El progreso en "${g.titleEs}" avanza con firmeza. La siguiente acción está lista.`,
          });
        }

        return {
          ...g,
          completedSteps: nextCompleted,
        };
      });

      return updated;
    });
  };

  // Simulated Voice Input action
  const handleToggleVoiceInput = () => {
    if (isListening) {
      setIsListening(false);
      triggerPose('idle');
      return;
    }

    setIsListening(true);
    triggerPose('thinking', 3200);
    setSherpaBubbleText({
      en: 'Listening... (Speak your question, comment or goal update)',
      es: 'Escuchando... (Haz tu pregunta, comentario o actualización de meta)',
    });

    setTimeout(() => {
      setIsListening(false);
      triggerPose('coaching', 4000);
      const forklift = goals.find((g) => g.id === 'lt-forklift') || goals[0];
      const fkPct = Math.round((forklift.completedSteps / forklift.totalSteps) * 100);
      const fkNext = forklift.steps[forklift.completedSteps]?.textEn || 'Complete certification';
      const fkNextEs = forklift.steps[forklift.completedSteps]?.textEs || 'Completar certificación';

      const voiceReplies = [
        {
          en: `I heard you, Marcus! You're at ${fkPct}% on your forklift goal. Next step: "${fkNext}". Let's lock it in!`,
          es: `¡Te escuché, Marcus! Estás al ${fkPct}% en tu meta de montacargas. Siguiente paso: "${fkNextEs}". ¡Vamos a asegurarlo!`,
        },
        {
          en: `Got it! Overall achievement is at ${overallPercentage}%. Focus on: "${fkNext}". You've got this!`,
          es: `¡Entendido! Tu logro general está al ${overallPercentage}%. Enfoque en: "${fkNextEs}". ¡Tú puedes!`,
        },
      ];
      const picked = voiceReplies[Math.floor(Math.random() * voiceReplies.length)];
      setSherpaBubbleText(picked);
    }, 2800);
  };

  // Scroll to topic chat section
  const handleChatButtonClick = () => {
    chatSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  // Helper to pick next non-repeating variant index for an intent key
  const getNextVariantIndex = (intentKey: string, totalVariants: number) => {
    const lastIdx = lastVariantRef.current[intentKey] ?? -1;
    let nextIdx = Math.floor(Math.random() * totalVariants);
    if (nextIdx === lastIdx && totalVariants > 1) {
      nextIdx = (nextIdx + 1) % totalVariants;
    }
    lastVariantRef.current[intentKey] = nextIdx;
    return nextIdx;
  };

  // Send message in active topic thread (Sherpa responds like a regular person with proportional responses)
  const handleSendTopicMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!topicInput.trim()) return;

    const userMsg = topicInput.trim();
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    setTopicThreads((prev) => ({
      ...prev,
      [activeTopic]: [
        ...prev[activeTopic],
        { id: `u-${Date.now()}`, sender: 'user', text: userMsg, time },
      ],
    }));
    setTopicInput('');

    // Trigger thinking/listening briefly while reading
    triggerPose('thinking', 1400);

    setTimeout(() => {
      const lower = userMsg.toLowerCase().trim();
      const cleanLower = lower.replace(/[.,\/#!$%\^&\*;:{}=\-_`~()?]/g, '').trim();

      const forklift = goals.find((g) => g.id === 'lt-forklift') || goals[0];
      const car = goals.find((g) => g.id === 'lt-car') || goals[1];
      const attendance = goals.find((g) => g.id === 'st-attendance') || goals[2];
      const docs = goals.find((g) => g.id === 'st-documents') || goals[3];

      const getPct = (g: SherpaGoal) => Math.round((g.completedSteps / (g.totalSteps || 1)) * 100);
      const getNextStepStr = (g: SherpaGoal, isEs: boolean) => {
        if (g.completedSteps >= g.totalSteps) {
          return isEs ? '¡Meta completada!' : 'Goal completed!';
        }
        const st = g.steps[g.completedSteps];
        return isEs ? st?.textEs : st?.textEn;
      };

      const sortedByProgress = [...goals].sort((a, b) => getPct(b) - getPct(a));
      const topGoal = sortedByProgress[0];

      let intentKey = '';
      let replyText = '';
      let chosenPose: SherpaPose = 'idle';

      // 1. SIMPLE CASUAL GREETING ("hey", "hi", "hello", "yo", "sup", "good morning", "hola", "buenas")
      const isGreeting = /^(hey|hi|hello|howdy|yo|sup|good morning|morning|good afternoon|good evening|hola|buenas|buenos dias|buenos días|buenas tardes|buenas noches|que tal|q tal|ey)(\s+(sherpa|there|marcus|girl))?$/i.test(cleanLower);

      // 2. CASUAL "HOW ARE YOU" / SMALL TALK ("how are you", "how's it going", "how you doing", "como estas")
      const isHowAreYou = /(how are you|how're you|hows it going|how's it going|how you doing|whats up|what's up|how are things|como estas|cómo estás|como te va|cómo te va|que tal todo)/i.test(lower);

      // 3. CASUAL ACKNOWLEDGMENT ("ok", "cool", "got it", "sounds good", "alright", "entendido", "vale")
      const isCasualAck = /^(ok|okay|cool|nice|got it|sounds good|deal|alright|all right|perfect|sure|yep|yes|si|sí|bien|entendido|de acuerdo|vale|sale|perfecto)$/i.test(cleanLower);

      // 4. CASUAL THANKS ("thanks", "thank you", "thx", "appreciate it", "gracias")
      const isThanks = /^(thanks|thank you|thx|appreciate it|much appreciated|gracias|muchas gracias|te lo agradezco)$/i.test(cleanLower) || /(thanks|thank you|gracias)/i.test(cleanLower) && cleanLower.split(' ').length <= 4;

      // 5. CASUAL GOODBYES ("bye", "see you", "good night", "adios", "hasta luego")
      const isGoodbye = /^(bye|goodbye|see you|see ya|later|good night|goodnight|adios|adiós|hasta luego|chao|nos vemos|buenas noches)$/i.test(cleanLower);

      // 6. CASUAL MOOD / EMOTION CHECK-IN ("tired", "rough day", "long shift", "feeling good", "cansado", "pesado")
      const isTiredOrRough = /(tired|exhausted|rough day|long shift|hard day|drained|stressed|cansado|agotado|dia pesado|día pesado|turno largo|estresado)/i.test(lower);
      const isFeelingGood = /(feeling good|great day|good day|energized|ready|me siento bien|buen dia|buen día|con ganas)/i.test(lower);

      // --- ROUTING: REGULAR PERSON RESPONSES FIRST ---

      if (isGreeting) {
        intentKey = 'greeting';
        chosenPose = 'wave';
        const vIdx = getNextVariantIndex(intentKey, 3);
        const variants = [
          {
            en: 'Hey Marcus! How are you doing today?',
            es: '¡Hola Marcus! ¿Cómo estás hoy?',
          },
          {
            en: "Hi Marcus! What's on your mind?",
            es: '¡Hola Marcus! ¿Qué tienes en mente?',
          },
          {
            en: "Hey there! Good to see you. How's everything going?",
            es: '¡Hola! Qué gusto saludarte. ¿Cómo va todo?',
          },
        ];
        replyText = lang === 'es' ? variants[vIdx].es : variants[vIdx].en;
      }
      else if (isHowAreYou) {
        intentKey = 'how_are_you';
        chosenPose = 'idle';
        const vIdx = getNextVariantIndex(intentKey, 3);
        const variants = [
          {
            en: "I'm doing great, thanks for asking! How are you holding up today?",
            es: '¡Muy bien, gracias por preguntar! ¿Cómo van las cosas contigo hoy?',
          },
          {
            en: "Doing well! Just here and ready to help whenever you need. How's your day treating you?",
            es: '¡Todo muy bien! Aquí lista para ayudarte cuando lo necesites. ¿Cómo te trata el día?',
          },
          {
            en: "Can't complain! Ready for whatever you want to tackle. How are you feeling?",
            es: '¡No me quejo! Lista para lo que quieras revisar. ¿Cómo te sientes?',
          },
        ];
        replyText = lang === 'es' ? variants[vIdx].es : variants[vIdx].en;
      }
      else if (isCasualAck) {
        intentKey = 'casual_ack';
        chosenPose = 'idle';
        const vIdx = getNextVariantIndex(intentKey, 3);
        const variants = [
          {
            en: "Sounds like a plan!",
            es: "¡De acuerdo!",
          },
          {
            en: "You got it, Marcus.",
            es: "¡Entendido, Marcus!",
          },
          {
            en: "Perfect, I'm right here whenever you're ready.",
            es: "Perfecto, aquí estoy cuando estés listo.",
          },
        ];
        replyText = lang === 'es' ? variants[vIdx].es : variants[vIdx].en;
      }
      else if (isThanks) {
        intentKey = 'thanks';
        chosenPose = 'idle';
        const vIdx = getNextVariantIndex(intentKey, 3);
        const variants = [
          {
            en: "Anytime, Marcus! Let me know if you need anything.",
            es: "¡De nada, Marcus! Avísame si necesitas cualquier cosa.",
          },
          {
            en: "You got it! Always happy to help.",
            es: "¡Con gusto! Siempre es un placer ayudarte.",
          },
          {
            en: "No problem at all! Have a great one.",
            es: "¡No hay de qué! Que tengas un excelente día.",
          },
        ];
        replyText = lang === 'es' ? variants[vIdx].es : variants[vIdx].en;
      }
      else if (isGoodbye) {
        intentKey = 'goodbye';
        chosenPose = 'wave';
        const vIdx = getNextVariantIndex(intentKey, 2);
        const variants = [
          {
            en: "See you later, Marcus! Take care out there.",
            es: "¡Hasta luego, Marcus! Cuídate mucho.",
          },
          {
            en: "Catch you later, Marcus! Have a good one.",
            es: "¡Nos vemos luego, Marcus! Que te vaya muy bien.",
          },
        ];
        replyText = lang === 'es' ? variants[vIdx].es : variants[vIdx].en;
      }
      else if (isTiredOrRough) {
        intentKey = 'empathy_tired';
        chosenPose = 'idle';
        const vIdx = getNextVariantIndex(intentKey, 2);
        const variants = [
          {
            en: "I hear you. Long shifts take a lot out of you—make sure to get some solid rest tonight, you earned it.",
            es: "Te entiendo. Los turnos largos cansan de verdad; asegúrate de descansar bien esta noche, te lo ganaste.",
          },
          {
            en: "Rough days happen on the floor. Take it easy this evening and recharge. Don't worry about goals right now.",
            es: "Hay días pesados en el trabajo. Tómalo con calma esta tarde y recarga energías. No te preocupes por metas ahora.",
          },
        ];
        replyText = lang === 'es' ? variants[vIdx].es : variants[vIdx].en;
      }
      else if (isFeelingGood) {
        intentKey = 'feeling_good';
        chosenPose = 'celebrating';
        const vIdx = getNextVariantIndex(intentKey, 2);
        const variants = [
          {
            en: "Love to hear that, Marcus! That positive energy goes a long way.",
            es: "¡Me da mucho gusto escuchar eso, Marcus! Esa buena energía hace una gran diferencia.",
          },
          {
            en: "Awesome! Great days like this make everything smoother. Let me know if you want to look at your roadmap or just keep rolling.",
            es: "¡Genial! Días así hacen que todo fluya mejor. Dime si quieres revisar tu plan o simplemente seguir adelante.",
          },
        ];
        replyText = lang === 'es' ? variants[vIdx].es : variants[vIdx].en;
      }

      // --- CONTEXT DICTATES SPECIFICS: USER ASKS OR REPORTS AN ACTION ---

      // 7. Money topic + consent toggle OFF (when user asks about pay specifically)
      else if (activeTopic === 'money' && !moneyConsentGranted && /(pay|wage|stub|rate|dollar|salary|money|income|sueldo|pago|dinero|ganancia|monto)/i.test(lower)) {
        intentKey = 'money_no_consent';
        chosenPose = 'coaching';
        const vIdx = getNextVariantIndex(intentKey, 2);
        const variants = [
          {
            en: "Your pay stub toggle is currently turned off, so I can't look at pay figures. If you want specific numbers, you can switch it on above!",
            es: "El permiso para ver recibos de pago está desactivado, así que no veo cifras de sueldo. ¡Si quieres números exactos, puedes activarlo arriba!",
          },
          {
            en: "I don't have access to your pay stubs right now with the consent toggle off. You can flip it on above anytime if you'd like tailored calculations.",
            es: "No tengo acceso a tus recibos de pago con el permiso desactivado. Puedes activarlo arriba cuando quieras para cálculos personalizados.",
          },
        ];
        replyText = lang === 'es' ? variants[vIdx].es : variants[vIdx].en;
      }
      // 8. User reports an achievement ("I saved $40", "class is booked", "I did it", "uploaded my id")
      else if (/(saved|booked|completed|done|finished|i did it|punched|uploaded|logre|logré|hice|listo|guarde|guardé|reserve|reservé|subi|subí)/i.test(lower)) {
        intentKey = 'achievement_report';
        chosenPose = 'celebrating';

        let targetGoal = forklift;
        if (/(forklift|cert|osha|class|saturday|montacargas|clase|sabado|sábado)/i.test(lower)) targetGoal = forklift;
        else if (/(car|vehicle|auto|save|savings|40|ahorrar|coche|dinero)/i.test(lower)) targetGoal = car;
        else if (/(attendance|streak|shift|punch|tomorrow|6 am|asistencia|turno|racha)/i.test(lower)) targetGoal = attendance;
        else if (/(document|doc|id|w-4|i-9|photo|documento|identificacion|identificación|perfil)/i.test(lower)) targetGoal = docs;
        else {
          targetGoal = goals.find((g) => g.completedSteps < g.totalSteps) || forklift;
        }

        let updatedNextStepEn = '';
        let updatedNextStepEs = '';
        let updatedGoalPct = 0;
        let updatedOverallPct = 0;

        setGoals((prev) => {
          return prev.map((g) => {
            if (g.id !== targetGoal.id) return g;
            if (g.completedSteps >= g.totalSteps) return g;

            const nextComp = g.completedSteps + 1;
            const updatedG = { ...g, completedSteps: nextComp };

            updatedGoalPct = getPct(updatedG);
            updatedNextStepEn = getNextStepStr(updatedG, false);
            updatedNextStepEs = getNextStepStr(updatedG, true);

            return updatedG;
          });
        });

        const newCompTotal = completedStepsAll + 1;
        updatedOverallPct = Math.round((newCompTotal / (totalStepsAll || 1)) * 100);

        const vIdx = getNextVariantIndex(intentKey, 3);
        const goalTitleEn = targetGoal.titleEn;
        const goalTitleEs = targetGoal.titleEs;

        const variants = [
          {
            en: `Nice job, Marcus! I marked that step complete for "${goalTitleEn}". You're at ${updatedGoalPct}% now. Next up: "${updatedNextStepEn}".`,
            es: `¡Muy bien, Marcus! Marqué ese paso como listo para "${goalTitleEs}". Ya vas al ${updatedGoalPct}%. Lo siguiente: "${updatedNextStepEs}".`,
          },
          {
            en: `Great follow-through! Step logged on "${goalTitleEn}". That puts this goal at ${updatedGoalPct}%. Next step: "${updatedNextStepEn}".`,
            es: `¡Excelente seguimiento! Paso registrado en "${goalTitleEs}". Eso pone esta meta al ${updatedGoalPct}%. Siguiente paso: "${updatedNextStepEs}".`,
          },
          {
            en: `Awesome! Checked off on "${goalTitleEn}". You're moving forward (${updatedOverallPct}% overall now). Your new next step is: "${updatedNextStepEn}".`,
            es: `¡Genial! Marcado en "${goalTitleEs}". Sigues avanzando (${updatedOverallPct}% general ahora). Tu nuevo paso es: "${updatedNextStepEs}".`,
          },
        ];

        replyText = lang === 'es' ? variants[vIdx].es : variants[vIdx].en;

        setSherpaBubbleText({
          en: `Milestone step logged for "${goalTitleEn}"! Overall achievement reached ${updatedOverallPct}%.`,
          es: `¡Paso registrado para "${goalTitleEs}"! El logro general alcanzó el ${updatedOverallPct}%.`,
        });
      }
      // 9. User asks about a SPECIFIC GOAL: Forklift
      else if (/(forklift|cert|osha|montacargas)/i.test(lower)) {
        intentKey = 'goal_forklift';
        chosenPose = 'coaching';
        const pct = getPct(forklift);
        const nextStep = getNextStepStr(forklift, lang === 'es');
        const vIdx = getNextVariantIndex(intentKey, 3);
        const variants = [
          {
            en: `You're at ${pct}% on your forklift certification. Next step is: "${getNextStepStr(forklift, false)}". Need any help with it?`,
            es: `Estás al ${pct}% en tu certificación de montacargas. El siguiente paso es: "${getNextStepStr(forklift, true)}". ¿Necesitas ayuda con eso?`,
          },
          {
            en: `For your forklift goal, you've knocked out ${forklift.completedSteps} of ${forklift.totalSteps} steps (${pct}%). Right now, the focus is: "${getNextStepStr(forklift, false)}".`,
            es: `Para el montacargas llevas ${forklift.completedSteps} de ${forklift.totalSteps} pasos (${pct}%). Ahora mismo el enfoque es: "${getNextStepStr(forklift, true)}".`,
          },
          {
            en: `Forklift progress is sitting at ${pct}%. Your next action is: "${getNextStepStr(forklift, false)}". It's a great step toward higher pay rates.`,
            es: `El avance de montacargas está en ${pct}%. Tu siguiente acción es: "${getNextStepStr(forklift, true)}". Es un paso clave hacia mejores tarifas.`,
          },
        ];
        replyText = lang === 'es' ? variants[vIdx].es : variants[vIdx].en;
      }
      // 10. User asks about a SPECIFIC GOAL: Car
      else if (/(car|vehicle|auto|savings|ahorrar|coche)/i.test(lower)) {
        intentKey = 'goal_car';
        chosenPose = 'coaching';
        const pct = getPct(car);
        const vIdx = getNextVariantIndex(intentKey, 3);
        const variants = [
          {
            en: `You're at ${pct}% on your reliable car fund. Next step: "${getNextStepStr(car, false)}". Steady weekly habits get you there.`,
            es: `Estás al ${pct}% en tu fondo para el auto. Siguiente paso: "${getNextStepStr(car, true)}". El hábito semanal te llevará a la meta.`,
          },
          {
            en: `For the car, you've completed ${car.completedSteps} of ${car.totalSteps} steps (${pct}%). Next up: "${getNextStepStr(car, false)}".`,
            es: `Para el auto llevas ${car.completedSteps} de ${car.totalSteps} pasos (${pct}%). Lo siguiente: "${getNextStepStr(car, true)}".`,
          },
          {
            en: `Your vehicle savings is at ${pct}%. Your current action: "${getNextStepStr(car, false)}". Every shift puts you closer to independent commute.`,
            es: `Tu ahorro de auto está al ${pct}%. Tu acción actual: "${getNextStepStr(car, true)}". Cada turno te acerca más a tu transporte propio.`,
          },
        ];
        replyText = lang === 'es' ? variants[vIdx].es : variants[vIdx].en;
      }
      // 11. User asks about a SPECIFIC GOAL: Attendance
      else if (/(attendance|streak|shift|punctual|asistencia|turno|racha)/i.test(lower)) {
        intentKey = 'goal_attendance';
        chosenPose = 'coaching';
        const pct = getPct(attendance);
        const vIdx = getNextVariantIndex(intentKey, 3);
        const variants = [
          {
            en: `Your attendance streak is at ${attendance.completedSteps}/${attendance.totalSteps} shifts (${pct}%). Next step: "${getNextStepStr(attendance, false)}".`,
            es: `Tu racha de asistencia está en ${attendance.completedSteps}/${attendance.totalSteps} turnos (${pct}%). Siguiente paso: "${getNextStepStr(attendance, true)}".`,
          },
          {
            en: `You're at ${pct}% on the attendance streak. Next action to keep it going: "${getNextStepStr(attendance, false)}".`,
            es: `Estás al ${pct}% en la racha de asistencia. Siguiente acción para mantenerla: "${getNextStepStr(attendance, true)}".`,
          },
          {
            en: `Short-term attendance is ${pct}% done. Your immediate step: "${getNextStepStr(attendance, false)}". Keep showing up strong!`,
            es: `La asistencia a corto plazo va al ${pct}%. Tu paso inmediato: "${getNextStepStr(attendance, true)}". ¡Sigue presentándote con todo!`,
          },
        ];
        replyText = lang === 'es' ? variants[vIdx].es : variants[vIdx].en;
      }
      // 12. User asks about a SPECIFIC GOAL: Documents
      else if (/(documents|doc|id|w-4|i-9|documentos|identificacion|identificación|perfil)/i.test(lower)) {
        intentKey = 'goal_documents';
        chosenPose = 'coaching';
        const pct = getPct(docs);
        const vIdx = getNextVariantIndex(intentKey, 3);
        const variants = [
          {
            en: `Your profile paperwork is at ${pct}%. Next step: "${getNextStepStr(docs, false)}".`,
            es: `Tus documentos de perfil están al ${pct}%. Siguiente paso: "${getNextStepStr(docs, true)}".`,
          },
          {
            en: `You've done ${docs.completedSteps} of ${docs.totalSteps} steps on paperwork (${pct}%). Next action: "${getNextStepStr(docs, false)}".`,
            es: `Llevas ${docs.completedSteps} de ${docs.totalSteps} pasos en documentos (${pct}%). Siguiente acción: "${getNextStepStr(docs, true)}".`,
          },
          {
            en: `Profile documents are at ${pct}%. Just one more item: "${getNextStepStr(docs, false)}", and you're 100% verified.`,
            es: `Los documentos están al ${pct}%. Solo un punto más: "${getNextStepStr(docs, true)}", y quedas 100% verificado.`,
          },
        ];
        replyText = lang === 'es' ? variants[vIdx].es : variants[vIdx].en;
      }
      // 13. USER ASKS "What's next" / "What should I do" -> List next step of each active goal, clean & proportional
      else if (/(what's next|what next|what should i do|next step|what to do|que sigue|qué sigue|que hago|qué hago|siguiente paso)/i.test(lower)) {
        intentKey = 'whats_next';
        chosenPose = 'coaching';
        const fkNext = getNextStepStr(forklift, lang === 'es');
        const carNext = getNextStepStr(car, lang === 'es');
        const attNext = getNextStepStr(attendance, lang === 'es');
        const docNext = getNextStepStr(docs, lang === 'es');

        const vIdx = getNextVariantIndex(intentKey, 2);
        const variants = [
          {
            en: `Here are your next steps right now:\n• Forklift: "${getNextStepStr(forklift, false)}"\n• Car: "${getNextStepStr(car, false)}"\n• Attendance: "${getNextStepStr(attendance, false)}"\n• Profile: "${getNextStepStr(docs, false)}"`,
            es: `Aquí están tus siguientes pasos ahora:\n• Montacargas: "${fkNext}"\n• Auto: "${carNext}"\n• Asistencia: "${attNext}"\n• Perfil: "${docNext}"`,
          },
          {
            en: `Your active next steps are:\n• Forklift -> "${getNextStepStr(forklift, false)}"\n• Car -> "${getNextStepStr(car, false)}"\n• Attendance -> "${getNextStepStr(attendance, false)}"\n• Profile -> "${getNextStepStr(docs, false)}"`,
            es: `Tus siguientes pasos activos son:\n• Montacargas -> "${fkNext}"\n• Auto -> "${carNext}"\n• Asistencia -> "${attNext}"\n• Perfil -> "${docNext}"`,
          },
        ];
        replyText = lang === 'es' ? variants[vIdx].es : variants[vIdx].en;
      }
      // 14. USER ASKS "How am I doing" / "Progress" -> Give overall % and strongest goal
      else if (/(how am i doing|how am i|progress|status|how's it going with my goals|como voy|cómo voy|progreso|estado|como estoy|cómo estoy)/i.test(lower)) {
        intentKey = 'how_am_i_doing';
        chosenPose = 'coaching';
        const topTitle = lang === 'es' ? topGoal.titleEs : topGoal.titleEn;
        const topPct = getPct(topGoal);
        const vIdx = getNextVariantIndex(intentKey, 3);
        const variants = [
          {
            en: `You're at ${overallPercentage}% overall achievement across all your goals. Your strongest right now is "${topGoal.titleEn}" at ${topPct}%.`,
            es: `Estás al ${overallPercentage}% de logro general en todas tus metas. Tu avance más fuerte ahora es "${topGoal.titleEs}" con ${topPct}%.`,
          },
          {
            en: `You've completed ${completedStepsAll} of ${totalStepsAll} steps (${overallPercentage}% overall). Leading the way is "${topGoal.titleEn}" at ${topPct}%. Solid progress!`,
            es: `Llevas ${completedStepsAll} de ${totalStepsAll} pasos completados (${overallPercentage}% general). A la cabeza va "${topGoal.titleEs}" con ${topPct}%. ¡Buen ritmo!`,
          },
          {
            en: `Overall you're at ${overallPercentage}%. "${topGoal.titleEn}" is at ${topPct}%. Let me know if you want to look at any specific one!`,
            es: `En general vas al ${overallPercentage}%. "${topGoal.titleEs}" está al ${topPct}%. ¡Dime si quieres revisar alguna en detalle!`,
          },
        ];
        replyText = lang === 'es' ? variants[vIdx].es : variants[vIdx].en;
      }
      // 15. USER ASKS FOR GENERAL ADVICE ("what do you think", "any advice", "help me")
      else if (/(advice|suggest|suggestion|recommend|what do you think|help|consejo|sugieres|opinas|ayuda)/i.test(lower)) {
        intentKey = 'advice';
        chosenPose = 'coaching';
        const fkNextEn = getNextStepStr(forklift, false);
        const fkNextEs = getNextStepStr(forklift, true);
        const vIdx = getNextVariantIndex(intentKey, 2);
        const variants = [
          {
            en: `I'd recommend focusing on your forklift certification first ("${fkNextEn}"). Getting that ticket unlocks higher-paying shift opportunities right away.`,
            es: `Te recomiendo enfocarte primero en la certificación de montacargas ("${fkNextEs}"). Esa credencial abre turnos mejor pagados de inmediato.`,
          },
          {
            en: `Small wins add up! Knocking out your profile document or confirming your shifts keeps you in good standing with zero stress. What feels easiest to knock out today?`,
            es: `¡Las pequeñas victorias suman! Completar tus documentos o confirmar tus turnos te mantiene al día sin estrés. ¿Qué te resulta más fácil hacer hoy?`,
          },
        ];
        replyText = lang === 'es' ? variants[vIdx].es : variants[vIdx].en;
      }
      // 16. GENERAL / CASUAL FALLBACK (Human-like, conversational, NO forced data dumps)
      else {
        intentKey = 'fallback';
        chosenPose = 'idle';
        const vIdx = getNextVariantIndex(intentKey, 3);
        const fallbacks = [
          {
            en: "I'm with you, Marcus. What would you like to focus on today—your shifts, savings, or career goals?",
            es: "Estoy contigo, Marcus. ¿En qué te gustaría enfocarte hoy: en tus turnos, ahorros o metas de carrera?",
          },
          {
            en: "Got it. Let me know what you'd like to work on and we'll take it step by step.",
            es: "Entendido. Dime en qué te gustaría trabajar y lo llevamos paso a paso.",
          },
          {
            en: "I hear you! What's the main thing on your mind right now?",
            es: "¡Te escucho! ¿Qué es lo principal que tienes en mente ahora?",
          },
        ];
        replyText = lang === 'es' ? fallbacks[vIdx].es : fallbacks[vIdx].en;
      }

      // Memory inside the thread: Handle repeated question intent naturally
      if (askedIntentsRef.current.has(intentKey) && ['how_am_i_doing', 'whats_next', 'goal_forklift', 'goal_car', 'goal_attendance', 'goal_documents'].includes(intentKey)) {
        const memoryPrefix = lang === 'es' ? 'Como te comentaba, ' : 'Like I mentioned, ';
        replyText = memoryPrefix + replyText;
      }
      askedIntentsRef.current.add(intentKey);

      // Trigger chosen pose
      triggerPose(chosenPose, 3500);

      // Append Sherpa reply to current active topic thread
      setTopicThreads((prev) => ({
        ...prev,
        [activeTopic]: [
          ...prev[activeTopic],
          { id: `s-${Date.now()}`, sender: 'sherpa', text: replyText, time },
        ],
      }));

      // Scroll chat to bottom
      chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 600);
  };

  const longTermGoals = goals.filter((g) => g.type === 'long-term');
  const shortTermGoals = goals.filter((g) => g.type === 'short-term');

  return (
    <div className="space-y-6 max-w-4xl mx-auto font-oswald text-[#0A1F44]">
      {/* 1. COMBINED SHERPA SHOWCASE & TOPIC CHAT HERO SECTION */}
      <section ref={chatSectionRef} className="bg-white border-2 border-slate-200 rounded-3xl p-5 sm:p-7 shadow-xl relative overflow-hidden">
        {/* Ambient background glows */}
        <div className="absolute -top-24 -left-24 w-72 h-72 bg-[#C9A227]/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-72 h-72 bg-[#0A1F44]/5 rounded-full blur-3xl pointer-events-none" />

        {/* Top Header */}
        <div className="relative text-center max-w-xl mx-auto mb-6">
          <div className="flex items-center justify-center gap-2 mb-1">
            <Sparkles className="w-5 h-5 text-[#C9A227] animate-pulse" />
            <h1 className="font-horizon text-3xl sm:text-4xl text-[#0A1F44] tracking-widest leading-none">
              SHERPA AI
            </h1>
            <Sparkles className="w-5 h-5 text-[#C9A227] animate-pulse" />
          </div>
          <p className="font-poppins text-xs sm:text-sm font-semibold tracking-wider text-[#C9A227] uppercase">
            {lang === 'es' ? 'Tu Guía de Carrera y Vida' : 'Your Career & Life Guide'}
          </p>
        </div>

        {/* Side-by-Side Combined Layout: Photo Stage Left + Chat Stage Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch relative z-10">
          {/* LEFT SIDE: Waist-Up Sherpa Photo Portrait Stage (lg:col-span-5) */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-4">
            {/* Waist-up Hero Portrait Stage Card */}
            <div
              onClick={() => {
                triggerPose('wave', 4000);
                setSherpaBubbleText({
                  en: "Hey Marcus! I'm right here by your side. Ask me anything or update your goals!",
                  es: '¡Hola Marcus! Estoy aquí mismo a tu lado. ¡Hazme cualquier pregunta o actualiza tus metas!',
                });
              }}
              title={lang === 'es' ? 'Haz clic para interactuar con Sherpa' : 'Click to interact with Sherpa'}
              className={`group relative w-full h-80 sm:h-96 lg:h-[420px] rounded-3xl p-3 bg-gradient-to-b from-[#FFFDF8] via-[#FBF8EF] to-[#ECE7DA] border-4 border-[#C9A227] shadow-xl overflow-hidden cursor-pointer flex flex-col items-center justify-end transition-all duration-300 animate-sherpa-float ${
                isSpeaking || isListening ? 'scale-[1.02] animate-sherpa-glow' : 'hover:scale-[1.01]'
              }`}
            >
              {/* Floating Status Badges */}
              <div className="absolute top-3 inset-x-3 flex items-center justify-between z-20 pointer-events-none">
                <span
                  className={`px-3 py-1 rounded-full text-xs font-poppins font-bold text-white shadow-md border border-white/60 flex items-center gap-1.5 transition-all ${
                    SHERPA_POSES[currentPose].badgeBg
                  }`}
                >
                  <span className="text-sm">
                    {currentPose === 'celebrating' && '🎉'}
                    {currentPose === 'thinking' && '💭'}
                    {currentPose === 'wave' && '👋'}
                    {currentPose === 'coaching' && '📋'}
                    {currentPose === 'idle' && '✨'}
                  </span>
                  <span>
                    {lang === 'es' ? SHERPA_POSES[currentPose].tagEs : SHERPA_POSES[currentPose].tagEn}
                  </span>
                </span>

                {isSpeaking ? (
                  <div className="flex items-center gap-1.5 px-3 py-1 bg-[#0A1F44] text-[#C9A227] rounded-full border border-[#C9A227] text-xs font-bold shadow-md">
                    <Volume2 className="w-3.5 h-3.5 animate-bounce" />
                    <span className="text-[11px] font-poppins">{lang === 'es' ? 'Hablando...' : 'Speaking...'}</span>
                  </div>
                ) : isListening ? (
                  <div className="flex items-center gap-1.5 px-3 py-1 bg-rose-600 text-white rounded-full text-xs font-bold shadow-md animate-pulse">
                    <Mic className="w-3.5 h-3.5 animate-bounce" />
                    <span className="text-[11px] font-poppins">{lang === 'es' ? 'Escuchando...' : 'Listening...'}</span>
                  </div>
                ) : null}
              </div>

              {/* Character Image */}
              <div className="w-full h-full relative flex items-end justify-center overflow-hidden pt-4">
                <img
                  key={currentPose}
                  src={SHERPA_POSES[currentPose].src}
                  alt={SHERPA_POSES[currentPose].alt}
                  className="h-full w-auto max-w-none object-contain object-bottom drop-shadow-2xl transition-all duration-300 group-hover:scale-105 select-none"
                />
              </div>

              <div className="absolute bottom-0 inset-x-0 h-4 bg-gradient-to-t from-[#0A1F44]/20 to-transparent pointer-events-none" />
            </div>

            {/* Voice & Language Action Controls */}
            <div className="flex flex-wrap items-center justify-center gap-2">
              <button
                type="button"
                onClick={() => setLang(lang === 'en' ? 'es' : 'en')}
                className="flex items-center gap-1 px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 border border-slate-300 font-poppins text-xs font-bold text-[#0A1F44] transition cursor-pointer shadow-xs"
              >
                <Languages className="w-3.5 h-3.5 text-[#C9A227]" />
                <span>{lang === 'en' ? 'ES' : 'EN'}</span>
              </button>

              <button
                type="button"
                onClick={handleToggleVoiceInput}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl border font-poppins text-xs font-bold transition-all cursor-pointer shadow-xs ${
                  isListening
                    ? 'bg-rose-500 text-white border-rose-600 animate-pulse ring-2 ring-rose-400'
                    : 'bg-slate-100 hover:bg-slate-200 text-[#0A1F44] border-slate-300'
                }`}
              >
                {isListening ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5 text-[#0A1F44]" />}
                <span>{isListening ? (lang === 'es' ? 'Detener' : 'Stop') : (lang === 'es' ? 'Hablar' : 'Talk')}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  const nextVal = !voiceOutEnabled;
                  setVoiceOutEnabled(nextVal);
                  if (!nextVal && typeof window !== 'undefined' && 'speechSynthesis' in window) {
                    window.speechSynthesis.cancel();
                    setIsSpeaking(false);
                  }
                }}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl border font-poppins text-xs font-bold transition-all cursor-pointer shadow-xs ${
                  voiceOutEnabled
                    ? 'bg-[#0A1F44] text-[#C9A227] border-[#0A1F44]'
                    : 'bg-slate-100 text-slate-400 border-slate-300'
                }`}
              >
                {voiceOutEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
                <span>{voiceOutEnabled ? (lang === 'es' ? 'Voz ON' : 'Voice ON') : (lang === 'es' ? 'Voz OFF' : 'Voice OFF')}</span>
              </button>
            </div>
          </div>

          {/* RIGHT SIDE: Speech Bubble + Topic Chat Stage (lg:col-span-7) */}
          <div className="lg:col-span-7 flex flex-col justify-between space-y-4">
            {/* Live Speech Bubble */}
            <div className="bg-[#0A1F44] text-white p-4 rounded-2xl border-l-4 border-[#C9A227] shadow-lg">
              <div className="flex items-start gap-2.5">
                <span className="text-[#C9A227] text-xl font-serif select-none leading-none">“</span>
                <p className="font-poppins text-xs sm:text-sm text-slate-100 leading-relaxed font-normal flex-1">
                  {lang === 'es' ? sherpaBubbleText.es : sherpaBubbleText.en}
                </p>
                <span className="text-[#C9A227] text-xl font-serif select-none leading-none self-end">”</span>
              </div>
            </div>

            {/* Chat Topic Header & Chips */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50 border border-slate-200 rounded-2xl p-3">
              <span className="font-poppins font-bold text-sm text-[#0A1F44]">
                {lang === 'es' ? 'Tema de Conversación:' : 'Chat Topic:'}
              </span>
              <div className="flex items-center gap-2">
                {[
                  { id: 'work', labelEn: 'Work', labelEs: 'Trabajo' },
                  { id: 'money', labelEn: 'Money', labelEs: 'Dinero' },
                  { id: 'goals', labelEn: 'Goals', labelEs: 'Metas' },
                ].map((chip) => {
                  const isSelected = activeTopic === chip.id;
                  return (
                    <button
                      key={chip.id}
                      type="button"
                      onClick={() => setActiveTopic(chip.id as TopicKey)}
                      className={`px-3.5 py-1 rounded-full font-poppins text-xs font-bold tracking-wide transition cursor-pointer ${
                        isSelected
                          ? 'bg-[#0A1F44] text-[#C9A227] shadow-xs'
                          : 'bg-white hover:bg-slate-200 text-slate-600 border border-slate-200'
                      }`}
                    >
                      {lang === 'es' ? chip.labelEs : chip.labelEn}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Money Topic Consent Toggle */}
            {activeTopic === 'money' && (
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-[#C9A227] shrink-0" />
                  <label htmlFor="money-consent" className="font-poppins text-xs font-semibold text-[#0A1F44] cursor-pointer">
                    {lang === 'es'
                      ? 'Permitir que Sherpa vea mis recibos de pago'
                      : 'Let Sherpa see my pay stubs for money goals'}
                  </label>
                </div>
                <button
                  id="money-consent"
                  type="button"
                  role="switch"
                  aria-checked={moneyConsentGranted}
                  onClick={() => setMoneyConsentGranted((prev) => !prev)}
                  className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                    moneyConsentGranted ? 'bg-[#C9A227]' : 'bg-slate-300'
                  }`}
                >
                  <span
                    className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                      moneyConsentGranted ? 'translate-x-4' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>
            )}

            {/* Live Chat Messages Thread */}
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 h-64 sm:h-72 overflow-y-auto space-y-3">
              {topicThreads[activeTopic].map((msg) => {
                const isSherpa = msg.sender === 'sherpa';
                return (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${isSherpa ? 'items-start' : 'items-end'}`}
                  >
                    <div className={`flex items-start gap-2 max-w-[90%] ${isSherpa ? 'flex-row' : 'flex-row-reverse'}`}>
                      {isSherpa && (
                        <div className="w-7 h-7 rounded-full shrink-0 border border-[#C9A227] overflow-hidden bg-[#FAF6EE] shadow-xs mt-0.5">
                          <img
                            src={SHERPA_POSES[currentPose].src}
                            alt="Sherpa"
                            className="w-full h-full object-cover object-[center_12%] scale-120"
                          />
                        </div>
                      )}
                      <div
                        className={`rounded-2xl p-3 text-xs sm:text-sm font-oswald leading-relaxed ${
                          isSherpa
                            ? 'bg-[#0A1F44] text-white rounded-tl-none border-l-3 border-[#C9A227]'
                            : 'bg-[#C9A227] text-[#0A1F44] font-medium rounded-tr-none'
                        }`}
                      >
                        {msg.text}
                      </div>
                    </div>
                    <span className={`text-[10px] text-slate-400 mt-0.5 px-1 ${isSherpa ? 'pl-9' : ''}`}>{msg.time}</span>
                  </div>
                );
              })}
              <div ref={chatBottomRef} />
            </div>

            {/* Input Bar */}
            <form onSubmit={handleSendTopicMessage} className="flex gap-2">
              <input
                type="text"
                value={topicInput}
                onChange={(e) => setTopicInput(e.target.value)}
                placeholder={
                  lang === 'es'
                    ? `Escribe a Sherpa sobre ${
                        activeTopic === 'work' ? 'trabajo' : activeTopic === 'money' ? 'dinero' : 'metas'
                      }...`
                    : `Type to Sherpa about ${activeTopic}...`
                }
                className="flex-1 bg-slate-50 border border-slate-300 rounded-xl px-4 py-2.5 text-xs sm:text-sm font-oswald text-[#0A1F44] placeholder-slate-400 focus:outline-none focus:border-[#0A1F44] focus:ring-1 focus:ring-[#0A1F44]"
              />
              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-[#0A1F44] hover:bg-[#1E4383] text-[#C9A227] font-poppins text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition cursor-pointer shrink-0"
              >
                <span>{lang === 'es' ? 'Enviar' : 'Send'}</span>
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* 3. JOURNEY SUMMARY CARD */}
      <section className="bg-white border-2 border-[#C9A227] rounded-3xl p-5 sm:p-6 shadow-md relative">
        <div className="flex items-center gap-2 mb-2 text-[#0A1F44]">
          <Sparkles className="w-5 h-5 text-[#C9A227]" />
          <h2 className="font-poppins font-bold text-base sm:text-lg text-[#0A1F44]">
            {lang === 'es' ? 'Dónde estás → hacia dónde vas' : "Where you are → where you're going"}
          </h2>
        </div>
        <p className="font-oswald text-slate-700 text-sm sm:text-base leading-relaxed">
          {getDynamicJourneySummary()}
        </p>
      </section>

      {/* 4. OVERALL PROGRESS */}
      <section className="bg-white border-2 border-slate-200 rounded-3xl p-5 sm:p-6 shadow-md">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="font-poppins text-xs uppercase tracking-widest text-[#C9A227] font-bold block">
              {lang === 'es' ? 'Progreso Acumulado' : 'Cumulative Progress'}
            </span>
            <h2 className="font-poppins font-bold text-lg sm:text-xl text-[#0A1F44]">
              {lang === 'es' ? 'Logro general' : 'Overall achievement'}
            </h2>
            <p className="font-oswald text-xs text-slate-500">
              {lang === 'es'
                ? `${completedStepsAll} de ${totalStepsAll} pasos completados en todas las metas`
                : `${completedStepsAll} of ${totalStepsAll} total steps accomplished across all goals`}
            </p>
          </div>

          {/* Big percentage display & progress indicator */}
          <div className="flex items-center gap-4 min-w-[200px]">
            <div className="flex-1">
              <div className="w-full bg-slate-100 rounded-full h-4 overflow-hidden border border-slate-200 p-0.5">
                <div
                  className="bg-gradient-to-r from-[#0A1F44] via-[#1E4383] to-[#C9A227] h-full rounded-full transition-all duration-700 ease-out"
                  style={{ width: `${overallPercentage}%` }}
                />
              </div>
            </div>
            <div className="shrink-0 font-horizon text-2xl sm:text-3xl font-bold text-[#0A1F44]">
              {overallPercentage}%
            </div>
          </div>
        </div>
      </section>

      {/* 5. LONG-TERM GOALS SECTION */}
      <section className="space-y-4">
        <h2 className="font-poppins font-bold text-xl sm:text-2xl text-[#0A1F44] px-1">
          {lang === 'es' ? 'Metas a largo plazo' : 'Long-term goals'}
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {longTermGoals.map((goal) => {
            const isAchieved = goal.completedSteps >= goal.totalSteps;
            const currentStepItem = goal.steps[goal.completedSteps];
            const goalPct = Math.round((goal.completedSteps / goal.totalSteps) * 100);

            return (
              <div
                key={goal.id}
                className={`bg-white border-2 rounded-3xl p-5 shadow-md flex flex-col justify-between transition-all ${
                  isAchieved ? 'border-[#C9A227] bg-[#C9A227]/5' : 'border-slate-200'
                }`}
              >
                <div>
                  {/* Goal Title */}
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <h3 className="font-poppins font-bold text-base text-[#0A1F44]">
                      {lang === 'es' ? goal.titleEs : goal.titleEn}
                    </h3>
                    {isAchieved && (
                      <span className="inline-flex items-center gap-1 bg-[#C9A227] text-[#0A1F44] font-poppins text-xs font-bold px-2.5 py-0.5 rounded-full shrink-0">
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                        <span>{lang === 'es' ? 'Alcanzada' : 'Achieved'}</span>
                      </span>
                    )}
                  </div>

                  {/* Goal Progress Bar */}
                  <div className="space-y-1 mb-4">
                    <div className="flex items-center justify-between text-xs font-oswald text-slate-500">
                      <span>
                        {goal.completedSteps} / {goal.totalSteps} {lang === 'es' ? 'pasos' : 'steps'}
                      </span>
                      <span className="font-bold text-[#0A1F44]">{goalPct}%</span>
                    </div>
                    <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden border border-slate-200">
                      <div
                        className="bg-[#C9A227] h-full rounded-full transition-all duration-500"
                        style={{ width: `${goalPct}%` }}
                      />
                    </div>
                  </div>
                </div>

                {/* Box state: Either Achieved Gold State or exactly ONE highlighted Next Step box */}
                {isAchieved ? (
                  <div className="bg-[#0A1F44] text-white rounded-2xl p-4 border border-[#C9A227] flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-[#C9A227] text-[#0A1F44] flex items-center justify-center shrink-0">
                      <CheckCircle2 className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="font-poppins font-bold text-xs text-[#C9A227] uppercase tracking-wider">
                        {lang === 'es' ? 'Meta Completada' : 'Goal Achieved'}
                      </p>
                      <p className="font-oswald text-xs text-slate-200 mt-0.5">
                        {lang === 'es'
                          ? 'Has completado todos los pasos de este objetivo.'
                          : 'All milestones completed. Outstanding work!'}
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="bg-slate-50 border-2 border-[#C9A227] rounded-2xl p-4 space-y-3">
                    <span className="font-poppins text-[11px] font-bold uppercase tracking-wider text-[#0A1F44] flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-[#C9A227]" />
                      <span>{lang === 'es' ? 'Siguiente paso' : 'Next step'}</span>
                    </span>

                    <p className="font-oswald text-sm text-[#0A1F44] font-medium leading-snug">
                      {lang === 'es' ? currentStepItem?.textEs : currentStepItem?.textEn}
                    </p>

                    <button
                      type="button"
                      onClick={() => handleCompleteNextStep(goal.id)}
                      className="w-full py-2.5 px-4 rounded-xl bg-[#0A1F44] hover:bg-[#1E4383] text-[#C9A227] font-poppins text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition cursor-pointer shadow-sm active:scale-98"
                    >
                      <Check className="w-4 h-4 stroke-[3]" />
                      <span>{lang === 'es' ? 'Listo' : 'Done'}</span>
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* 6. SHORT-TERM GOALS SECTION */}
      <section className="space-y-4">
        <h2 className="font-poppins font-bold text-xl sm:text-2xl text-[#0A1F44] px-1">
          {lang === 'es' ? 'Metas a corto plazo' : 'Short-term goals'}
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {shortTermGoals.map((goal) => {
            const isAchieved = goal.completedSteps >= goal.totalSteps;
            const currentStepItem = goal.steps[goal.completedSteps];
            const goalPct = Math.round((goal.completedSteps / goal.totalSteps) * 100);

            return (
              <div
                key={goal.id}
                className={`bg-white border-2 rounded-3xl p-5 shadow-md flex flex-col justify-between transition-all ${
                  isAchieved ? 'border-[#C9A227] bg-[#C9A227]/5' : 'border-slate-200'
                }`}
              >
                <div>
                  {/* Goal Title */}
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <h3 className="font-poppins font-bold text-base text-[#0A1F44]">
                      {lang === 'es' ? goal.titleEs : goal.titleEn}
                    </h3>
                    {isAchieved && (
                      <span className="inline-flex items-center gap-1 bg-[#C9A227] text-[#0A1F44] font-poppins text-xs font-bold px-2.5 py-0.5 rounded-full shrink-0">
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                        <span>{lang === 'es' ? 'Alcanzada' : 'Achieved'}</span>
                      </span>
                    )}
                  </div>

                  {/* Goal Progress Bar */}
                  <div className="space-y-1 mb-4">
                    <div className="flex items-center justify-between text-xs font-oswald text-slate-500">
                      <span>
                        {goal.completedSteps} / {goal.totalSteps} {lang === 'es' ? 'pasos' : 'steps'}
                      </span>
                      <span className="font-bold text-[#0A1F44]">{goalPct}%</span>
                    </div>
                    <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden border border-slate-200">
                      <div
                        className="bg-[#C9A227] h-full rounded-full transition-all duration-500"
                        style={{ width: `${goalPct}%` }}
                      />
                    </div>
                  </div>
                </div>

                {/* Box state: Either Achieved Gold State or exactly ONE highlighted Next Step box */}
                {isAchieved ? (
                  <div className="bg-[#0A1F44] text-white rounded-2xl p-4 border border-[#C9A227] flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-[#C9A227] text-[#0A1F44] flex items-center justify-center shrink-0">
                      <CheckCircle2 className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="font-poppins font-bold text-xs text-[#C9A227] uppercase tracking-wider">
                        {lang === 'es' ? 'Meta Completada' : 'Goal Achieved'}
                      </p>
                      <p className="font-oswald text-xs text-slate-200 mt-0.5">
                        {lang === 'es'
                          ? 'Has completado todos los pasos de este objetivo.'
                          : 'All milestones completed. Outstanding work!'}
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="bg-slate-50 border-2 border-[#C9A227] rounded-2xl p-4 space-y-3">
                    <span className="font-poppins text-[11px] font-bold uppercase tracking-wider text-[#0A1F44] flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-[#C9A227]" />
                      <span>{lang === 'es' ? 'Siguiente paso' : 'Next step'}</span>
                    </span>

                    <p className="font-oswald text-sm text-[#0A1F44] font-medium leading-snug">
                      {lang === 'es' ? currentStepItem?.textEs : currentStepItem?.textEn}
                    </p>

                    <button
                      type="button"
                      onClick={() => handleCompleteNextStep(goal.id)}
                      className="w-full py-2.5 px-4 rounded-xl bg-[#0A1F44] hover:bg-[#1E4383] text-[#C9A227] font-poppins text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition cursor-pointer shadow-sm active:scale-98"
                    >
                      <Check className="w-4 h-4 stroke-[3]" />
                      <span>{lang === 'es' ? 'Listo' : 'Done'}</span>
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
};
