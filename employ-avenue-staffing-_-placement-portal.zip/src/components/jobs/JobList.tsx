import React, { useState } from 'react';
import { useWorkforce } from '../../context/WorkforceContext';
import {
  Briefcase,
  MapPin,
  Clock,
  DollarSign,
  Filter,
  CheckCircle2,
  Send,
  Search,
  Sparkles,
  Users,
  AlertCircle,
} from 'lucide-react';
import { JobOpening } from '../../types';

export const JobList: React.FC = () => {
  const { jobs, applyToJob, application } = useWorkforce();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedShift, setSelectedShift] = useState<string>('All');
  const [selectedType, setSelectedType] = useState<string>('All');
  const [selectedJobForModal, setSelectedJobForModal] = useState<JobOpening | null>(null);

  const shifts = ['All', '1st Shift (Day)', '2nd Shift (Swing)', '3rd Shift (Graveyard)', 'Weekend'];
  const jobTypes = ['All', 'Warehouse', 'Assembly', 'Logistics', 'Quality Control'];

  const filteredJobs = jobs.filter((job) => {
    const matchesSearch =
      job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.location.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesShift = selectedShift === 'All' || job.shift === selectedShift;
    const matchesType =
      selectedType === 'All' ||
      job.jobType.toLowerCase().includes(selectedType.toLowerCase());

    return matchesSearch && matchesShift && matchesType;
  });

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-[#0E2652] border border-[#1E4383] rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span className="text-xs font-poppins text-[#C9A227] uppercase tracking-widest font-bold">
              Immediate Placement Board
            </span>
            <h2 className="text-2xl font-horizon font-bold text-white tracking-wider">
              Open Staffing Positions
            </h2>
            <p className="mt-1 text-xs font-oswald text-white/70">
              One-Click Apply: Your permanent profile, verified skills, and background checks are
              sent directly to the hiring supervisor in one tap. No redundant forms.
            </p>
          </div>

          <div className="bg-[#06132B] px-4 py-2.5 rounded-xl border border-[#1E4383] text-center md:text-right">
            <span className="text-[11px] font-oswald text-white/60 uppercase block">
              Direct Profile Dispatch
            </span>
            <span className="text-sm font-poppins font-bold text-[#C9A227]">
              {application.firstName ? `${application.firstName}'s Profile Attached` : 'Profile Ready'}
            </span>
          </div>
        </div>

        {/* Filter Toolbar */}
        <div className="mt-6 pt-5 border-t border-[#1E4383] flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          {/* Search Bar */}
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-white/40 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by title, facility, or location..."
              className="w-full pl-9 pr-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-xl text-white font-oswald text-xs placeholder-white/40 focus:border-[#C9A227] outline-none"
            />
          </div>

          {/* Shift Filter buttons */}
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-[11px] font-oswald uppercase text-white/60 mr-1 hidden sm:inline">
              Shift:
            </span>
            {shifts.map((s) => (
              <button
                key={s}
                onClick={() => setSelectedShift(s)}
                className={`px-3 py-1.5 rounded-lg font-oswald text-xs uppercase tracking-wider transition ${
                  selectedShift === s
                    ? 'bg-[#C9A227] text-[#0A1F44] font-bold shadow'
                    : 'bg-[#06132B] text-white/70 hover:text-white border border-[#1E4383]'
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Job Type Filter row */}
        <div className="mt-3 flex flex-wrap items-center gap-1.5">
          <span className="text-[11px] font-oswald uppercase text-white/60 mr-1 hidden sm:inline">
            Discipline:
          </span>
          {jobTypes.map((t) => (
            <button
              key={t}
              onClick={() => setSelectedType(t)}
              className={`px-3 py-1 rounded-md font-oswald text-xs uppercase tracking-wider transition ${
                selectedType === t
                  ? 'bg-[#13336E] text-[#C9A227] font-semibold border border-[#C9A227]/50'
                  : 'bg-[#06132B]/80 text-white/60 hover:text-white border border-[#1E4383]/60'
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* Jobs Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredJobs.map((job) => {
          return (
            <div
              key={job.id}
              className={`bg-[#0E2652] rounded-2xl border transition-all duration-300 flex flex-col justify-between p-5 relative overflow-hidden group shadow-lg ${
                job.applied
                  ? 'border-[#C9A227] shadow-[#C9A227]/10'
                  : 'border-[#1E4383] hover:border-[#C9A227]/60'
              }`}
            >
              {/* Applied Ribbon if applied */}
              {job.applied && (
                <div className="absolute top-3 right-3 bg-gradient-to-r from-[#9B7A15] to-[#C9A227] text-[#0A1F44] px-3 py-0.5 rounded-full font-oswald font-black text-xs uppercase tracking-wider flex items-center gap-1 shadow">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Applied</span>
                </div>
              )}

              <div>
                <span className="text-[10px] font-poppins font-bold uppercase tracking-widest text-[#C9A227]">
                  {job.jobType} • {job.shift}
                </span>
                <h3 className="font-poppins font-bold text-lg text-white mt-1 group-hover:text-[#C9A227] transition">
                  {job.title}
                </h3>
                <p className="font-oswald text-xs text-white/80 font-medium">{job.company}</p>

                <div className="flex items-center gap-1.5 text-xs font-oswald text-white/60 mt-2">
                  <MapPin className="w-3.5 h-3.5 text-[#C9A227]" />
                  <span>{job.location}</span>
                </div>

                {/* Rate & Hours Badge */}
                <div className="mt-4 p-3 bg-[#06132B] rounded-xl border border-[#1E4383] flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-oswald text-white/50 uppercase block">
                      Pay Rate
                    </span>
                    <span className="font-horizon text-xl font-bold text-[#C9A227]">
                      ${job.payRate.toFixed(2)}
                      <span className="text-xs font-oswald text-white/60"> / hr</span>
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] font-oswald text-white/50 uppercase block">
                      Schedule
                    </span>
                    <span className="font-oswald text-xs text-white font-semibold">
                      {job.hoursPerWeek} hrs / wk
                    </span>
                  </div>
                </div>

                <p className="text-xs font-oswald text-white/70 mt-3 line-clamp-2">
                  {job.description}
                </p>

                {/* Requirements tags */}
                <div className="mt-3 flex flex-wrap gap-1">
                  {job.requirements.slice(0, 2).map((req, i) => (
                    <span
                      key={i}
                      className="text-[10px] font-oswald px-2 py-0.5 rounded bg-[#13336E] text-white/80"
                    >
                      {req}
                    </span>
                  ))}
                </div>
              </div>

              {/* Bottom Actions */}
              <div className="mt-5 pt-3 border-t border-[#1E4383] flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedJobForModal(job)}
                  className="text-xs font-oswald text-white/70 hover:text-white underline uppercase tracking-wider"
                >
                  View Details
                </button>

                {job.applied ? (
                  <button
                    disabled
                    className="px-4 py-2 rounded-xl bg-[#06132B] border border-[#C9A227] text-[#C9A227] font-oswald font-bold text-xs uppercase tracking-wider cursor-default flex items-center gap-1.5"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Profile Transmitted</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => applyToJob(job.id)}
                    className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#C9A227] to-[#DBB535] hover:from-[#DBB535] hover:to-[#C9A227] text-[#0A1F44] font-horizon font-bold text-xs uppercase tracking-wider transition shadow-md shadow-[#C9A227]/20 flex items-center gap-1.5 hover:scale-[1.02]"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>One-Click Apply</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {filteredJobs.length === 0 && (
        <div className="bg-[#0E2652] rounded-2xl border border-[#1E4383] p-12 text-center">
          <Briefcase className="w-12 h-12 text-white/20 mx-auto mb-3" />
          <h3 className="font-poppins font-bold text-base text-white">No openings match filters</h3>
          <p className="text-xs font-oswald text-white/60 mt-1">
            Try switching shift or discipline filters above.
          </p>
        </div>
      )}

      {/* Job Details Modal */}
      {selectedJobForModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#0E2652] border-2 border-[#1E4383] rounded-2xl max-w-lg w-full p-6 shadow-2xl relative">
            <div className="flex justify-between items-start pb-3 border-b border-[#1E4383]">
              <div>
                <span className="text-[10px] font-poppins font-bold text-[#C9A227] uppercase">
                  {selectedJobForModal.jobType} • {selectedJobForModal.shift}
                </span>
                <h3 className="font-poppins font-bold text-xl text-white">
                  {selectedJobForModal.title}
                </h3>
                <p className="font-oswald text-xs text-white/80">{selectedJobForModal.company}</p>
              </div>
              <button
                onClick={() => setSelectedJobForModal(null)}
                className="text-white/60 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="mt-4 space-y-4">
              <div className="p-3 bg-[#06132B] rounded-xl border border-[#1E4383] grid grid-cols-2 gap-3 text-xs font-oswald">
                <div>
                  <span className="text-white/50 block">Pay Rate:</span>
                  <span className="text-lg font-horizon font-bold text-[#C9A227]">
                    ${selectedJobForModal.payRate.toFixed(2)}/hr
                  </span>
                </div>
                <div>
                  <span className="text-white/50 block">Start Date:</span>
                  <span className="text-sm font-semibold text-white">
                    {selectedJobForModal.startDate}
                  </span>
                </div>
              </div>

              <div>
                <h4 className="font-poppins font-bold text-xs uppercase text-white/90 mb-1">
                  Full Role Description
                </h4>
                <p className="text-xs font-oswald text-white/80 leading-relaxed">
                  {selectedJobForModal.description}
                </p>
              </div>

              <div>
                <h4 className="font-poppins font-bold text-xs uppercase text-white/90 mb-1">
                  Position Requirements
                </h4>
                <ul className="space-y-1">
                  {selectedJobForModal.requirements.map((req, i) => (
                    <li key={i} className="flex items-start gap-2 text-xs font-oswald text-white/70">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#C9A227] mt-1.5" />
                      <span>{req}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="pt-3 border-t border-[#1E4383] flex items-center justify-between">
                <span className="text-[11px] font-oswald text-white/60">
                  {selectedJobForModal.spotsLeft} Open Placement Slots Remaining
                </span>

                {selectedJobForModal.applied ? (
                  <div className="px-4 py-2 rounded-xl bg-emerald-500/20 text-emerald-400 font-oswald text-xs font-bold flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Applied With Permanent Profile</span>
                  </div>
                ) : (
                  <button
                    onClick={() => {
                      applyToJob(selectedJobForModal.id);
                      setSelectedJobForModal(null);
                    }}
                    className="px-6 py-2.5 rounded-xl bg-[#C9A227] hover:bg-[#DBB535] text-[#0A1F44] font-horizon font-bold text-xs uppercase tracking-wider"
                  >
                    One-Click Apply
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
