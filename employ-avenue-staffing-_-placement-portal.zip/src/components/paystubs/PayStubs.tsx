import React, { useState } from 'react';
import { useWorkforce } from '../../context/WorkforceContext';
import {
  FileCheck2,
  Download,
  Eye,
  Printer,
  Calendar,
  Building,
  CheckCircle2,
  DollarSign,
  ShieldCheck,
} from 'lucide-react';
import { PayStub } from '../../types';

export const PayStubs: React.FC = () => {
  const { payStubs, user } = useWorkforce();
  const [selectedStub, setSelectedStub] = useState<PayStub | null>(null);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-[#0E2652] border border-[#1E4383] rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span className="text-xs font-poppins text-[#C9A227] uppercase tracking-widest font-bold">
              Earnings & Tax Statements
            </span>
            <h2 className="text-2xl font-horizon font-bold text-white tracking-wider">
              Pay Stubs Archive
            </h2>
            <p className="mt-1 text-xs font-oswald text-white/70">
              Access and download official earnings statements anytime. All stubs detail hours,
              regular & overtime rates, gross wages, statutory taxes, and net direct deposits.
            </p>
          </div>

          <div className="bg-[#06132B] px-4 py-3 rounded-xl border border-[#1E4383] text-left md:text-right">
            <span className="text-[10px] font-oswald uppercase text-white/60 block">
              2026 Year-To-Date Gross
            </span>
            <span className="font-horizon text-2xl font-bold text-[#C9A227]">
              ${payStubs[0]?.ytdGross.toLocaleString() || '39,420.00'}
            </span>
          </div>
        </div>
      </div>

      {/* Pay Stubs Table */}
      <div className="bg-[#0E2652] border border-[#1E4383] rounded-2xl shadow-xl overflow-hidden">
        <div className="p-5 border-b border-[#1E4383] bg-[#06132B]/80 flex justify-between items-center">
          <h3 className="font-poppins font-bold text-base text-white">Statement Records</h3>
          <span className="text-xs font-oswald text-white/60">
            {payStubs.length} Statements Available
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-oswald text-xs">
            <thead className="bg-[#06132B] text-white/70 uppercase border-b border-[#1E4383]">
              <tr>
                <th className="px-5 py-3 font-semibold">Stub Number</th>
                <th className="px-5 py-3 font-semibold">Pay Period</th>
                <th className="px-5 py-3 font-semibold">Pay Date</th>
                <th className="px-5 py-3 font-semibold text-right">Regular Hrs</th>
                <th className="px-5 py-3 font-semibold text-right">OT Hrs</th>
                <th className="px-5 py-3 font-semibold text-right">Gross Pay</th>
                <th className="px-5 py-3 font-semibold text-right">Taxes & Deduct.</th>
                <th className="px-5 py-3 font-semibold text-right">Net Pay</th>
                <th className="px-5 py-3 font-semibold text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1E4383]/60">
              {payStubs.map((stub) => {
                const totalDeductions =
                  stub.deductions.federalTax +
                  stub.deductions.stateTax +
                  stub.deductions.socialSecurity +
                  stub.deductions.medicare;

                return (
                  <tr key={stub.id} className="hover:bg-[#13336E]/40 transition">
                    <td className="px-5 py-3.5 font-poppins font-bold text-white">
                      {stub.stubNumber}
                    </td>
                    <td className="px-5 py-3.5 text-white/80">
                      {stub.payPeriodStart} – {stub.payPeriodEnd}
                    </td>
                    <td className="px-5 py-3.5 text-[#C9A227] font-semibold">{stub.payDate}</td>
                    <td className="px-5 py-3.5 text-right text-white/90">
                      {stub.regularHours.toFixed(1)} hrs
                    </td>
                    <td className="px-5 py-3.5 text-right text-white/90">
                      {stub.overtimeHours > 0 ? `${stub.overtimeHours.toFixed(1)} hrs` : '—'}
                    </td>
                    <td className="px-5 py-3.5 text-right font-semibold text-white">
                      ${stub.grossPay.toFixed(2)}
                    </td>
                    <td className="px-5 py-3.5 text-right text-rose-300">
                      -${totalDeductions.toFixed(2)}
                    </td>
                    <td className="px-5 py-3.5 text-right font-horizon text-sm font-bold text-emerald-400">
                      ${stub.netPay.toFixed(2)}
                    </td>
                    <td className="px-5 py-3.5 text-center">
                      <button
                        onClick={() => setSelectedStub(stub)}
                        className="px-3 py-1.5 rounded-lg bg-[#13336E] hover:bg-[#1E4383] text-[#C9A227] border border-[#C9A227]/40 font-oswald uppercase text-xs tracking-wider transition flex items-center gap-1 mx-auto"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>View Stub</span>
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* DETAILED PAY STUB SLIP MODAL */}
      {selectedStub && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md overflow-y-auto">
          <div className="bg-white text-[#0A1F44] rounded-2xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl relative my-auto border-4 border-[#0A1F44]">
            {/* Action Bar (Top of modal) */}
            <div className="flex justify-between items-center pb-4 mb-6 border-b border-gray-200">
              <span className="font-poppins font-bold text-xs uppercase tracking-wider text-gray-500">
                Official Employee Pay Statement
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={handlePrint}
                  className="px-3 py-1.5 rounded-lg bg-[#0A1F44] text-[#C9A227] font-oswald text-xs uppercase flex items-center gap-1.5"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Slip</span>
                </button>
                <button
                  onClick={() => setSelectedStub(null)}
                  className="text-gray-400 hover:text-gray-700 p-1"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* Paystub Document Body */}
            <div className="space-y-6 text-xs font-oswald">
              {/* Header: Company & Employee */}
              <div className="grid grid-cols-2 gap-4 pb-4 border-b border-gray-300">
                <div>
                  <img
                    src="/assets/aistudio/Staffing_agency_logo_7ec39da1.png"
                    alt="Employ Avenue Staffing"
                    className="h-10 w-auto object-contain mb-1"
                  />
                  <p className="text-gray-600 text-[11px]">Staffing & Placement Services Inc.</p>
                  <p className="text-gray-600 text-[11px]">100 Peachtree St NW, Suite 1400</p>
                  <p className="text-gray-600 text-[11px]">Atlanta, GA 30303 • EIN: 58-9821400</p>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-gray-500 uppercase block">Employee Name</span>
                  <p className="font-poppins font-bold text-sm text-[#0A1F44]">
                    {user?.fullName || 'Marcus Vance'}
                  </p>
                  <p className="text-gray-600">SSN: •••-••-8842</p>
                  <p className="text-gray-600">
                    Payment Method: Direct Deposit ({user?.accountNumberMasked || '••••4819'})
                  </p>
                </div>
              </div>

              {/* Pay Period & Dates */}
              <div className="grid grid-cols-3 gap-2 p-3 bg-gray-100 rounded-lg text-center">
                <div>
                  <span className="text-gray-500 uppercase text-[10px] block">Pay Period</span>
                  <span className="font-semibold text-gray-800">
                    {selectedStub.payPeriodStart} – {selectedStub.payPeriodEnd}
                  </span>
                </div>
                <div>
                  <span className="text-gray-500 uppercase text-[10px] block">Pay Date</span>
                  <span className="font-semibold text-gray-800">{selectedStub.payDate}</span>
                </div>
                <div>
                  <span className="text-gray-500 uppercase text-[10px] block">Advice / Check #</span>
                  <span className="font-semibold text-gray-800">{selectedStub.checkNumber}</span>
                </div>
              </div>

              {/* Earnings Table */}
              <div>
                <h4 className="font-poppins font-bold text-xs uppercase text-[#0A1F44] mb-1">
                  Earnings Breakdown
                </h4>
                <table className="w-full text-left border border-gray-200">
                  <thead className="bg-gray-100 text-gray-700 text-[11px]">
                    <tr>
                      <th className="p-2">Description</th>
                      <th className="p-2 text-right">Hours</th>
                      <th className="p-2 text-right">Rate</th>
                      <th className="p-2 text-right">Total Gross</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200 text-gray-800">
                    <tr>
                      <td className="p-2 font-medium">Regular Shift Hours</td>
                      <td className="p-2 text-right">{selectedStub.regularHours.toFixed(2)}</td>
                      <td className="p-2 text-right">${selectedStub.hourlyRate.toFixed(2)}</td>
                      <td className="p-2 text-right font-semibold">
                        ${(selectedStub.regularHours * selectedStub.hourlyRate).toFixed(2)}
                      </td>
                    </tr>
                    {selectedStub.overtimeHours > 0 && (
                      <tr>
                        <td className="p-2 font-medium">Overtime (1.5x)</td>
                        <td className="p-2 text-right">{selectedStub.overtimeHours.toFixed(2)}</td>
                        <td className="p-2 text-right">${selectedStub.overtimeRate.toFixed(2)}</td>
                        <td className="p-2 text-right font-semibold">
                          ${(selectedStub.overtimeHours * selectedStub.overtimeRate).toFixed(2)}
                        </td>
                      </tr>
                    )}
                    <tr className="bg-gray-50 font-bold">
                      <td colSpan={3} className="p-2 uppercase text-gray-900">
                        Total Gross Earnings
                      </td>
                      <td className="p-2 text-right text-gray-900">
                        ${selectedStub.grossPay.toFixed(2)}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Deductions & Taxes Table */}
              <div>
                <h4 className="font-poppins font-bold text-xs uppercase text-[#0A1F44] mb-1">
                  Statutory Deductions & Taxes
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-gray-700">
                  <div className="p-2 bg-gray-50 rounded border border-gray-200">
                    <span className="text-[10px] text-gray-500 block">Federal Withholding</span>
                    <span className="font-semibold text-rose-600">
                      -${selectedStub.deductions.federalTax.toFixed(2)}
                    </span>
                  </div>
                  <div className="p-2 bg-gray-50 rounded border border-gray-200">
                    <span className="text-[10px] text-gray-500 block">State Withholding (GA)</span>
                    <span className="font-semibold text-rose-600">
                      -${selectedStub.deductions.stateTax.toFixed(2)}
                    </span>
                  </div>
                  <div className="p-2 bg-gray-50 rounded border border-gray-200">
                    <span className="text-[10px] text-gray-500 block">Social Security (FICA)</span>
                    <span className="font-semibold text-rose-600">
                      -${selectedStub.deductions.socialSecurity.toFixed(2)}
                    </span>
                  </div>
                  <div className="p-2 bg-gray-50 rounded border border-gray-200">
                    <span className="text-[10px] text-gray-500 block">Medicare (1.45%)</span>
                    <span className="font-semibold text-rose-600">
                      -${selectedStub.deductions.medicare.toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Net Pay Callout Banner */}
              <div className="p-4 bg-[#0A1F44] text-white rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-xs uppercase text-[#C9A227] tracking-wider block font-semibold">
                    Net Direct Deposit
                  </span>
                  <span className="text-xs text-white/70">
                    Dispatched to {user?.bankName || 'First Horizon National'}
                  </span>
                </div>
                <div className="text-right">
                  <span className="font-horizon text-3xl font-bold text-[#C9A227]">
                    ${selectedStub.netPay.toFixed(2)}
                  </span>
                </div>
              </div>

              {/* Year To Date Summary Strip */}
              <div className="pt-2 border-t border-gray-200 flex justify-between text-[11px] text-gray-600">
                <span>YTD Gross: ${selectedStub.ytdGross.toLocaleString()}</span>
                <span>YTD Net Received: ${selectedStub.ytdNet.toLocaleString()}</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
