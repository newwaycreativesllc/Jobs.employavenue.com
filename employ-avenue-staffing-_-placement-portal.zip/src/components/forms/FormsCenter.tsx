import React, { useState } from 'react';
import { useWorkforce } from '../../context/WorkforceContext';
import {
  FileText,
  AlertCircle,
  Clock,
  ShieldAlert,
  Send,
  CheckCircle2,
  Calendar,
  UserCheck,
  Building,
  ChevronRight,
  Eye,
} from 'lucide-react';
import { FiledFormRecord } from '../../types';

export const FormsCenter: React.FC = () => {
  const { forms, fileForm, assignment, user } = useWorkforce();
  const [activeFormType, setActiveFormType] = useState<
    'Call-in-Sick' | 'Running-Late Ticket' | 'Incident Report'
  >('Running-Late Ticket');
  const [successToast, setSuccessToast] = useState<string | null>(null);
  const [selectedFormDetail, setSelectedFormDetail] = useState<FiledFormRecord | null>(null);

  // Form states:
  // 1. Call-in-Sick
  const [sickDate, setSickDate] = useState(new Date().toISOString().split('T')[0]);
  const [sickReason, setSickReason] = useState('Acute fever and respiratory symptoms');
  const [sickReturnDate, setSickReturnDate] = useState(
    new Date(Date.now() + 86400000).toISOString().split('T')[0]
  );
  const [sickShift, setSickShift] = useState(assignment?.startTime || 'Day Shift (06:30 - 15:00)');

  // 2. Running-Late
  const [minutesLate, setMinutesLate] = useState(20);
  const [lateReason, setLateReason] = useState('Severe highway traffic on I-285 loop');
  const [updatedETA, setUpdatedETA] = useState('06:50 AM');

  // 3. Incident Report
  const [incidentType, setIncidentType] = useState('Equipment / Near-Miss');
  const [incidentLocation, setIncidentLocation] = useState(
    assignment?.siteAddress || 'Employ Avenue Logistics Hub 4, Staging Bay 14'
  );
  const [incidentNarrative, setIncidentNarrative] = useState('');
  const [incidentWitnesses, setIncidentWitnesses] = useState('');
  const [medicalSought, setMedicalSought] = useState('No');

  const handleSickSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fileForm('Call-in-Sick', {
      dateOfAbsence: sickDate,
      reason: sickReason,
      expectedReturnDate: sickReturnDate,
      shiftMissed: sickShift,
      supervisor: assignment?.supervisorName || 'Dispatch Supervisor',
      site: assignment?.clientName || 'Assigned Site',
    });
    setSuccessToast('Mandatory Call-in-Sick Notice logged and sent to agency.');
    setTimeout(() => setSuccessToast(null), 3000);
  };

  const handleLateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fileForm('Running-Late Ticket', {
      date: new Date().toISOString().split('T')[0],
      estimatedMinutesLate: minutesLate,
      reason: lateReason,
      updatedETA,
      supervisor: assignment?.supervisorName || 'Floor Supervisor',
      agencyDispatchNotified: true,
      site: assignment?.siteAddress || 'Current Assignment Site',
    });
    setSuccessToast(
      'Running-Late ticket delivered simultaneously to Site Supervisor and Agency Dispatch.'
    );
    setTimeout(() => setSuccessToast(null), 3000);
  };

  const handleIncidentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!incidentNarrative.trim()) return;
    fileForm('Incident Report', {
      incidentType,
      location: incidentLocation,
      narrative: incidentNarrative,
      witnesses: incidentWitnesses || 'None',
      medicalTreatmentSought: medicalSought,
      reportedBy: user?.fullName || 'Worker',
    });
    setSuccessToast('Official Incident Report registered and logged for OSHA audit review.');
    setTimeout(() => setSuccessToast(null), 3000);
    setIncidentNarrative('');
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-[#0E2652] border border-[#1E4383] rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span className="text-xs font-poppins text-[#C9A227] uppercase tracking-widest font-bold flex items-center gap-1.5">
              <AlertCircle className="w-4 h-4" />
              <span>Official Compliance & Attendance Desk</span>
            </span>
            <h2 className="text-2xl font-horizon font-bold text-white tracking-wider">
              Staffing Forms Center
            </h2>
            <p className="mt-1 text-xs font-oswald text-white/70">
              Submit mandatory daily attendance notices and safety incidents. Every filed form stays
              permanently listed on your profile record with timestamps and supervisor acknowledgment.
            </p>
          </div>
        </div>

        {/* Form Type Selector Tabs */}
        <div className="mt-6 pt-5 border-t border-[#1E4383] flex flex-wrap gap-2">
          {[
            { id: 'Running-Late Ticket', label: '1. Running-Late Ticket', icon: Clock },
            { id: 'Call-in-Sick', label: '2. Call-in-Sick Form (Mandatory)', icon: FileText },
            { id: 'Incident Report', label: '3. Incident Report', icon: ShieldAlert },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeFormType === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveFormType(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl font-oswald text-xs uppercase tracking-wider transition ${
                  isActive
                    ? 'bg-[#C9A227] text-[#0A1F44] font-bold shadow'
                    : 'bg-[#06132B] text-white/70 hover:text-white border border-[#1E4383]'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {successToast && (
        <div className="p-4 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-oswald text-xs flex items-center gap-2 shadow-lg">
          <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
          <span>{successToast}</span>
        </div>
      )}

      {/* ACTIVE FORM CONTAINER */}
      <div className="bg-[#0E2652] border border-[#1E4383] rounded-2xl p-6 shadow-xl">
        {/* 1. RUNNING LATE TICKET */}
        {activeFormType === 'Running-Late Ticket' && (
          <form onSubmit={handleLateSubmit} className="space-y-4">
            <div className="border-b border-[#1E4383] pb-3">
              <h3 className="font-poppins font-bold text-base text-white flex items-center gap-2">
                <Clock className="w-5 h-5 text-[#C9A227]" />
                <span>Submit Running-Late Ticket</span>
              </h3>
              <p className="text-xs font-oswald text-white/70">
                Immediately transmits an automated SMS and portal alert to both{' '}
                <strong className="text-[#C9A227]">
                  {assignment?.supervisorName || 'Site Supervisor Dave Miller'}
                </strong>{' '}
                and the Employ Avenue Dispatch Desk.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                  Estimated Minutes Delayed *
                </label>
                <select
                  value={minutesLate}
                  onChange={(e) => setMinutesLate(parseInt(e.target.value))}
                  className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-xs focus:border-[#C9A227] outline-none"
                >
                  <option value={10}>10 Minutes</option>
                  <option value={15}>15 Minutes</option>
                  <option value={20}>20 Minutes</option>
                  <option value={30}>30 Minutes</option>
                  <option value={45}>45 Minutes</option>
                  <option value={60}>60+ Minutes (Call Dispatch)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                  New Estimated Arrival Time (ETA) *
                </label>
                <input
                  type="text"
                  required
                  value={updatedETA}
                  onChange={(e) => setUpdatedETA(e.target.value)}
                  placeholder="e.g. 06:50 AM"
                  className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-xs focus:border-[#C9A227] outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                  Assigned Facility / Bay
                </label>
                <input
                  type="text"
                  disabled
                  value={assignment?.siteAddress || 'Employ Avenue Logistics Hub 4, Dock Bay 14'}
                  className="w-full px-3 py-2 bg-[#06132B]/60 border border-[#1E4383] rounded-lg text-white/60 font-oswald text-xs"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                Reason for Delay *
              </label>
              <textarea
                required
                rows={2}
                value={lateReason}
                onChange={(e) => setLateReason(e.target.value)}
                placeholder="e.g. Major accident on highway I-285, vehicle stalled in center lane; moving safely now."
                className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-xs focus:border-[#C9A227] outline-none"
              />
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-[#C9A227] hover:bg-[#DBB535] text-[#0A1F44] font-horizon font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 shadow"
              >
                <Send className="w-4 h-4" />
                <span>Send Running-Late Ticket</span>
              </button>
            </div>
          </form>
        )}

        {/* 2. CALL-IN-SICK FORM */}
        {activeFormType === 'Call-in-Sick' && (
          <form onSubmit={handleSickSubmit} className="space-y-4">
            <div className="border-b border-[#1E4383] pb-3">
              <h3 className="font-poppins font-bold text-base text-white flex items-center gap-2">
                <FileText className="w-5 h-5 text-[#C9A227]" />
                <span>Mandatory Call-in-Sick Absence Form</span>
              </h3>
              <p className="text-xs font-oswald text-white/70">
                Agency policy requires submission at least 2 hours before scheduled shift start to
                arrange qualified replacement coverage.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                  Date of Absence *
                </label>
                <input
                  type="date"
                  required
                  value={sickDate}
                  onChange={(e) => setSickDate(e.target.value)}
                  className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-xs focus:border-[#C9A227] outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                  Shift Scheduled *
                </label>
                <input
                  type="text"
                  required
                  value={sickShift}
                  onChange={(e) => setSickShift(e.target.value)}
                  className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-xs focus:border-[#C9A227] outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                  Estimated Return-To-Work Date *
                </label>
                <input
                  type="date"
                  required
                  value={sickReturnDate}
                  onChange={(e) => setSickReturnDate(e.target.value)}
                  className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-xs focus:border-[#C9A227] outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                Reason / Wellness Condition (Confidential) *
              </label>
              <textarea
                required
                rows={2}
                value={sickReason}
                onChange={(e) => setSickReason(e.target.value)}
                placeholder="Briefly state symptoms (e.g. fever, food illness, medical appointment)..."
                className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-xs focus:border-[#C9A227] outline-none"
              />
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#C9A227] to-[#DBB535] text-[#0A1F44] font-horizon font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 shadow"
              >
                <Send className="w-4 h-4" />
                <span>Submit Sick Day Form</span>
              </button>
            </div>
          </form>
        )}

        {/* 3. INCIDENT REPORT */}
        {activeFormType === 'Incident Report' && (
          <form onSubmit={handleIncidentSubmit} className="space-y-4">
            <div className="border-b border-[#1E4383] pb-3">
              <h3 className="font-poppins font-bold text-base text-white flex items-center gap-2">
                <ShieldAlert className="w-5 h-5 text-rose-400" />
                <span>Workplace Safety & Incident Report</span>
              </h3>
              <p className="text-xs font-oswald text-white/70">
                Mandatory reporting for any worker injury, equipment collision, hazard, or near-miss
                at any client work facility.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                  Incident Classification *
                </label>
                <select
                  value={incidentType}
                  onChange={(e) => setIncidentType(e.target.value)}
                  className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-xs focus:border-[#C9A227] outline-none"
                >
                  <option value="Near-Miss (No Injury)">Near-Miss (No Injury)</option>
                  <option value="Minor Worker Injury">Minor Worker Injury (First Aid)</option>
                  <option value="Equipment / Forklift Damage">Equipment / Forklift Damage</option>
                  <option value="Spill / Environmental Hazard">Spill / Environmental Hazard</option>
                  <option value="Property / Pallet Rack Collision">
                    Property / Pallet Rack Collision
                  </option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                  Specific Facility Location / Dock *
                </label>
                <input
                  type="text"
                  required
                  value={incidentLocation}
                  onChange={(e) => setIncidentLocation(e.target.value)}
                  placeholder="e.g. Staging Dock Bay 14"
                  className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-xs focus:border-[#C9A227] outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                  Medical Attention Required?
                </label>
                <select
                  value={medicalSought}
                  onChange={(e) => setMedicalSought(e.target.value)}
                  className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-xs"
                >
                  <option value="No">No - First Aid Only</option>
                  <option value="Yes - Onsite Nurse">Yes - Onsite Nurse Station</option>
                  <option value="Yes - Urgent Care / Hospital">Yes - Urgent Care / ER</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                Detailed Incident Narrative *
              </label>
              <textarea
                required
                rows={3}
                value={incidentNarrative}
                onChange={(e) => setIncidentNarrative(e.target.value)}
                placeholder="Explain chronologically what happened, equipment involved, immediate actions taken, and who was notified..."
                className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-xs focus:border-[#C9A227] outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                Witness Names & Contact
              </label>
              <input
                type="text"
                value={incidentWitnesses}
                onChange={(e) => setIncidentWitnesses(e.target.value)}
                placeholder="e.g. Lead Operator Ken Miller, Badge #412"
                className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-xs"
              />
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-rose-500 hover:bg-rose-600 text-white font-horizon font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 shadow"
              >
                <Send className="w-4 h-4" />
                <span>Submit Safety Incident Report</span>
              </button>
            </div>
          </form>
        )}
      </div>

      {/* FILED FORMS HISTORY RECORD */}
      <div className="bg-[#0E2652] border border-[#1E4383] rounded-2xl p-6 shadow-xl space-y-4">
        <div className="border-b border-[#1E4383] pb-3 flex justify-between items-center">
          <div>
            <h3 className="font-poppins font-bold text-base text-white">
              Permanent Attendance & Incident Record
            </h3>
            <p className="text-xs font-oswald text-white/60">
              Every filed form stays permanently listed on your profile.
            </p>
          </div>
          <span className="text-xs font-oswald text-[#C9A227]">
            {forms.length} Filed Records
          </span>
        </div>

        <div className="space-y-3">
          {forms.map((item) => (
            <div
              key={item.id}
              className="p-4 bg-[#06132B] rounded-xl border border-[#1E4383] hover:border-[#C9A227]/50 transition flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs font-oswald"
            >
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                      item.type === 'Incident Report'
                        ? 'bg-rose-500/20 text-rose-300'
                        : item.type === 'Call-in-Sick'
                        ? 'bg-amber-500/20 text-amber-300'
                        : 'bg-sky-500/20 text-sky-300'
                    }`}
                  >
                    {item.type}
                  </span>
                  <span className="text-white/60">Record ID: {item.id}</span>
                  <span className="text-[#C9A227]">({item.filedAt})</span>
                </div>
                <p className="text-white/80 font-medium">
                  {item.details.reason || item.details.note || item.details.narrative || 'Notice filed'}
                </p>
                {item.resolutionNotes && (
                  <p className="text-[11px] text-white/50 mt-1 italic">
                    Resolution note: {item.resolutionNotes}
                  </p>
                )}
              </div>

              <div className="flex items-center gap-2 sm:self-center">
                <span className="px-2.5 py-1 rounded bg-[#13336E] text-white font-semibold border border-[#1E4383] text-[11px]">
                  {item.status}
                </span>
                <button
                  type="button"
                  onClick={() => setSelectedFormDetail(item)}
                  className="p-1.5 rounded-lg bg-[#0E2652] hover:bg-[#1E4383] text-[#C9A227]"
                  title="View Record Full Details"
                >
                  <Eye className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* FORM DETAIL MODAL */}
      {selectedFormDetail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#0E2652] border-2 border-[#1E4383] rounded-2xl max-w-lg w-full p-6 shadow-2xl relative">
            <div className="flex justify-between items-start pb-3 border-b border-[#1E4383]">
              <div>
                <span className="text-[10px] font-poppins font-bold text-[#C9A227] uppercase">
                  Permanent Filing Confirmation
                </span>
                <h3 className="font-poppins font-bold text-lg text-white">
                  {selectedFormDetail.type} (#{selectedFormDetail.id})
                </h3>
              </div>
              <button
                onClick={() => setSelectedFormDetail(null)}
                className="text-white/60 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="my-4 space-y-3 p-4 bg-[#06132B] rounded-xl border border-[#1E4383] text-xs font-oswald">
              <p>
                <strong className="text-white/60">Timestamp: </strong>
                <span className="text-white">{selectedFormDetail.filedAt}</span>
              </p>
              <p>
                <strong className="text-white/60">Dispatch Status: </strong>
                <span className="text-emerald-400 font-semibold">
                  {selectedFormDetail.status}
                </span>
              </p>
              <div className="pt-2 border-t border-[#1E4383]">
                <strong className="text-[#C9A227] uppercase block mb-1">Field Data:</strong>
                <pre className="p-2 bg-[#0A1F44] rounded text-[11px] text-white/90 overflow-x-auto whitespace-pre-wrap font-mono">
                  {JSON.stringify(selectedFormDetail.details, null, 2)}
                </pre>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setSelectedFormDetail(null)}
                className="px-4 py-2 rounded-lg bg-[#C9A227] text-[#0A1F44] font-oswald font-bold text-xs uppercase"
              >
                Close Record
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
