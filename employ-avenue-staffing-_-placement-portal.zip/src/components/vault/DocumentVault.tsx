import React, { useState } from 'react';
import { useWorkforce } from '../../context/WorkforceContext';
import {
  ShieldCheck,
  FileText,
  Download,
  Upload,
  Eye,
  RefreshCw,
  Plus,
  CheckCircle2,
  Lock,
  Calendar,
  AlertCircle,
  FileCheck2,
} from 'lucide-react';
import { DocumentRecord } from '../../types';

export const DocumentVault: React.FC = () => {
  const { documents, uploadDocument, application } = useWorkforce();
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [previewDoc, setPreviewDoc] = useState<DocumentRecord | null>(null);
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<DocumentRecord['category']>('Certification');
  const [newFileName, setNewFileName] = useState('');

  const categories = ['All', 'Resume', 'Tax Form', 'Consent', 'Identification', 'Certification'];

  const filteredDocs = documents.filter(
    (d) => selectedCategory === 'All' || d.category === selectedCategory
  );

  const handleUploadSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newFileName) return;

    uploadDocument({
      title: newTitle,
      category: newCategory,
      fileName: newFileName,
      fileSize: '740 KB',
      status: newCategory === 'Identification' ? 'Pending Live Video Check' : 'Verified',
    });

    setUploadModalOpen(false);
    setNewTitle('');
    setNewFileName('');
  };

  const handleSimulateDownload = (doc: DocumentRecord) => {
    // Generate text blob for user's downloadable file
    const content = `EMPLOY AVENUE STAFFING DOCUMENT VAULT RECORD\n=====================================\nDocument: ${doc.title}\nCategory: ${doc.category}\nFile Name: ${doc.fileName}\nUpload/Sign Date: ${doc.uploadDate}\nVerification Status: ${doc.status}\nWorker: ${application.firstName} ${application.lastName}\nEncrypted Storage ID: ${doc.id}\nSigned Authenticity Token: SHA256-${Date.now()}-EA`;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = doc.fileName || `${doc.title.replace(/\s+/g, '_')}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-[#0E2652] border border-[#1E4383] rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span className="text-xs font-poppins text-[#C9A227] uppercase tracking-widest font-bold flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4" />
              <span>Encrypted Worker Record Repository</span>
            </span>
            <h2 className="text-2xl font-horizon font-bold text-white tracking-wider">
              The Document Vault
            </h2>
            <p className="mt-1 text-xs font-oswald text-white/70">
              Your personal file locker. Stored master resume, signed W-4, I-9 Section 1, 4 agency
              consents, government photo IDs, and safety certifications—downloadable anytime.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setUploadModalOpen(true)}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#C9A227] to-[#DBB535] hover:from-[#DBB535] hover:to-[#C9A227] text-[#0A1F44] font-horizon font-bold text-xs uppercase tracking-wider transition shadow-md flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Upload Document</span>
            </button>
          </div>
        </div>

        {/* Category Filter Pills */}
        <div className="mt-6 pt-5 border-t border-[#1E4383] flex flex-wrap gap-2">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-lg font-oswald text-xs uppercase tracking-wider transition ${
                selectedCategory === cat
                  ? 'bg-[#C9A227] text-[#0A1F44] font-bold shadow'
                  : 'bg-[#06132B] text-white/70 hover:text-white border border-[#1E4383]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Documents Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredDocs.map((doc) => {
          const isSigned = doc.status === 'Signed' || doc.status === 'Verified';
          const isPendingVideo = doc.status === 'Pending Live Video Check';

          return (
            <div
              key={doc.id}
              className="bg-[#0E2652] rounded-2xl border border-[#1E4383] hover:border-[#C9A227]/60 p-5 shadow-lg flex flex-col justify-between transition group"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-poppins font-bold uppercase tracking-wider text-[#C9A227] bg-[#06132B] px-2.5 py-0.5 rounded-full border border-[#1E4383]">
                    {doc.category}
                  </span>
                  <span
                    className={`text-[10px] font-oswald uppercase px-2 py-0.5 rounded-full font-semibold ${
                      isSigned
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : isPendingVideo
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                        : 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                    }`}
                  >
                    {doc.status}
                  </span>
                </div>

                <h3 className="font-poppins font-bold text-base text-white group-hover:text-[#C9A227] transition">
                  {doc.title}
                </h3>

                <div className="mt-2 text-xs font-oswald text-white/70 space-y-0.5">
                  <p>
                    File: <span className="text-white font-mono">{doc.fileName}</span> (
                    {doc.fileSize})
                  </p>
                  <p className="text-white/50">
                    Timestamp: {doc.signedDate ? `Signed ${doc.signedDate}` : `Uploaded ${doc.uploadDate}`}
                  </p>
                </div>

                {isPendingVideo && (
                  <div className="mt-2.5 p-2 bg-[#06132B] rounded-lg border border-amber-500/40 text-[11px] font-oswald text-amber-200 flex items-center gap-1.5">
                    <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />
                    <span>Checked live on recruiter video call during Section 2 review.</span>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="mt-5 pt-3 border-t border-[#1E4383] flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => setPreviewDoc(doc)}
                  className="px-3 py-1.5 rounded-lg bg-[#06132B] hover:bg-[#13336E] text-white/90 text-xs font-oswald uppercase tracking-wider transition flex items-center gap-1.5"
                >
                  <Eye className="w-3.5 h-3.5 text-[#C9A227]" />
                  <span>Preview File</span>
                </button>

                <div className="flex items-center gap-2">
                  {doc.category === 'Resume' && (
                    <label className="cursor-pointer px-3 py-1.5 rounded-lg bg-[#13336E] hover:bg-[#1E4383] text-[#C9A227] text-xs font-oswald uppercase tracking-wider transition flex items-center gap-1 border border-[#C9A227]/40">
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Replace</span>
                      <input
                        type="file"
                        className="hidden"
                        accept=".pdf,.docx,.doc"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            uploadDocument({
                              title: 'Master Industrial & Assembly Resume',
                              category: 'Resume',
                              fileName: file.name,
                              fileSize: '430 KB',
                              status: 'Verified',
                            });
                          }
                        }}
                      />
                    </label>
                  )}

                  <button
                    type="button"
                    onClick={() => handleSimulateDownload(doc)}
                    className="px-3.5 py-1.5 rounded-lg bg-[#C9A227] hover:bg-[#DBB535] text-[#0A1F44] font-oswald font-bold text-xs uppercase tracking-wider transition flex items-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download Copy</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* DOCUMENT PREVIEW MODAL */}
      {previewDoc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#0E2652] border-2 border-[#1E4383] rounded-2xl max-w-xl w-full p-6 shadow-2xl relative">
            <div className="flex justify-between items-start pb-3 border-b border-[#1E4383]">
              <div className="flex items-center gap-2">
                <FileCheck2 className="w-5 h-5 text-[#C9A227]" />
                <div>
                  <h3 className="font-poppins font-bold text-base text-white">
                    {previewDoc.title}
                  </h3>
                  <p className="font-oswald text-xs text-white/60">
                    File: {previewDoc.fileName} • {previewDoc.fileSize}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setPreviewDoc(null)}
                className="text-white/60 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="my-4 p-5 bg-[#06132B] rounded-xl border border-[#1E4383] space-y-3 font-oswald text-xs text-white/80">
              <div className="flex justify-between border-b border-[#1E4383] pb-2 text-[11px] text-white/60">
                <span>Category: {previewDoc.category}</span>
                <span className="text-[#C9A227] font-semibold">{previewDoc.status}</span>
              </div>
              <p>
                This document is securely stored on your permanent profile. Our systems encrypt all
                statutory documents and transmit authenticated duplicates for audit compliance.
              </p>
              <div className="p-3 bg-[#0A1F44] rounded-lg border border-[#1E4383] text-white">
                <span className="text-[10px] uppercase text-[#C9A227] block font-bold mb-1">
                  Digital Signature Attestation
                </span>
                <p className="italic">
                  "Digitally signed and certified by {application.firstName} {application.lastName} on{' '}
                  {previewDoc.signedDate || previewDoc.uploadDate}."
                </p>
              </div>
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <button
                onClick={() => setPreviewDoc(null)}
                className="px-4 py-2 rounded-lg bg-[#06132B] text-white font-oswald text-xs uppercase"
              >
                Close Preview
              </button>
              <button
                onClick={() => handleSimulateDownload(previewDoc)}
                className="px-5 py-2 rounded-lg bg-[#C9A227] hover:bg-[#DBB535] text-[#0A1F44] font-oswald font-bold text-xs uppercase flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download File</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* UPLOAD DOCUMENT MODAL */}
      {uploadModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#0E2652] border-2 border-[#1E4383] rounded-2xl max-w-md w-full p-6 shadow-2xl relative">
            <div className="flex justify-between items-center pb-3 border-b border-[#1E4383]">
              <h3 className="font-horizon text-base font-bold text-white uppercase tracking-wider">
                Upload New Document / Certification
              </h3>
              <button
                onClick={() => setUploadModalOpen(false)}
                className="text-white/60 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleUploadSubmit} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                  Document Title *
                </label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. OSHA 30-Hour Construction Card"
                  className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-xs focus:border-[#C9A227] outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                  Category *
                </label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as any)}
                  className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-xs focus:border-[#C9A227] outline-none"
                >
                  <option value="Certification">Certification & Trade License</option>
                  <option value="Identification">Identification (ID / Passport / SSN)</option>
                  <option value="Resume">Updated Resume</option>
                  <option value="Tax Form">Tax / Direct Deposit Void Check</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                  Choose File (PDF, JPG, PNG) *
                </label>
                <div className="p-4 bg-[#06132B] rounded-xl border border-dashed border-[#1E4383] text-center">
                  <Upload className="w-5 h-5 text-[#C9A227] mx-auto mb-1" />
                  <span className="text-xs font-oswald text-white/80 block">
                    {newFileName || 'Select document to store'}
                  </span>
                  <input
                    type="file"
                    required
                    className="text-xs text-white/60 mt-1"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        setNewFileName(file.name);
                        if (!newTitle) setNewTitle(file.name.replace(/\.[^/.]+$/, ''));
                      }
                    }}
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setUploadModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-[#06132B] text-white font-oswald text-xs uppercase"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 rounded-lg bg-[#C9A227] hover:bg-[#DBB535] text-[#0A1F44] font-oswald font-bold text-xs uppercase tracking-wider"
                >
                  Save to Vault
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
