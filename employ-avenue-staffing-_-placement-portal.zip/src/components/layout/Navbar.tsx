import React, { useState } from 'react';
import { useWorkforce } from '../../context/WorkforceContext';
import {
  Briefcase,
  Calendar,
  CheckCircle2,
  Clock,
  FileCheck2,
  FileText,
  HelpCircle,
  LogOut,
  Mail,
  Menu,
  ShieldCheck,
  User,
  Users,
  X,
  Sparkles,
  Languages,
} from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenApplication: () => void;
  onOpenInterview: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  onOpenApplication,
  onOpenInterview,
}) => {
  const { user, logout, completeness, toggleAvailability, loadDemoAccount, assignment, language, setLanguage } = useWorkforce();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);
  const [moreDropdownOpen, setMoreDropdownOpen] = useState(false);

  const moreDropdownRef = React.useRef<HTMLDivElement>(null);
  const profileDropdownRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as Node;
      if (moreDropdownRef.current && !moreDropdownRef.current.contains(target)) {
        setMoreDropdownOpen(false);
      }
      if (profileDropdownRef.current && !profileDropdownRef.current.contains(target)) {
        setProfileDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Briefcase },
    { id: 'jobs', label: 'Job Openings', icon: Briefcase },
    { id: 'hours', label: 'Hours & Pay', icon: Clock },
    { id: 'paystubs', label: 'Pay Stubs', icon: FileCheck2 },
    { id: 'vault', label: 'Document Vault', icon: ShieldCheck },
    { id: 'forms', label: 'Forms Center', icon: FileText },
    { id: 'messages', label: 'Messages & Offers', icon: Mail },
    { id: 'career', label: 'Sherpa AI', icon: Sparkles },
    { id: 'referrals', label: 'Referrals ($100)', icon: Users },
    { id: 'profile', label: 'My Profile', icon: User },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-sm">
      {/* Top Banner Notice for Quick Demos & Save State + Language Selector */}
      <div className="bg-[#0A1F44] border-b border-[#1E4383]/60 px-4 py-1.5 text-xs text-white/90 flex flex-wrap items-center justify-between gap-3">
        {/* Left: Autosave notice */}
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-[#C9A227] animate-pulse"></span>
          <span className="font-oswald tracking-wide">
            Employ Avenue Permanent Profile Active: All applications, forms, & documents autosave continuously.
          </span>
        </div>

        {/* Center: Language Select between Spanish and English (English default) */}
        <div className="flex items-center gap-2 bg-[#06132B]/80 px-2.5 py-0.5 rounded-full border border-[#C9A227]/40 shadow-xs mx-auto md:mx-0">
          <Languages className="w-3.5 h-3.5 text-[#C9A227] shrink-0" />
          <span className="text-[11px] font-oswald text-white/70 hidden sm:inline">Language:</span>
          <div className="inline-flex rounded-md p-0.5 bg-[#0A1F44]">
            <button
              type="button"
              onClick={() => setLanguage('en')}
              className={`px-2.5 py-0.5 rounded text-[11px] font-poppins font-bold transition-all cursor-pointer ${
                language === 'en'
                  ? 'bg-[#C9A227] text-[#0A1F44] shadow-xs'
                  : 'text-white/80 hover:text-white'
              }`}
              title="English (Default)"
            >
              English
            </button>
            <button
              type="button"
              onClick={() => setLanguage('es')}
              className={`px-2.5 py-0.5 rounded text-[11px] font-poppins font-bold transition-all cursor-pointer ${
                language === 'es'
                  ? 'bg-[#C9A227] text-[#0A1F44] shadow-xs'
                  : 'text-white/80 hover:text-white'
              }`}
              title="Español"
            >
              Español
            </button>
          </div>
        </div>

        {/* Right: Demo Profiles */}
        <div className="flex items-center gap-2 font-oswald">
          <span className="text-white/70">Demo Profiles:</span>
          <button
            onClick={() => loadDemoAccount('marcus')}
            className="px-2 py-0.5 rounded bg-[#13336E] hover:bg-[#1E4383] text-[#C9A227] font-medium border border-[#C9A227]/40 transition text-[11px]"
            title="Load Marcus Vance (Assigned Lead Assembler)"
          >
            Marcus (Assigned)
          </button>
          <button
            onClick={() => loadDemoAccount('fresh')}
            className="px-2 py-0.5 rounded bg-[#13336E] hover:bg-[#1E4383] text-white/90 font-medium border border-white/20 transition text-[11px]"
            title="Load Brand New Candidate to test fresh application"
          >
            Alex (New Applicant)
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Left section: Logo separated with breathing room and divider */}
          <div className="flex items-center gap-5 lg:gap-7 xl:gap-8">
            <div className="flex items-center shrink-0 pr-4 lg:pr-6 border-r border-slate-200">
              <button
                onClick={() => setActiveTab('dashboard')}
                className="flex items-center group text-left cursor-pointer py-0.5 focus:outline-none"
                title="Employ Avenue Staffing"
              >
                <img
                  src="/assets/aistudio/Staffing_agency_logo_7ec39da1.png"
                  alt="Employ Avenue Staffing"
                  className="h-9 sm:h-10 w-auto object-contain group-hover:scale-105 transition-transform"
                />
              </button>
            </div>

            {/* Desktop Navigation - Slim, No Icons, Dashboard written out completely */}
            <nav className="hidden lg:flex items-center gap-1 xl:gap-1.5">
              {navItems.slice(0, 6).map((item) => {
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    title={item.label}
                    className={`px-2.5 py-1 rounded transition uppercase font-oswald text-xs tracking-wider whitespace-nowrap ${
                      isActive
                        ? 'bg-[#C9A227] text-[#0A1F44] shadow-sm font-bold'
                        : 'text-slate-700 hover:text-[#0A1F44] hover:bg-slate-100 font-medium'
                    }`}
                  >
                    {item.label}
                  </button>
                );
              })}

              {/* More dropdown - Clickable and easy to use */}
              <div className="relative" ref={moreDropdownRef}>
                <button
                  type="button"
                  onClick={() => setMoreDropdownOpen((prev) => !prev)}
                  aria-expanded={moreDropdownOpen}
                  aria-haspopup="true"
                  title="More Navigation Options"
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded font-oswald text-xs tracking-wider uppercase transition whitespace-nowrap cursor-pointer select-none ${
                    moreDropdownOpen || ['messages', 'career', 'referrals', 'profile'].includes(activeTab)
                      ? 'text-[#0A1F44] bg-[#C9A227] font-bold shadow-sm'
                      : 'text-slate-700 hover:text-[#0A1F44] hover:bg-slate-100 font-medium'
                  }`}
                >
                  <span>More</span>
                  <span
                    className={`text-[9px] transition-transform duration-200 ${
                      moreDropdownOpen ? 'rotate-180 text-[#0A1F44]' : 'text-slate-500'
                    }`}
                  >
                    ▼
                  </span>
                </button>

                {moreDropdownOpen && (
                  <div className="absolute left-0 mt-1 w-52 bg-white border border-slate-200 rounded-xl shadow-2xl py-1.5 z-50 animate-in fade-in zoom-in-95 duration-100">
                    {navItems.slice(6).map((item) => {
                      const isActive = activeTab === item.id;
                      return (
                        <button
                          key={item.id}
                          onClick={() => {
                            setActiveTab(item.id);
                            setMoreDropdownOpen(false);
                          }}
                          className={`w-full flex items-center justify-between px-3.5 py-2 text-left font-oswald text-xs tracking-wider uppercase transition ${
                            isActive
                              ? 'bg-[#C9A227] text-[#0A1F44] font-bold'
                              : 'text-slate-700 hover:text-[#0A1F44] hover:bg-slate-50 font-medium'
                          }`}
                        >
                          <span>{item.label}</span>
                          {isActive && <span className="text-[10px] text-[#0A1F44] font-bold">●</span>}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            </nav>
          </div>

          {/* Right Controls: Availability switch, user info, logout */}
          <div className="flex items-center gap-3">
            {/* Availability Pill Switch - Compact */}
            {user && (
              <div className="hidden sm:flex items-center bg-slate-100 border border-slate-300 rounded-full px-2.5 py-0.5 gap-1.5 shadow-sm">
                <span className="text-[11px] font-oswald uppercase tracking-wide text-slate-600">
                  Available This Week:
                </span>
                <button
                  type="button"
                  onClick={() => toggleAvailability(!user.availableThisWeek)}
                  className={`relative inline-flex h-3.5 w-7 flex-shrink-0 cursor-pointer rounded-full border border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                    user.availableThisWeek ? 'bg-[#C9A227]' : 'bg-gray-400'
                  }`}
                  role="switch"
                  aria-checked={user.availableThisWeek}
                  title={user.availableThisWeek ? 'Click to mark unavailable' : 'Click to mark available'}
                >
                  <span
                    className={`pointer-events-none inline-block h-2.5 w-2.5 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out mt-[1px] ml-[1px] ${
                      user.availableThisWeek ? 'translate-x-3.5' : 'translate-x-0'
                    }`}
                  />
                </button>
                <span
                  className={`text-[10px] font-bold font-oswald uppercase ${
                    user.availableThisWeek ? 'text-[#0A1F44]' : 'text-gray-500'
                  }`}
                >
                  {user.availableThisWeek ? 'ON' : 'OFF'}
                </span>
              </div>
            )}

            {/* Profile Button */}
            {user && (
              <div className="relative" ref={profileDropdownRef}>
                <button
                  onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                  className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-slate-100 border border-slate-200 transition"
                >
                  <div className="w-8 h-8 rounded-full bg-[#0A1F44] border-2 border-[#C9A227] flex items-center justify-center text-[#C9A227] font-bold font-poppins text-xs">
                    {user.fullName
                      .split(' ')
                      .map((n) => n[0])
                      .join('')
                      .toUpperCase()
                      .slice(0, 2)}
                  </div>
                  <div className="hidden md:block text-left">
                    <p className="text-xs font-poppins font-semibold text-[#0A1F44] leading-tight">
                      {user.fullName}
                    </p>
                    <p className="text-[10px] font-oswald text-[#C9A227] tracking-wider uppercase font-bold">
                      {user.status}
                    </p>
                  </div>
                </button>

                {profileDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-64 bg-white border border-slate-200 rounded-xl shadow-2xl py-3 z-50">
                    <div className="px-4 py-2 border-b border-slate-200">
                      <p className="font-poppins font-bold text-sm text-[#0A1F44]">{user.fullName}</p>
                      <p className="text-xs text-slate-500 font-oswald truncate">{user.email}</p>
                      <div className="mt-2 flex items-center justify-between text-xs font-oswald">
                        <span className="text-slate-600">Profile Completeness:</span>
                        <span className="text-[#C9A227] font-bold">{completeness.percent}%</span>
                      </div>
                    </div>
                    <div className="py-1">
                      <button
                        onClick={() => {
                          setActiveTab('profile');
                          setProfileDropdownOpen(false);
                        }}
                        className="w-full flex items-center gap-2 px-4 py-2 text-sm font-oswald text-slate-700 hover:bg-slate-50"
                      >
                        <User className="w-4 h-4 text-[#C9A227]" />
                        <span>My Profile & Pay Method</span>
                      </button>
                      <button
                        onClick={() => {
                          onOpenApplication();
                          setProfileDropdownOpen(false);
                        }}
                        className="w-full flex items-center gap-2 px-4 py-2 text-sm font-oswald text-slate-700 hover:bg-slate-50"
                      >
                        <FileText className="w-4 h-4 text-[#C9A227]" />
                        <span>6-Step Application</span>
                      </button>
                      <button
                        onClick={() => {
                          onOpenInterview();
                          setProfileDropdownOpen(false);
                        }}
                        className="w-full flex items-center gap-2 px-4 py-2 text-sm font-oswald text-slate-700 hover:bg-slate-50"
                      >
                        <Calendar className="w-4 h-4 text-[#C9A227]" />
                        <span>Schedule Video Interview</span>
                      </button>
                    </div>
                    <div className="pt-2 border-t border-slate-200">
                      <button
                        onClick={() => {
                          logout();
                          setProfileDropdownOpen(false);
                        }}
                        className="w-full flex items-center gap-2 px-4 py-2 text-sm font-oswald text-rose-600 hover:bg-rose-50 transition"
                      >
                        <LogOut className="w-4 h-4" />
                        <span>Save & Log Out</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Mobile menu trigger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-lg text-slate-800 hover:bg-slate-100 transition"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#06132B] border-b border-[#1E4383] px-4 pt-2 pb-6 space-y-1">
          {/* Mobile Availability Toggle - Compact */}
          {user && (
            <div className="flex items-center justify-between px-3 py-2 bg-[#0E2652] rounded-lg mb-3 border border-[#1E4383]">
              <span className="text-xs font-oswald text-white/80">Available this week</span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => toggleAvailability(!user.availableThisWeek)}
                  className={`relative inline-flex h-4 w-8 flex-shrink-0 cursor-pointer rounded-full border border-transparent transition-colors duration-200 ease-in-out ${
                    user.availableThisWeek ? 'bg-[#C9A227]' : 'bg-gray-600'
                  }`}
                >
                  <span
                    className={`pointer-events-none inline-block h-3 w-3 transform rounded-full bg-white shadow transition duration-200 ease-in-out mt-[1px] ml-[1px] ${
                      user.availableThisWeek ? 'translate-x-4' : 'translate-x-0'
                    }`}
                  />
                </button>
                <span
                  className={`text-[11px] font-bold font-oswald ${
                    user.availableThisWeek ? 'text-[#C9A227]' : 'text-gray-400'
                  }`}
                >
                  {user.availableThisWeek ? 'ON' : 'OFF'}
                </span>
              </div>
            </div>
          )}

          <div className="grid grid-cols-2 gap-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`flex items-center gap-2 px-3 py-2.5 rounded-lg font-oswald text-sm font-medium tracking-wide uppercase transition ${
                    isActive
                      ? 'bg-[#C9A227] text-[#0A1F44] font-bold'
                      : 'text-white/80 hover:bg-[#13336E]'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </div>

          <div className="pt-4 border-t border-[#1E4383] flex gap-2">
            <button
              onClick={() => {
                onOpenApplication();
                setMobileMenuOpen(false);
              }}
              className="flex-1 py-2 px-3 rounded-lg bg-[#C9A227] text-[#0A1F44] font-oswald font-bold text-sm uppercase text-center"
            >
              Open Application
            </button>
            <button
              onClick={() => {
                logout();
                setMobileMenuOpen(false);
              }}
              className="py-2 px-3 rounded-lg bg-rose-500/20 text-rose-400 border border-rose-500/30 font-oswald font-medium text-sm uppercase"
            >
              Logout
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
