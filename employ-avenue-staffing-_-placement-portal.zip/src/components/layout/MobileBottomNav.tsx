import React from 'react';
import {
  LayoutDashboard,
  Briefcase,
  Clock,
  FileText,
  Menu,
  ShieldCheck,
  User,
} from 'lucide-react';
import { useWorkforce } from '../../context/WorkforceContext';

interface MobileBottomNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenMenu: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  activeTab,
  setActiveTab,
  onOpenMenu,
}) => {
  const { offers, user } = useWorkforce();
  const pendingOffersCount = offers.filter((o) => o.status === 'Pending').length;

  const tabs = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'jobs', label: 'Openings', icon: Briefcase, badge: pendingOffersCount > 0 ? pendingOffersCount : undefined },
    { id: 'hours', label: 'Hours & Pay', icon: Clock },
    { id: 'forms', label: 'Forms', icon: FileText },
    { id: 'profile', label: 'Profile', icon: User },
  ];

  return (
    <nav
      aria-label="Mobile Navigation"
      className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 shadow-[0_-4px_20px_rgba(10,31,68,0.08)] px-2 py-1.5 transition-all"
    >
      <div className="max-w-md mx-auto grid grid-cols-5 items-center">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition-all relative ${
                isActive
                  ? 'text-[#0A1F44]'
                  : 'text-slate-500 hover:text-slate-900 active:scale-95'
              }`}
            >
              <div
                className={`w-9 h-7 rounded-lg flex items-center justify-center transition-all ${
                  isActive ? 'bg-[#C9A227] text-[#0A1F44] shadow-sm font-bold' : ''
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'stroke-[2.5]' : 'stroke-2'}`} />
              </div>
              <span
                className={`text-[10px] font-oswald uppercase tracking-wider mt-0.5 ${
                  isActive ? 'font-bold text-[#0A1F44]' : 'font-medium text-slate-500'
                }`}
              >
                {tab.label}
              </span>

              {tab.badge && (
                <span className="absolute top-1 right-2 w-4 h-4 bg-emerald-500 text-white rounded-full text-[9px] font-bold flex items-center justify-center ring-2 ring-white">
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
