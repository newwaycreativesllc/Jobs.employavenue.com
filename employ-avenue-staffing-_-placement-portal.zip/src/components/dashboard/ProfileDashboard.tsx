import React, { useState } from 'react';
import { useWorkforce } from '../../context/WorkforceContext';
import {
  MapPin,
  Clock,
  UserCheck,
  ShieldAlert,
  Navigation,
  CheckCircle2,
  AlertCircle,
  Calendar,
  ExternalLink,
  ChevronRight,
  Briefcase,
  Sparkles,
  Phone,
  FileCheck2,
  Layers,
  ArrowRight,
  Send,
  Video,
} from 'lucide-react';
import { ApplicationStatus } from '../../types';

interface ProfileDashboardProps {
  onOpenApplication: (step?: number) => void;
  onOpenInterview: () => void;
  onOpenVideoRoom: () => void;
  setActiveTab: (tab: string) => void;
}

export const ProfileDashboard: React.FC<ProfileDashboardProps> = ({
  onOpenApplication,
  onOpenInterview,
  onOpenVideoRoom,
  setActiveTab,
}) => {
  const {
    user,
    completeness,
    assignment,
    confirmForTomorrow,
    markOnMyWay,
    toggleAvailability,
    offers,
    application,
    setUserStatus,
  } = useWorkforce();

  const [directionsModalOpen, setDirectionsModalOpen] = useState(false);
  const [checklistModalOpen, setChecklistModalOpen] = useState(false);

  const trackerSteps: ApplicationStatus[] = [
    'Applied',
    'Screened',
    'Interview',
    'Documents',
    'On the Roster',
  ];

  const currentStatusIndex = user ? trackerSteps.indexOf(user.status) : 0;

  const pendingOffersCount = offers.filter((o) => o.status === 'Pending').length;

  return (
    <div className="space-y-6">
      {/* 1. STATUS TRACKER - ALWAYS VISIBLE AT THE TOP */}
      <div className="bg-[#0E2652] border border-[#1E4383] rounded-2xl p-5 shadow-xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div>
            <span className="text-[11px] font-poppins text-[#C9A227] uppercase tracking-widest font-bold">
              Official Placement Status
            </span>
            <h2 className="text-xl sm:text-2xl font-poppins font-bold text-white flex items-center gap-2">
              <span>Candidate Career Pipeline</span>
              <span className="text-xs bg-[#C9A227]/20 border border-[#C9A227] text-[#C9A227] px-2.5 py-0.5 rounded-full font-oswald uppercase tracking-wider">
                Current: {user?.status || 'Applied'}
              </span>
            </h2>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-oswald text-white/60">Simulate Pipeline:</span>
            <select
              value={user?.status || 'Applied'}
              onChange={(e) => setUserStatus(e.target.value as ApplicationStatus)}
              className="bg-[#06132B] border border-[#1E4383] text-[#C9A227] text-xs font-oswald rounded px-2 py-1 outline-none focus:border-[#C9A227]"
            >
              {trackerSteps.map((st) => (
                <option key={st} value={st}>
                  {st}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Tracker Progress Bar with Steppers */}
        <div className="relative mt-2 mb-2">
          {/* Connecting Line */}
          <div className="absolute top-1/2 left-4 right-4 -translate-y-1/2 h-1 bg-[#13336E] z-0">
            <div
              className="h-full bg-gradient-to-r from-[#C9A227] to-[#DBB535] transition-all duration-500"
              style={{
                width: `${(currentStatusIndex / (trackerSteps.length - 1)) * 100}%`,
              }}
            />
          </div>

          <div className="grid grid-cols-5 relative z-10">
            {trackerSteps.map((step, idx) => {
              const isPast = idx < currentStatusIndex;
              const isCurrent = idx === currentStatusIndex;
              const isFuture = idx > currentStatusIndex;

              return (
                <div key={step} className="flex flex-col items-center text-center px-1">
                  <div
                    className={`w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center font-horizon font-bold text-xs transition-all duration-300 ${
                      isCurrent
                        ? 'bg-[#C9A227] text-[#0A1F44] ring-4 ring-[#C9A227]/30 scale-110 shadow-lg shadow-[#C9A227]/40'
                        : isPast
                        ? 'bg-[#1E4383] text-[#C9A227] border-2 border-[#C9A227]'
                        : 'bg-[#06132B] text-white/40 border border-[#1E4383]'
                    }`}
                  >
                    {isPast ? <CheckCircle2 className="w-5 h-5" /> : idx + 1}
                  </div>
                  <span
                    className={`mt-2 font-oswald text-[11px] sm:text-xs uppercase tracking-wider font-semibold ${
                      isCurrent
                        ? 'text-[#C9A227] font-bold'
                        : isPast
                        ? 'text-white'
                        : 'text-white/40'
                    }`}
                  >
                    {step}
                  </span>
                  <span className="hidden md:block text-[10px] text-white/50 font-oswald">
                    {idx === 0 && 'Profile Submitted'}
                    {idx === 1 && 'Skills Evaluated'}
                    {idx === 2 && 'Video 1-on-1'}
                    {idx === 3 && 'I-9 & Tax Check'}
                    {idx === 4 && 'Shift Ready'}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* 2. PROFILE COMPLETENESS METER & CHECKLIST */}
      <div className="bg-gradient-to-r from-[#0E2652] via-[#102B5E] to-[#0E2652] border border-[#C9A227]/30 rounded-2xl p-5 shadow-lg relative">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex-1">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-xs font-poppins font-bold uppercase tracking-wider text-[#C9A227] flex items-center gap-1.5">
                <Sparkles className="w-4 h-4" />
                <span>Profile Completeness Meter</span>
              </span>
              <span className="font-horizon text-xl font-bold text-[#C9A227]">
                {completeness.percent}%
              </span>
            </div>

            {/* Progress bar */}
            <div className="w-full h-3 bg-[#06132B] rounded-full overflow-hidden border border-[#1E4383] p-0.5">
              <div
                className="h-full bg-gradient-to-r from-[#9B7A15] via-[#C9A227] to-[#F7E7B4] rounded-full transition-all duration-700 shadow-sm"
                style={{ width: `${completeness.percent}%` }}
              />
            </div>

            {/* Explicit sentence naming what's missing */}
            <p className="mt-2 text-sm font-oswald text-white/90">
              <span className="text-[#C9A227] font-semibold">{completeness.summaryText}</span>
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setChecklistModalOpen(true)}
              className="px-4 py-2.5 rounded-xl bg-[#06132B] hover:bg-[#13336E] border border-[#1E4383] text-white text-xs font-oswald uppercase tracking-wider font-semibold transition flex items-center gap-1.5"
            >
              <span>View Checklist</span>
              <ChevronRight className="w-4 h-4 text-[#C9A227]" />
            </button>

            {completeness.percent < 100 && (
              <button
                onClick={() => onOpenApplication()}
                className="px-5 py-2.5 rounded-xl bg-[#C9A227] hover:bg-[#DBB535] text-[#0A1F44] font-horizon font-bold text-xs uppercase tracking-wider transition shadow-md shadow-[#C9A227]/20 flex items-center gap-1.5"
              >
                <span>Complete Application</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* QUICK NOTICES & INTERVIEW CALLOUT */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Scheduled Interview Banner */}
        {user?.interviewSlot?.confirmed ? (
          <div className="bg-[#06132B] border border-[#C9A227]/50 rounded-xl p-4 flex items-center justify-between gap-3 shadow-md">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-[#C9A227]/15 border border-[#C9A227] flex items-center justify-center text-[#C9A227]">
                <Video className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-poppins font-bold text-[#C9A227] uppercase tracking-wide">
                  Video Interview Confirmed
                </p>
                <p className="text-sm font-poppins font-semibold text-white">
                  {user.interviewSlot.date} at {user.interviewSlot.time}
                </p>
                <p className="text-xs font-oswald text-white/60">
                  With {user.interviewSlot.recruiterName} ({user.interviewSlot.recruiterTitle})
                </p>
              </div>
            </div>
            <button
              onClick={onOpenVideoRoom}
              className="px-4 py-2 rounded-lg bg-[#C9A227] hover:bg-[#DBB535] text-[#0A1F44] font-oswald font-bold text-xs uppercase tracking-wider shadow-md transition flex items-center gap-1.5 flex-shrink-0"
            >
              <Video className="w-4 h-4" />
              <span>Join Video Room</span>
            </button>
          </div>
        ) : (
          <div className="bg-[#06132B] border border-[#1E4383] rounded-xl p-4 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-[#13336E] flex items-center justify-center text-white/70">
                <Calendar className="w-5 h-5 text-[#C9A227]" />
              </div>
              <div>
                <p className="text-xs font-poppins font-bold text-white uppercase tracking-wide">
                  Schedule Recruiter Video Call
                </p>
                <p className="text-xs font-oswald text-white/70">
                  Pick a 15-minute slot for live document check and placement match.
                </p>
              </div>
            </div>
            <button
              onClick={onOpenInterview}
              className="px-3.5 py-2 rounded-lg bg-[#13336E] hover:bg-[#1E4383] text-[#C9A227] border border-[#C9A227]/40 font-oswald font-bold text-xs uppercase tracking-wider transition flex-shrink-0"
            >
              Book Time Slot
            </button>
          </div>
        )}

        {/* Offers Inbox Alert */}
        {pendingOffersCount > 0 ? (
          <div className="bg-[#06132B] border border-emerald-500/40 rounded-xl p-4 flex items-center justify-between gap-3 shadow-md">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-emerald-500/20 border border-emerald-500/50 flex items-center justify-center text-emerald-400">
                <Briefcase className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                  <p className="text-xs font-poppins font-bold text-emerald-400 uppercase tracking-wide">
                    {pendingOffersCount} New Shift Offer Waiting!
                  </p>
                </div>
                <p className="text-xs font-oswald text-white/80">
                  Direct client match released with instant accept.
                </p>
              </div>
            </div>
            <button
              onClick={() => setActiveTab('messages')}
              className="px-4 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-[#0A1F44] font-oswald font-bold text-xs uppercase tracking-wider transition flex items-center gap-1 flex-shrink-0"
            >
              <span>Review Offers</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        ) : (
          <div className="bg-[#06132B] border border-[#1E4383] rounded-xl p-4 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-[#13336E] flex items-center justify-center text-white/70">
                <Clock className="w-5 h-5 text-[#C9A227]" />
              </div>
              <div>
                <p className="text-xs font-poppins font-bold text-white uppercase tracking-wide">
                  Weekly Availability
                </p>
                <p className="text-xs font-oswald text-white/70">
                  {user?.availableThisWeek
                    ? 'You are active for shift dispatch this week.'
                    : 'Turn on your availability switch to receive assignment calls.'}
                </p>
              </div>
            </div>
            <button
              onClick={() => toggleAvailability(!user?.availableThisWeek)}
              className={`px-3.5 py-1.5 rounded-lg font-oswald font-bold text-xs uppercase transition ${
                user?.availableThisWeek
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                  : 'bg-gray-700 text-gray-300'
              }`}
            >
              {user?.availableThisWeek ? 'Available' : 'Set Available'}
            </button>
          </div>
        )}
      </div>

      {/* 3. "MY ASSIGNMENT" CARD */}
      <div className="bg-[#0E2652] border-2 border-[#C9A227] rounded-2xl shadow-2xl overflow-hidden relative">
        {/* Gold Ribbon Header */}
        <div className="bg-gradient-to-r from-[#9B7A15] via-[#C9A227] to-[#DBB535] px-6 py-3.5 text-[#0A1F44] flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Briefcase className="w-5 h-5 font-black" />
            <h2 className="font-horizon text-lg font-black tracking-wider uppercase">
              My Active Assignment
            </h2>
          </div>
          <div className="flex items-center gap-2">
            <span className="bg-[#0A1F44] text-[#C9A227] px-3 py-1 rounded-full font-oswald font-bold text-xs tracking-wider uppercase">
              {assignment ? `${assignment.status} Dispatch` : 'No Active Assignment'}
            </span>
          </div>
        </div>

        {assignment ? (
          <div className="p-6 space-y-6">
            {/* Top row: Job title & client */}
            <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-[#1E4383] gap-3">
              <div>
                <h3 className="text-2xl font-poppins font-bold text-white">{assignment.jobTitle}</h3>
                <p className="text-sm font-poppins text-[#C9A227] font-semibold">
                  {assignment.clientName}
                </p>
              </div>
              <div className="text-left md:text-right">
                <span className="text-xs font-oswald text-white/60 uppercase tracking-wider block">
                  Hourly Rate
                </span>
                <span className="font-horizon text-2xl font-bold text-white">
                  ${assignment.hourlyRate.toFixed(2)}
                  <span className="text-xs font-oswald font-normal text-white/60"> / hr</span>
                </span>
              </div>
            </div>

            {/* Core Details Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {/* Site Address & Gate */}
              <div className="bg-[#06132B] p-4 rounded-xl border border-[#1E4383]">
                <div className="flex items-center gap-2 text-[#C9A227] mb-1">
                  <MapPin className="w-4 h-4" />
                  <span className="text-xs font-poppins font-bold uppercase tracking-wider">
                    Site Location & Gate
                  </span>
                </div>
                <p className="font-oswald text-sm text-white font-medium">
                  {assignment.siteAddress}
                </p>
                <div className="mt-2 pt-2 border-t border-[#1E4383]/60 text-xs font-oswald text-white/70">
                  <span className="text-[#C9A227] font-semibold">Access Point: </span>
                  {assignment.dockOrGate}
                </div>
              </div>

              {/* Start Time & Duration */}
              <div className="bg-[#06132B] p-4 rounded-xl border border-[#1E4383]">
                <div className="flex items-center gap-2 text-[#C9A227] mb-1">
                  <Clock className="w-4 h-4" />
                  <span className="text-xs font-poppins font-bold uppercase tracking-wider">
                    Shift Timing
                  </span>
                </div>
                <p className="font-oswald text-lg text-white font-bold">
                  {assignment.startTime} – {assignment.endTime}
                </p>
                <div className="mt-1 text-xs font-oswald text-white/70">
                  Dates: {assignment.startDate} to {assignment.endDate}
                </div>
              </div>

              {/* Who to report to */}
              <div className="bg-[#06132B] p-4 rounded-xl border border-[#1E4383]">
                <div className="flex items-center gap-2 text-[#C9A227] mb-1">
                  <UserCheck className="w-4 h-4" />
                  <span className="text-xs font-poppins font-bold uppercase tracking-wider">
                    Who To Report To
                  </span>
                </div>
                <p className="font-oswald text-sm text-white font-bold">
                  {assignment.supervisorName}
                </p>
                <div className="mt-1 text-xs font-oswald text-white/70 flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-[#C9A227]" />
                  <span>{assignment.supervisorPhone}</span>
                </div>
              </div>
            </div>

            {/* What to wear & What to bring */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-1">
              {/* What to wear */}
              <div className="bg-[#06132B] p-4 rounded-xl border border-[#1E4383]">
                <span className="text-xs font-poppins font-bold text-[#C9A227] uppercase tracking-wider block mb-2">
                  What To Wear (Dress Code)
                </span>
                <ul className="space-y-1.5">
                  {assignment.dressCode.map((item, i) => (
                    <li key={i} className="flex items-start gap-2 text-xs font-oswald text-white/80">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#C9A227] mt-1.5 flex-shrink-0" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* What to bring */}
              <div className="bg-[#06132B] p-4 rounded-xl border border-[#1E4383]">
                <span className="text-xs font-poppins font-bold text-[#C9A227] uppercase tracking-wider block mb-2">
                  What To Bring (Mandatory Items)
                </span>
                <ul className="space-y-1.5">
                  {assignment.requiredItems.map((item, i) => (
                    <li key={i} className="flex items-start gap-2 text-xs font-oswald text-white/80">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 mt-0.5 flex-shrink-0" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
                <div className="mt-3 pt-2 border-t border-[#1E4383]/60 text-[11px] font-oswald text-white/60">
                  <span className="text-[#C9A227] font-semibold">Special Briefing: </span>
                  {assignment.specialInstructions}
                </div>
              </div>
            </div>

            {/* ACTION BUTTONS ROW: Directions, Confirm for tomorrow, I'm on my way */}
            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
              {/* One-tap directions */}
              <button
                onClick={() => setDirectionsModalOpen(true)}
                className="px-4 py-3 rounded-xl bg-[#06132B] hover:bg-[#13336E] border border-[#1E4383] text-[#C9A227] font-oswald font-semibold text-sm tracking-wider uppercase transition flex items-center justify-center gap-2 shadow-sm"
              >
                <Navigation className="w-4 h-4" />
                <span>One-Tap Directions</span>
              </button>

              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
                {/* Confirm for tomorrow */}
                <button
                  onClick={confirmForTomorrow}
                  className={`px-5 py-3 rounded-xl font-oswald font-bold text-sm tracking-wider uppercase transition flex items-center justify-center gap-2 ${
                    assignment.confirmedForTomorrow
                      ? 'bg-emerald-600/30 border border-emerald-500 text-emerald-300'
                      : 'bg-[#13336E] hover:bg-[#1E4383] border border-[#C9A227]/40 text-white'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>
                    {assignment.confirmedForTomorrow
                      ? 'Confirmed for Tomorrow ✓'
                      : 'Confirm for Tomorrow'}
                  </span>
                </button>

                {/* I'm on my way */}
                <button
                  onClick={markOnMyWay}
                  className={`px-6 py-3 rounded-xl font-horizon font-bold text-sm tracking-wider uppercase transition flex items-center justify-center gap-2 shadow-lg ${
                    assignment.onMyWay
                      ? 'bg-amber-500 text-[#0A1F44] ring-2 ring-amber-300'
                      : 'bg-gradient-to-r from-[#C9A227] to-[#DBB535] hover:from-[#DBB535] hover:to-[#C9A227] text-[#0A1F44] shadow-[#C9A227]/25'
                  }`}
                >
                  <Send className="w-4 h-4" />
                  <span>{assignment.onMyWay ? "En Route Reported" : "I'm On My Way"}</span>
                </button>
              </div>
            </div>

            {/* Confirmation status feedback */}
            {(assignment.confirmedForTomorrow || assignment.onMyWay) && (
              <div className="p-3 bg-[#06132B] rounded-lg border border-[#1E4383] text-xs font-oswald flex flex-wrap items-center justify-between gap-2 text-white/80">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                  <span>
                    {assignment.confirmedForTomorrow &&
                      `Tomorrow's shift confirmed (${assignment.confirmedTimestamp || 'Logged'}).`}
                    {assignment.onMyWay &&
                      ` ${assignment.onMyWayTimestamp || 'Supervisor notified you are en route.'}`}
                  </span>
                </div>
                <span className="text-[#C9A227] font-semibold">
                  Employ Avenue Dispatch Auto-Sync Active
                </span>
              </div>
            )}
          </div>
        ) : (
          <div className="p-8 text-center space-y-4">
            <p className="text-white/70 font-oswald text-base">
              You currently do not have an active assignment assigned to your profile.
            </p>
            <div className="flex justify-center gap-3">
              <button
                onClick={() => setActiveTab('jobs')}
                className="px-5 py-2.5 rounded-xl bg-[#C9A227] hover:bg-[#DBB535] text-[#0A1F44] font-oswald font-bold text-sm uppercase"
              >
                Browse Job Openings
              </button>
              {offers.length > 0 && (
                <button
                  onClick={() => setActiveTab('messages')}
                  className="px-5 py-2.5 rounded-xl bg-[#13336E] hover:bg-[#1E4383] text-white font-oswald font-semibold text-sm uppercase"
                >
                  Check Offers Inbox ({offers.length})
                </button>
              )}
            </div>
          </div>
        )}
      </div>

      {/* 4. DASHBOARD QUICK ACCESS CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Hours this week */}
        <button
          onClick={() => setActiveTab('hours')}
          className="bg-[#0E2652] hover:bg-[#13336E]/70 border border-[#1E4383] rounded-xl p-4 text-left transition group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-poppins text-white/70 font-semibold uppercase">
              Hours Logged
            </span>
            <Clock className="w-4 h-4 text-[#C9A227] group-hover:scale-110 transition" />
          </div>
          <p className="font-horizon text-2xl font-bold text-white">40.5 hrs</p>
          <p className="text-xs font-oswald text-[#C9A227] mt-1">Expected Pay: $951.75</p>
        </button>

        {/* Card 2: Document Vault */}
        <button
          onClick={() => setActiveTab('vault')}
          className="bg-[#0E2652] hover:bg-[#13336E]/70 border border-[#1E4383] rounded-xl p-4 text-left transition group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-poppins text-white/70 font-semibold uppercase">
              The Vault
            </span>
            <FileCheck2 className="w-4 h-4 text-[#C9A227] group-hover:scale-110 transition" />
          </div>
          <p className="font-horizon text-2xl font-bold text-white">8 Files</p>
          <p className="text-xs font-oswald text-emerald-400 mt-1">W-4, I-9 & Consents Saved</p>
        </button>

        {/* Card 3: Forms Center */}
        <button
          onClick={() => setActiveTab('forms')}
          className="bg-[#0E2652] hover:bg-[#13336E]/70 border border-[#1E4383] rounded-xl p-4 text-left transition group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-poppins text-white/70 font-semibold uppercase">
              Staffing Forms
            </span>
            <AlertCircle className="w-4 h-4 text-[#C9A227] group-hover:scale-110 transition" />
          </div>
          <p className="font-horizon text-lg font-bold text-white">Sick / Late / Incident</p>
          <p className="text-xs font-oswald text-white/60 mt-1">Instant Supervisor Dispatch</p>
        </button>

        {/* Card 4: Referrals */}
        <button
          onClick={() => setActiveTab('referrals')}
          className="bg-[#0E2652] hover:bg-[#13336E]/70 border border-[#1E4383] rounded-xl p-4 text-left transition group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-poppins text-white/70 font-semibold uppercase">
              Referral Rewards
            </span>
            <Sparkles className="w-4 h-4 text-[#C9A227] group-hover:scale-110 transition" />
          </div>
          <p className="font-horizon text-2xl font-bold text-[#C9A227]">$100 Earned</p>
          <p className="text-xs font-oswald text-white/60 mt-1">3 Candidates Referred</p>
        </button>
      </div>

      {/* CHECKLIST MODAL */}
      {checklistModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
          <div className="bg-[#0E2652] border border-[#1E4383] rounded-2xl max-w-lg w-full p-6 shadow-2xl relative">
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-[#1E4383]">
              <div>
                <h3 className="font-poppins font-bold text-lg text-white">
                  Profile Completeness Checklist
                </h3>
                <p className="font-oswald text-xs text-[#C9A227]">
                  {completeness.percent}% Complete — All items permanently saved to your profile
                </p>
              </div>
              <button
                onClick={() => setChecklistModalOpen(false)}
                className="text-white/60 hover:text-white p-1 rounded-lg"
              >
                ✕
              </button>
            </div>

            <div className="space-y-2.5 max-h-[60vh] overflow-y-auto pr-1">
              {[
                {
                  id: 'step1',
                  label: 'Step 1: Basic info + Texting consent',
                  done: Boolean(
                    application.firstName && application.phone && application.smsConsent
                  ),
                  action: () => {
                    setChecklistModalOpen(false);
                    onOpenApplication(1);
                  },
                },
                {
                  id: 'step2',
                  label: 'Step 2: Resume upload & work history parse',
                  done: Boolean(application.resumeFileName && application.skills.length > 0),
                  action: () => {
                    setChecklistModalOpen(false);
                    onOpenApplication(2);
                  },
                },
                {
                  id: 'step3',
                  label: 'Step 3: Job & shift interests for matching',
                  done: application.industryInterests.length > 0,
                  action: () => {
                    setChecklistModalOpen(false);
                    onOpenApplication(3);
                  },
                },
                {
                  id: 'step4_w4',
                  label: 'Step 4: Form W-4 filled & signed in-app',
                  done: Boolean(application.w4Signature),
                  action: () => {
                    setChecklistModalOpen(false);
                    onOpenApplication(4);
                  },
                },
                {
                  id: 'step4_i9',
                  label: 'Step 4: Form I-9 Section 1 attestation & signature',
                  done: Boolean(application.i9Signature),
                  action: () => {
                    setChecklistModalOpen(false);
                    onOpenApplication(4);
                  },
                },
                {
                  id: 'step4_id',
                  label: 'Step 4: Photo upload for ID documents (checked live on video call)',
                  done: application.idDocumentUploaded,
                  action: () => {
                    setChecklistModalOpen(false);
                    onOpenApplication(4);
                  },
                },
                {
                  id: 'step5',
                  label: 'Step 5: Consents (Background, Drug Test, No-Fees, Policies)',
                  done: Boolean(
                    application.consentBackgroundCheck &&
                      application.consentDrugTest &&
                      application.consentNoFees &&
                      application.consentAgencyPolicies
                  ),
                  action: () => {
                    setChecklistModalOpen(false);
                    onOpenApplication(5);
                  },
                },
                {
                  id: 'step6',
                  label: 'Step 6: Review & Final Submit (flips to Applied)',
                  done: application.isSubmitted,
                  action: () => {
                    setChecklistModalOpen(false);
                    onOpenApplication(6);
                  },
                },
                {
                  id: 'interview',
                  label: 'Video Interview slot scheduled with recruiter',
                  done: Boolean(user?.interviewSlot?.confirmed),
                  action: () => {
                    setChecklistModalOpen(false);
                    onOpenInterview();
                  },
                },
                {
                  id: 'paymethod',
                  label: 'Direct deposit bank pay method configured',
                  done: Boolean(user?.routingNumber && user?.accountNumberMasked),
                  action: () => {
                    setChecklistModalOpen(false);
                    setActiveTab('profile');
                  },
                },
              ].map((item, idx) => (
                <div
                  key={item.id}
                  className={`p-3 rounded-xl border flex items-center justify-between gap-3 ${
                    item.done
                      ? 'bg-[#06132B]/80 border-emerald-500/30'
                      : 'bg-[#13336E]/40 border-[#1E4383]'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    {item.done ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                    ) : (
                      <div className="w-5 h-5 rounded-full border-2 border-white/30 flex items-center justify-center text-[10px] text-white/50 flex-shrink-0">
                        {idx + 1}
                      </div>
                    )}
                    <span
                      className={`text-xs font-oswald ${
                        item.done ? 'text-white/90 line-through' : 'text-white font-medium'
                      }`}
                    >
                      {item.label}
                    </span>
                  </div>

                  {!item.done && (
                    <button
                      onClick={item.action}
                      className="px-2.5 py-1 rounded bg-[#C9A227] hover:bg-[#DBB535] text-[#0A1F44] font-oswald font-bold text-[11px] uppercase tracking-wider flex-shrink-0"
                    >
                      Do Now
                    </button>
                  )}
                </div>
              ))}
            </div>

            <div className="mt-4 pt-3 border-t border-[#1E4383] flex justify-end">
              <button
                onClick={() => setChecklistModalOpen(false)}
                className="px-4 py-2 rounded-lg bg-[#06132B] hover:bg-[#13336E] text-white text-xs font-oswald uppercase"
              >
                Close Checklist
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ONE-TAP DIRECTIONS MODAL */}
      {directionsModalOpen && assignment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#0E2652] border border-[#C9A227] rounded-2xl max-w-lg w-full p-6 shadow-2xl relative">
            <div className="flex items-center justify-between pb-3 border-b border-[#1E4383]">
              <div className="flex items-center gap-2">
                <Navigation className="w-5 h-5 text-[#C9A227]" />
                <h3 className="font-horizon text-lg font-bold text-white uppercase tracking-wider">
                  Site Directions & Access
                </h3>
              </div>
              <button
                onClick={() => setDirectionsModalOpen(false)}
                className="text-white/60 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="mt-4 space-y-4">
              <div className="bg-[#06132B] p-4 rounded-xl border border-[#1E4383]">
                <p className="text-xs font-poppins text-[#C9A227] font-bold uppercase">
                  Facility Address
                </p>
                <p className="text-base font-oswald text-white font-semibold mt-1">
                  {assignment.siteAddress}
                </p>
                <p className="text-xs font-oswald text-white/70 mt-1">
                  Gate / Checkpoint: {assignment.dockOrGate}
                </p>
              </div>

              {/* Parking & Turnstiles notes */}
              <div className="p-3 bg-[#13336E]/40 rounded-xl border border-[#1E4383] text-xs font-oswald text-white/80 space-y-2">
                <p>
                  <strong className="text-[#C9A227]">Parking Access: </strong>
                  {assignment.parkingNotes}
                </p>
                <p>
                  <strong className="text-[#C9A227]">Supervisor on Site: </strong>
                  {assignment.supervisorName} — {assignment.supervisorPhone}
                </p>
              </div>

              {/* Map Preview Graphic */}
              <div className="relative h-44 rounded-xl overflow-hidden border border-[#1E4383] bg-[#06132B] flex flex-col items-center justify-center text-center p-4">
                <div className="w-12 h-12 rounded-full bg-[#C9A227]/20 border border-[#C9A227] flex items-center justify-center text-[#C9A227] mb-2 animate-bounce">
                  <MapPin className="w-6 h-6" />
                </div>
                <p className="font-poppins font-bold text-sm text-white">{assignment.clientName}</p>
                <p className="text-xs font-oswald text-white/60">
                  GPS Coordinates: 33.7490° N, 84.5120° W • Gate Clearance: Active
                </p>
              </div>

              {/* External Map Buttons */}
              <div className="grid grid-cols-2 gap-2 pt-2">
                <a
                  href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                    assignment.siteAddress
                  )}`}
                  target="_blank"
                  rel="noreferrer"
                  className="py-2.5 px-3 rounded-xl bg-[#C9A227] hover:bg-[#DBB535] text-[#0A1F44] font-oswald font-bold text-xs uppercase text-center flex items-center justify-center gap-1.5 shadow"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Google Maps</span>
                </a>
                <a
                  href={`https://maps.apple.com/?q=${encodeURIComponent(assignment.siteAddress)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="py-2.5 px-3 rounded-xl bg-[#06132B] hover:bg-[#13336E] text-white border border-[#1E4383] font-oswald font-semibold text-xs uppercase text-center flex items-center justify-center gap-1.5"
                >
                  <Navigation className="w-3.5 h-3.5 text-[#C9A227]" />
                  <span>Apple Maps</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
