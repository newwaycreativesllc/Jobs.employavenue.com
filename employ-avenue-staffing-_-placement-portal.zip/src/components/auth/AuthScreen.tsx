import React, { useState } from 'react';
import { useWorkforce } from '../../context/WorkforceContext';
import { ShieldCheck, Lock, Mail, User, Phone, ArrowRight, CheckCircle2, KeyRound, Sparkles } from 'lucide-react';

export const AuthScreen: React.FC = () => {
  const { login, signup, loadDemoAccount } = useWorkforce();
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [forgotPasswordOpen, setForgotPasswordOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotSubmitted, setForgotSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (isSignUp) {
      if (!fullName.trim() || !email.trim() || !password.trim()) {
        setErrorMessage('Please complete all required fields to create your permanent profile.');
        return;
      }
      signup(email, password, fullName, phone || '(555) 000-0000');
    } else {
      if (!email.trim() || !password.trim()) {
        setErrorMessage('Please enter both your email address and password.');
        return;
      }
      login(email, password);
    }
  };

  const handleForgotSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotEmail) return;
    setForgotSubmitted(true);
    setTimeout(() => {
      // Auto close after 3s
      setForgotPasswordOpen(false);
      setForgotSubmitted(false);
      setForgotEmail('');
    }, 3000);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8 relative overflow-hidden text-[#0A1F44]">
      {/* Decorative background geometry */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-[#C9A227]/10 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-[#0A1F44]/5 rounded-full blur-3xl pointer-events-none"></div>

      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center z-10 px-4">
        {/* Logo */}
        <div className="flex justify-center mb-6">
          <img
            src="/assets/aistudio/Staffing_agency_logo_7ec39da1.png"
            alt="Employ Avenue Staffing"
            className="h-20 sm:h-24 w-auto object-contain drop-shadow-md"
          />
        </div>
        <p className="text-xs font-oswald text-slate-600 max-w-sm mx-auto">
          One profile for your entire staffing journey. Everything you do—applications, hours, W-4,
          and pay stubs—is permanently saved.
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md z-10 px-4">
        <div className="bg-white py-8 px-6 sm:px-10 shadow-xl rounded-2xl border border-slate-200">
          {/* Tabs */}
          <div className="flex border-b border-slate-200 mb-6">
            <button
              onClick={() => {
                setIsSignUp(false);
                setErrorMessage('');
              }}
              className={`flex-1 py-3 text-center font-horizon text-sm tracking-wider uppercase transition border-b-2 ${
                !isSignUp
                  ? 'border-[#C9A227] text-[#0A1F44] font-bold'
                  : 'border-transparent text-slate-400 hover:text-slate-600'
              }`}
            >
              Sign In
            </button>
            <button
              onClick={() => {
                setIsSignUp(true);
                setErrorMessage('');
              }}
              className={`flex-1 py-3 text-center font-horizon text-sm tracking-wider uppercase transition border-b-2 ${
                isSignUp
                  ? 'border-[#C9A227] text-[#0A1F44] font-bold'
                  : 'border-transparent text-slate-400 hover:text-slate-600'
              }`}
            >
              Create Account
            </button>
          </div>

          {errorMessage && (
            <div className="mb-4 p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs font-oswald">
              {errorMessage}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {isSignUp && (
              <>
                <div>
                  <label className="block text-xs font-oswald uppercase tracking-wider text-slate-700 mb-1 font-semibold">
                    Full Legal Name *
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                      <User className="w-4 h-4" />
                    </div>
                    <input
                      type="text"
                      required
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="e.g. Marcus Vance"
                      className="w-full pl-10 pr-3 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-[#0A1F44] font-oswald text-sm focus:border-[#C9A227] focus:ring-1 focus:ring-[#C9A227] outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-oswald uppercase tracking-wider text-slate-700 mb-1 font-semibold">
                    Mobile Phone Number *
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                      <Phone className="w-4 h-4" />
                    </div>
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="(555) 000-0000"
                      className="w-full pl-10 pr-3 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-[#0A1F44] font-oswald text-sm focus:border-[#C9A227] focus:ring-1 focus:ring-[#C9A227] outline-none"
                    />
                  </div>
                </div>
              </>
            )}

            <div>
              <label className="block text-xs font-oswald uppercase tracking-wider text-slate-700 mb-1 font-semibold">
                Email Address *
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Mail className="w-4 h-4" />
                </div>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="worker@example.com"
                  className="w-full pl-10 pr-3 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-[#0A1F44] font-oswald text-sm focus:border-[#C9A227] focus:ring-1 focus:ring-[#C9A227] outline-none"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-oswald uppercase tracking-wider text-slate-700 font-semibold">
                  Password *
                </label>
                {!isSignUp && (
                  <button
                    type="button"
                    onClick={() => setForgotPasswordOpen(true)}
                    className="text-xs font-oswald text-[#0A1F44] font-semibold hover:text-[#C9A227]"
                  >
                    Forgot password?
                  </button>
                )}
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full pl-10 pr-3 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-[#0A1F44] font-oswald text-sm focus:border-[#C9A227] focus:ring-1 focus:ring-[#C9A227] outline-none"
                />
              </div>
            </div>

            {isSignUp && (
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs font-oswald text-slate-600 space-y-1">
                <div className="flex items-center gap-1.5 text-emerald-600 font-semibold">
                  <CheckCircle2 className="w-3.5 h-3.5 flex-shrink-0" />
                  <span>Permanent workforce profile created automatically</span>
                </div>
                <p className="text-[11px] text-slate-500">
                  Includes full Save & Close state across phones, tablets, and computers.
                </p>
              </div>
            )}

            <button
              type="submit"
              className="w-full mt-2 py-3 px-4 rounded-xl bg-gradient-to-r from-[#C9A227] to-[#DBB535] hover:from-[#DBB535] hover:to-[#C9A227] text-[#0A1F44] font-horizon font-bold text-base tracking-wider uppercase shadow-md shadow-[#C9A227]/30 flex items-center justify-center gap-2 transition hover:scale-[1.01]"
            >
              <span>{isSignUp ? 'Create Permanent Profile' : 'Sign In To Portal'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          {/* Quick Demo Logins Section */}
          <div className="mt-6 pt-6 border-t border-slate-200">
            <p className="text-center text-xs font-oswald uppercase tracking-wider text-slate-500 mb-3">
              Fast Demo Profiles (Instant Access)
            </p>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => {
                  loadDemoAccount('marcus');
                }}
                className="p-2.5 rounded-lg bg-slate-50 hover:bg-slate-100 border border-slate-200 text-left transition group"
              >
                <div className="flex items-center justify-between">
                  <span className="font-poppins font-semibold text-xs text-[#0A1F44] group-hover:text-[#C9A227]">
                    Marcus Vance
                  </span>
                  <span className="text-[10px] bg-[#C9A227]/20 text-[#0A1F44] font-bold px-1 rounded">Active</span>
                </div>
                <p className="text-[11px] font-oswald text-slate-500">Lead Assembler (Assigned)</p>
              </button>

              <button
                type="button"
                onClick={() => {
                  loadDemoAccount('fresh');
                }}
                className="p-2.5 rounded-lg bg-slate-50 hover:bg-slate-100 border border-slate-200 text-left transition group"
              >
                <div className="flex items-center justify-between">
                  <span className="font-poppins font-semibold text-xs text-[#0A1F44] group-hover:text-[#C9A227]">
                    Alex Taylor
                  </span>
                  <span className="text-[10px] bg-sky-100 text-sky-800 font-bold px-1 rounded">Fresh</span>
                </div>
                <p className="text-[11px] font-oswald text-slate-500">Test 6-Step Application</p>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Forgot Password Modal */}
      {forgotPasswordOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="bg-[#0E2652] border border-[#1E4383] rounded-2xl max-w-md w-full p-6 shadow-2xl relative">
            <h2 className="text-xl font-poppins font-bold text-white mb-2 flex items-center gap-2">
              <KeyRound className="w-5 h-5 text-[#C9A227]" />
              <span>Reset Your Password</span>
            </h2>
            <p className="text-xs font-oswald text-white/70 mb-4">
              Enter the email address tied to your Employ Avenue permanent profile. We'll send a direct reset
              link and secure SMS verification code.
            </p>

            {forgotSubmitted ? (
              <div className="p-4 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-sm font-oswald flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
                <span>
                  Password reset link dispatched to <strong>{forgotEmail}</strong>. Check your inbox
                  and text messages.
                </span>
              </div>
            ) : (
              <form onSubmit={handleForgotSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-oswald uppercase tracking-wider text-white/80 mb-1">
                    Your Profile Email
                  </label>
                  <input
                    type="email"
                    required
                    value={forgotEmail}
                    onChange={(e) => setForgotEmail(e.target.value)}
                    placeholder="worker@example.com"
                    className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-sm focus:border-[#C9A227] outline-none"
                  />
                </div>
                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setForgotPasswordOpen(false)}
                    className="px-4 py-2 rounded-lg bg-[#06132B] text-white/70 hover:text-white font-oswald text-sm"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-lg bg-[#C9A227] hover:bg-[#DBB535] text-[#0A1F44] font-oswald font-bold text-sm uppercase"
                  >
                    Send Reset Link
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
