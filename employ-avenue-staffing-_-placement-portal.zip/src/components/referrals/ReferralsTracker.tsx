import React, { useState } from 'react';
import { useWorkforce } from '../../context/WorkforceContext';
import { Users, DollarSign, UserPlus, CheckCircle2, Phone, Mail, Sparkles, Send } from 'lucide-react';

export const ReferralsTracker: React.FC = () => {
  const { referrals, addReferral } = useWorkforce();
  const [candidateName, setCandidateName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [tradeSkill, setTradeSkill] = useState('');
  const [submittedToast, setSubmittedToast] = useState(false);

  const totalEarned = referrals
    .filter((r) => r.rewardPaid)
    .reduce((acc, r) => acc + r.rewardAmount, 0);

  const pendingPotential = referrals
    .filter((r) => !r.rewardPaid)
    .reduce((acc, r) => acc + r.rewardAmount, 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!candidateName.trim() || !phone.trim()) return;

    addReferral({
      candidateName,
      phone,
      email: email || `${candidateName.toLowerCase().replace(/\s+/g, '.')}@example.com`,
      tradeSkill: tradeSkill || 'General Labor & Staging',
    });

    setSubmittedToast(true);
    setCandidateName('');
    setPhone('');
    setEmail('');
    setTradeSkill('');

    setTimeout(() => {
      setSubmittedToast(false);
    }, 3000);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-[#0E2652] border border-[#1E4383] rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span className="text-xs font-poppins text-[#C9A227] uppercase tracking-widest font-bold flex items-center gap-1.5">
              <Sparkles className="w-4 h-4" />
              <span>Employ Avenue Worker Referral Network</span>
            </span>
            <h2 className="text-2xl font-horizon font-bold text-white tracking-wider">
              Refer a Colleague & Earn $100
            </h2>
            <p className="mt-1 text-xs font-oswald text-white/70">
              Refer colleagues in warehousing, manufacturing, forklift operations, and logistics.
              When your referral completes their first 40 hours on assignment, you receive a $100
              bonus added directly to your weekly direct deposit.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="bg-[#06132B] px-4 py-3 rounded-xl border border-[#C9A227]/40 text-left md:text-right">
              <span className="text-[10px] font-oswald uppercase text-white/60 block">
                Total Bonuses Paid
              </span>
              <span className="font-horizon text-2xl font-bold text-[#C9A227]">
                ${totalEarned.toFixed(2)}
              </span>
            </div>
            <div className="bg-[#06132B] px-4 py-3 rounded-xl border border-[#1E4383] text-left md:text-right">
              <span className="text-[10px] font-oswald uppercase text-white/60 block">
                Pending Pipeline
              </span>
              <span className="font-horizon text-2xl font-bold text-emerald-400">
                ${pendingPotential.toFixed(2)}
              </span>
            </div>
          </div>
        </div>
      </div>

      {submittedToast && (
        <div className="p-4 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-oswald text-xs flex items-center gap-2 shadow-lg">
          <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
          <span>
            Referral successfully dispatched! An automated invitation SMS and onboarding link have
            been sent to the candidate.
          </span>
        </div>
      )}

      {/* Refer a Worker Form */}
      <div className="bg-[#0E2652] border border-[#1E4383] rounded-2xl p-6 shadow-xl">
        <h3 className="font-poppins font-bold text-base text-white flex items-center gap-2 mb-1">
          <UserPlus className="w-5 h-5 text-[#C9A227]" />
          <span>Refer a Worker by Name & Phone</span>
        </h3>
        <p className="text-xs font-oswald text-white/70 mb-5">
          Enter their contact details below. Our staffing recruiters will contact them within 4
          business hours.
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                Candidate Full Name *
              </label>
              <input
                type="text"
                required
                value={candidateName}
                onChange={(e) => setCandidateName(e.target.value)}
                placeholder="e.g. Jamal Washington"
                className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-xs focus:border-[#C9A227] outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                Mobile Phone *
              </label>
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="(555) 345-6712"
                className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-xs focus:border-[#C9A227] outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                Email Address
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="colleague@gmail.com"
                className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-xs focus:border-[#C9A227] outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-oswald uppercase text-white/80 mb-1">
                Primary Trade / Skill
              </label>
              <input
                type="text"
                value={tradeSkill}
                onChange={(e) => setTradeSkill(e.target.value)}
                placeholder="Forklift, Assembly, Logistics..."
                className="w-full px-3 py-2 bg-[#06132B] border border-[#1E4383] rounded-lg text-white font-oswald text-xs focus:border-[#C9A227] outline-none"
              />
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#C9A227] to-[#DBB535] hover:from-[#DBB535] hover:to-[#C9A227] text-[#0A1F44] font-horizon font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 shadow"
            >
              <Send className="w-4 h-4" />
              <span>Dispatch Referral ($100 Reward)</span>
            </button>
          </div>
        </form>
      </div>

      {/* Referrals Status Tracker */}
      <div className="bg-[#0E2652] border border-[#1E4383] rounded-2xl shadow-xl overflow-hidden">
        <div className="p-5 border-b border-[#1E4383] bg-[#06132B]/80 flex justify-between items-center">
          <h3 className="font-poppins font-bold text-base text-white">
            Referral Placement Status Tracker
          </h3>
          <span className="text-xs font-oswald text-[#C9A227]">
            {referrals.length} Total Candidates Tracked
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-oswald text-xs">
            <thead className="bg-[#06132B] text-white/70 uppercase border-b border-[#1E4383]">
              <tr>
                <th className="px-5 py-3 font-semibold">Candidate Name</th>
                <th className="px-5 py-3 font-semibold">Contact Info</th>
                <th className="px-5 py-3 font-semibold">Trade / Skill</th>
                <th className="px-5 py-3 font-semibold">Date Referred</th>
                <th className="px-5 py-3 font-semibold text-center">Status</th>
                <th className="px-5 py-3 font-semibold text-right">Referral Reward</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1E4383]/60">
              {referrals.map((ref) => {
                const isPlaced = ref.status === 'Placed';
                const isApplied = ref.status === 'Applied';
                const isInvited = ref.status === 'Invited';

                return (
                  <tr key={ref.id} className="hover:bg-[#13336E]/40 transition">
                    <td className="px-5 py-3.5 font-poppins font-bold text-white">
                      {ref.candidateName}
                    </td>
                    <td className="px-5 py-3.5 text-white/80">
                      <div>{ref.phone}</div>
                      <div className="text-[11px] text-white/50">{ref.email}</div>
                    </td>
                    <td className="px-5 py-3.5 text-white/90">{ref.tradeSkill}</td>
                    <td className="px-5 py-3.5 text-white/60">{ref.referredDate}</td>
                    <td className="px-5 py-3.5 text-center">
                      <span
                        className={`inline-flex items-center gap-1 px-3 py-0.5 rounded-full font-bold uppercase text-[11px] ${
                          isPlaced
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                            : isApplied
                            ? 'bg-[#C9A227]/20 text-[#C9A227] border border-[#C9A227]/40'
                            : 'bg-sky-500/20 text-sky-300 border border-sky-500/40'
                        }`}
                      >
                        {isPlaced && <CheckCircle2 className="w-3.5 h-3.5" />}
                        <span>{ref.status}</span>
                      </span>
                    </td>
                    <td className="px-5 py-3.5 text-right font-horizon text-sm font-bold">
                      {ref.rewardPaid ? (
                        <span className="text-emerald-400">$100.00 Paid ✓</span>
                      ) : isPlaced ? (
                        <span className="text-[#C9A227]">Processing ($100)</span>
                      ) : (
                        <span className="text-white/40">$100 (Upon 40 hrs)</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
