import React, { useState } from 'react';
import { WorkforceProvider, useWorkforce } from './context/WorkforceContext';
import { Navbar } from './components/layout/Navbar';
import { AuthScreen } from './components/auth/AuthScreen';
import { ProfileDashboard } from './components/dashboard/ProfileDashboard';
import { JobList } from './components/jobs/JobList';
import { HoursAndPay } from './components/hours/HoursAndPay';
import { PayStubs } from './components/paystubs/PayStubs';
import { DocumentVault } from './components/vault/DocumentVault';
import { FormsCenter } from './components/forms/FormsCenter';
import { MessagesAndOffers } from './components/messages/MessagesAndOffers';
import { CareerGuide } from './components/career/CareerGuide';
import { ReferralsTracker } from './components/referrals/ReferralsTracker';
import { MyProfile } from './components/profile/MyProfile';
import { MobileBottomNav } from './components/layout/MobileBottomNav';
import { ApplicationModal } from './components/application/ApplicationModal';
import { InterviewScheduleModal } from './components/interview/InterviewScheduleModal';
import { VideoInterviewRoom } from './components/interview/VideoInterviewRoom';

function MainApp() {
  const { user } = useWorkforce();
  const [activeTab, setActiveTab] = useState<string>('dashboard');

  // Global Modals
  const [applicationModalOpen, setApplicationModalOpen] = useState(false);
  const [applicationInitialStep, setApplicationInitialStep] = useState(1);
  const [interviewModalOpen, setInterviewModalOpen] = useState(false);
  const [videoRoomOpen, setVideoRoomOpen] = useState(false);

  const handleOpenApplication = (step = 1) => {
    setApplicationInitialStep(step);
    setApplicationModalOpen(true);
  };

  // If user is logged out, render the Front Door AuthScreen
  if (!user) {
    return <AuthScreen />;
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-[#0A1F44] flex flex-col font-oswald antialiased selection:bg-[#C9A227] selection:text-[#0A1F44]">
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenApplication={() => handleOpenApplication(1)}
        onOpenInterview={() => setInterviewModalOpen(true)}
      />

      {/* Main Container - with bottom clearance for mobile dock */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-5 sm:py-8 pb-24 lg:pb-8">
        {activeTab === 'dashboard' && (
          <ProfileDashboard
            onOpenApplication={handleOpenApplication}
            onOpenInterview={() => setInterviewModalOpen(true)}
            onOpenVideoRoom={() => setVideoRoomOpen(true)}
            setActiveTab={setActiveTab}
          />
        )}

        {activeTab === 'jobs' && <JobList />}

        {activeTab === 'hours' && <HoursAndPay />}

        {activeTab === 'paystubs' && <PayStubs />}

        {activeTab === 'vault' && <DocumentVault />}

        {activeTab === 'forms' && <FormsCenter />}

        {activeTab === 'messages' && <MessagesAndOffers />}

        {activeTab === 'career' && <CareerGuide />}

        {activeTab === 'referrals' && <ReferralsTracker />}

        {activeTab === 'profile' && <MyProfile />}
      </main>

      {/* Mobile Bottom Navigation Bar (Dock) */}
      <MobileBottomNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenMenu={() => {}}
      />

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-6 px-4 text-center text-xs font-oswald text-slate-600 shadow-sm mb-16 lg:mb-0">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <img
              src="/assets/aistudio/Staffing_agency_logo_7ec39da1.png"
              alt="Employ Avenue Staffing"
              className="h-8 w-auto object-contain"
            />
            <span className="text-[#C9A227]">•</span>
            <span className="font-semibold text-[#0A1F44]">E.A.S.E. Employ Avenue Staffing Ecosystem</span>
          </div>
          <div className="flex items-center gap-4 text-slate-500 text-[11px]">
            <span>Save & Close Guaranteed</span>
            <span>FCRA & OSHA Compliant</span>
            <span>ACH Encrypted Direct Deposit</span>
          </div>
        </div>
      </footer>

      {/* 6-Step Application Modal */}
      <ApplicationModal
        isOpen={applicationModalOpen}
        onClose={() => setApplicationModalOpen(false)}
        initialStep={applicationInitialStep}
      />

      {/* Schedule Interview Modal */}
      <InterviewScheduleModal
        isOpen={interviewModalOpen}
        onClose={() => setInterviewModalOpen(false)}
        onOpenVideoRoom={() => {
          setInterviewModalOpen(false);
          setVideoRoomOpen(true);
        }}
      />

      {/* Live Video Interview Room */}
      <VideoInterviewRoom
        isOpen={videoRoomOpen}
        onClose={() => setVideoRoomOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <WorkforceProvider>
      <MainApp />
    </WorkforceProvider>
  );
}
