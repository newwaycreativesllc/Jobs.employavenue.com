export type ApplicationStatus = 'Applied' | 'Screened' | 'Interview' | 'Documents' | 'On the Roster';

export interface WorkHistoryItem {
  id: string;
  employer: string;
  role: string;
  location: string;
  startDate: string;
  endDate: string;
  responsibilities: string;
}

export interface ApplicationData {
  // Step 1: Basic info
  firstName: string;
  lastName: string;
  preferredName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  ssnLast4: string;
  dob: string;
  emergencyName: string;
  emergencyRelation: string;
  emergencyPhone: string;
  smsConsent: boolean;

  // Step 2: Resume
  resumeFileName?: string;
  resumeFileDate?: string;
  skills: string[];
  workHistory: WorkHistoryItem[];
  parsedFromResume: boolean;

  // Step 3: Job Interests
  industryInterests: string[];
  shiftPreferences: string[];
  minHourlyRate: number;
  commuteRadiusMiles: number;
  hasOwnTransportation: boolean;
  willingToTravel: boolean;

  // Step 4: Tax & Verification
  w4FilingStatus: 'Single' | 'Married' | 'Head of Household';
  w4MultipleJobs: boolean;
  w4DependentsClaimed: number;
  w4ExtraWithholding: number;
  w4Signature: string;
  w4SignDate: string;

  i9CitizenshipStatus: 'citizen' | 'noncitizen' | 'permanent_resident' | 'authorized_alien';
  i9AlienNumber?: string;
  i9WorkAuthExpiry?: string;
  i9Signature: string;
  i9SignDate: string;
  idDocumentUploaded: boolean;
  idDocumentName?: string;
  secondaryDocumentUploaded: boolean;
  secondaryDocumentName?: string;

  // Step 5: Consents
  consentBackgroundCheck: boolean;
  backgroundSignature: string;
  backgroundSignDate: string;

  consentDrugTest: boolean;
  drugTestSignature: string;
  drugTestSignDate: string;

  consentNoFees: boolean;
  noFeesSignature: string;
  noFeesSignDate: string;

  consentAgencyPolicies: boolean;
  policiesSignature: string;
  policiesSignDate: string;

  // Progress
  currentStep: number; // 1 to 6
  isSubmitted: boolean;
  submittedAt?: string;
}

export interface Assignment {
  id: string;
  jobTitle: string;
  clientName: string;
  siteAddress: string;
  dockOrGate: string;
  startTime: string;
  endTime: string;
  startDate: string;
  endDate: string;
  hourlyRate: number;
  supervisorName: string;
  supervisorPhone: string;
  supervisorEmail: string;
  dressCode: string[];
  requiredItems: string[];
  parkingNotes: string;
  specialInstructions: string;
  confirmedForTomorrow: boolean;
  confirmedTimestamp?: string;
  onMyWay: boolean;
  onMyWayTimestamp?: string;
  status: 'Active' | 'Upcoming' | 'Completed';
}

export interface JobOpening {
  id: string;
  title: string;
  company: string;
  location: string;
  shift: '1st Shift (Day)' | '2nd Shift (Swing)' | '3rd Shift (Graveyard)' | 'Weekend';
  jobType: 'Warehouse' | 'Manufacturing' | 'Logistics' | 'Assembly' | 'Hospitality' | 'Quality Control';
  payRate: number;
  hoursPerWeek: number;
  spotsLeft: number;
  startDate: string;
  description: string;
  requirements: string[];
  applied: boolean;
  appliedDate?: string;
}

export interface DayHourEntry {
  id: string;
  date: string;
  dayOfWeek: string;
  site: string;
  shiftName: string;
  clockIn: string;
  clockOut: string;
  breakMinutes: number;
  hoursSubmitted: number;
  hoursApproved: number;
  status: 'Approved' | 'Pending Review' | 'Disputed';
}

export interface HoursDispute {
  id: string;
  entryId: string;
  date: string;
  submittedAt: string;
  siteName: string;
  reportedHours: number;
  expectedHours: number;
  reason: string;
  status: 'Open' | 'Under Investigation' | 'Adjusted & Resolved';
  supervisorNotes?: string;
}

export interface PayStub {
  id: string;
  stubNumber: string;
  payPeriodStart: string;
  payPeriodEnd: string;
  payDate: string;
  regularHours: number;
  overtimeHours: number;
  hourlyRate: number;
  overtimeRate: number;
  grossPay: number;
  deductions: {
    federalTax: number;
    stateTax: number;
    socialSecurity: number;
    medicare: number;
  };
  netPay: number;
  ytdGross: number;
  ytdNet: number;
  checkNumber: string;
}

export interface DocumentRecord {
  id: string;
  category: 'Resume' | 'Identification' | 'Tax Form' | 'Consent' | 'Certification';
  title: string;
  fileName: string;
  fileSize: string;
  uploadDate: string;
  status: 'Verified' | 'Pending Live Video Check' | 'Signed' | 'Active';
  signedDate?: string;
  downloadUrl?: string;
}

export interface FiledFormRecord {
  id: string;
  type: 'Call-in-Sick' | 'Running-Late Ticket' | 'Incident Report';
  filedAt: string;
  details: Record<string, any>;
  status: 'Delivered to Supervisor & Agency' | 'Acknowledged' | 'Under Investigation' | 'Resolved';
  resolutionNotes?: string;
}

export interface MessageThreadItem {
  id: string;
  sender: 'recruiter' | 'worker' | 'system';
  senderName: string;
  avatar?: string;
  content: string;
  timestamp: string;
  isOfferLink?: boolean;
}

export interface JobOffer {
  id: string;
  title: string;
  clientName: string;
  location: string;
  hourlyRate: number;
  shift: string;
  duration: string;
  startDate: string;
  supervisor: string;
  status: 'Pending' | 'Accepted' | 'Declined';
  receivedAt: string;
  assignmentDetails: Partial<Assignment>;
}

export interface CareerGoal {
  id: string;
  type: 'short-term' | 'long-term';
  title: string;
  category: 'Certification' | 'Savings' | 'Career Advancement' | 'Skill Mastery';
  targetDate: string;
  isCompleted: boolean;
  notes: string;
}

export interface Referral {
  id: string;
  candidateName: string;
  phone: string;
  email: string;
  tradeSkill: string;
  referredDate: string;
  status: 'Invited' | 'Applied' | 'Placed';
  rewardAmount: number;
  rewardPaid: boolean;
}

export interface InterviewSlot {
  id: string;
  recruiterName: string;
  recruiterTitle: string;
  date: string;
  time: string;
  meetingLink: string;
  confirmed: boolean;
}

export interface WorkerUser {
  id: string;
  email: string;
  fullName: string;
  phone: string;
  tradeTitle: string;
  profilePic?: string;
  status: ApplicationStatus;
  availableThisWeek: boolean;
  bankName: string;
  accountType: 'Checking' | 'Savings';
  routingNumber: string;
  accountNumberMasked: string;
  interviewSlot?: InterviewSlot;
}
