import React, { createContext, useContext, useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import {
  WorkerUser,
  ApplicationData,
  Assignment,
  JobOpening,
  DayHourEntry,
  HoursDispute,
  PayStub,
  DocumentRecord,
  FiledFormRecord,
  MessageThreadItem,
  JobOffer,
  CareerGoal,
  Referral,
  InterviewSlot,
  ApplicationStatus,
} from '../types';
import {
  INITIAL_USER,
  INITIAL_APPLICATION,
  INITIAL_ASSIGNMENT,
  INITIAL_JOB_OPENINGS,
  INITIAL_HOURS,
  INITIAL_PAY_STUBS,
  INITIAL_DOCUMENTS,
  INITIAL_FORMS,
  INITIAL_MESSAGES,
  INITIAL_OFFERS,
  INITIAL_GOALS,
  INITIAL_REFERRALS,
} from '../data/mockData';

interface CompletenessResult {
  percent: number;
  missingItems: string[];
  summaryText: string;
}

interface WorkforceContextType {
  user: WorkerUser | null;
  application: ApplicationData;
  assignment: Assignment | null;
  jobs: JobOpening[];
  hours: DayHourEntry[];
  disputes: HoursDispute[];
  payStubs: PayStub[];
  documents: DocumentRecord[];
  forms: FiledFormRecord[];
  messages: MessageThreadItem[];
  offers: JobOffer[];
  goals: CareerGoal[];
  referrals: Referral[];
  completeness: CompletenessResult;
  language: 'en' | 'es';
  setLanguage: (lang: 'en' | 'es') => void;

  // Actions
  login: (email: string, pass: string) => boolean;
  signup: (email: string, pass: string, name: string, phone: string) => void;
  logout: () => void;
  toggleAvailability: (enabled: boolean) => void;
  confirmForTomorrow: () => void;
  markOnMyWay: () => void;
  saveApplicationStep: (partial: Partial<ApplicationData>, nextStep?: number) => void;
  submitApplication: () => void;
  scheduleInterview: (slot: InterviewSlot) => void;
  applyToJob: (jobId: string) => void;
  flagHoursDispute: (dispute: Omit<HoursDispute, 'id' | 'submittedAt' | 'status'>) => void;
  fileForm: (type: FiledFormRecord['type'], details: Record<string, any>) => void;
  sendMessage: (content: string) => void;
  acceptOffer: (offerId: string) => void;
  declineOffer: (offerId: string) => void;
  addGoal: (goal: Omit<CareerGoal, 'id' | 'isCompleted'>) => void;
  toggleGoal: (goalId: string) => void;
  deleteGoal: (goalId: string) => void;
  addReferral: (referral: Omit<Referral, 'id' | 'referredDate' | 'status' | 'rewardAmount' | 'rewardPaid'>) => void;
  updatePayMethod: (bankName: string, accountType: 'Checking' | 'Savings', routing: string, account: string) => void;
  updateProfileInfo: (fullName: string, phone: string, email: string, tradeTitle: string, profilePic?: string) => void;
  uploadDocument: (doc: Omit<DocumentRecord, 'id' | 'uploadDate'>) => void;
  setUserStatus: (status: ApplicationStatus) => void;
  loadDemoAccount: (preset: 'marcus' | 'fresh' | 'applied') => void;
}

const WorkforceContext = createContext<WorkforceContextType | null>(null);

const STORAGE_KEY_PREFIX = 'employ_avenue_wf_';

function getStored<T>(key: string, defaultValue: T): T {
  try {
    const item = localStorage.getItem(STORAGE_KEY_PREFIX + key);
    return item ? JSON.parse(item) : defaultValue;
  } catch (e) {
    console.error('Error reading from localStorage', e);
    return defaultValue;
  }
}

function setStored<T>(key: string, value: T): void {
  try {
    localStorage.setItem(STORAGE_KEY_PREFIX + key, JSON.stringify(value));
  } catch (e) {
    console.error('Error writing to localStorage', e);
  }
}

export const WorkforceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<WorkerUser | null>(() => getStored('user', INITIAL_USER));
  const [application, setApplication] = useState<ApplicationData>(() =>
    getStored('app', INITIAL_APPLICATION)
  );
  const [assignment, setAssignment] = useState<Assignment | null>(() =>
    getStored('asg', INITIAL_ASSIGNMENT)
  );
  const [jobs, setJobs] = useState<JobOpening[]>(() => getStored('jobs', INITIAL_JOB_OPENINGS));
  const [hours, setHours] = useState<DayHourEntry[]>(() => getStored('hours', INITIAL_HOURS));
  const [disputes, setDisputes] = useState<HoursDispute[]>(() => getStored('disputes', []));
  const [payStubs, setPayStubs] = useState<PayStub[]>(() => getStored('stubs', INITIAL_PAY_STUBS));
  const [documents, setDocuments] = useState<DocumentRecord[]>(() =>
    getStored('docs', INITIAL_DOCUMENTS)
  );
  const [forms, setForms] = useState<FiledFormRecord[]>(() => getStored('forms', INITIAL_FORMS));
  const [messages, setMessages] = useState<MessageThreadItem[]>(() =>
    getStored('msgs', INITIAL_MESSAGES)
  );
  const [offers, setOffers] = useState<JobOffer[]>(() => getStored('offers', INITIAL_OFFERS));
  const [goals, setGoals] = useState<CareerGoal[]>(() => getStored('goals', INITIAL_GOALS));
  const [referrals, setReferrals] = useState<Referral[]>(() =>
    getStored('referrals', INITIAL_REFERRALS)
  );
  const [language, setLanguageState] = useState<'en' | 'es'>(() =>
    getStored<'en' | 'es'>('lang', 'en')
  );

  const setLanguage = (lang: 'en' | 'es') => {
    setLanguageState(lang);
    setStored('lang', lang);
  };

  // Sync to localStorage
  useEffect(() => {
    setStored('user', user);
  }, [user]);

  useEffect(() => {
    setStored('app', application);
  }, [application]);

  useEffect(() => {
    setStored('asg', assignment);
  }, [assignment]);

  useEffect(() => {
    setStored('jobs', jobs);
  }, [jobs]);

  useEffect(() => {
    setStored('hours', hours);
  }, [hours]);

  useEffect(() => {
    setStored('disputes', disputes);
  }, [disputes]);

  useEffect(() => {
    setStored('stubs', payStubs);
  }, [payStubs]);

  useEffect(() => {
    setStored('docs', documents);
  }, [documents]);

  useEffect(() => {
    setStored('forms', forms);
  }, [forms]);

  useEffect(() => {
    setStored('msgs', messages);
  }, [messages]);

  useEffect(() => {
    setStored('offers', offers);
  }, [offers]);

  useEffect(() => {
    setStored('goals', goals);
  }, [goals]);

  useEffect(() => {
    setStored('referrals', referrals);
  }, [referrals]);

  // Compute profile completeness
  const completeness = React.useMemo<CompletenessResult>(() => {
    const checks: { label: string; done: boolean; shortName: string }[] = [
      {
        label: 'Basic contact information & SMS consent',
        shortName: 'basic info',
        done: Boolean(application.firstName && application.phone && application.smsConsent),
      },
      {
        label: 'Resume uploaded & verified',
        shortName: 'resume upload',
        done: Boolean(application.resumeFileName && application.skills.length > 0),
      },
      {
        label: 'Job & shift interests selected',
        shortName: 'job interests',
        done: application.industryInterests.length > 0,
      },
      {
        label: 'Form W-4 signed',
        shortName: 'W-4 tax form',
        done: Boolean(application.w4Signature),
      },
      {
        label: 'Form I-9 section 1 signed',
        shortName: 'I-9 form',
        done: Boolean(application.i9Signature),
      },
      {
        label: 'ID document photos uploaded',
        shortName: 'photo ID upload',
        done: application.idDocumentUploaded,
      },
      {
        label: 'Background & drug test consents signed',
        shortName: 'consents signed',
        done: Boolean(
          application.consentBackgroundCheck &&
            application.consentDrugTest &&
            application.consentNoFees &&
            application.consentAgencyPolicies
        ),
      },
      {
        label: 'Application review & final submission',
        shortName: 'submit application',
        done: application.isSubmitted,
      },
      {
        label: 'Schedule video interview',
        shortName: 'schedule interview',
        done: Boolean(user?.interviewSlot?.confirmed),
      },
      {
        label: 'Direct deposit pay method set',
        shortName: 'set pay method',
        done: Boolean(user?.routingNumber && user?.accountNumberMasked),
      },
    ];

    const completedCount = checks.filter((c) => c.done).length;
    const percent = Math.round((completedCount / checks.length) * 100);
    const missing = checks.filter((c) => !c.done).map((c) => c.shortName);

    let summaryText = '';
    if (percent === 100) {
      summaryText = '100% — All profile requirements and verifications complete!';
    } else {
      const topMissing = missing.slice(0, 3).join(', ');
      summaryText = `${percent}% — left to do: ${topMissing}`;
    }

    return {
      percent,
      missingItems: missing,
      summaryText,
    };
  }, [application, user]);

  const login = (email: string, pass: string): boolean => {
    // Allows logging in with current user or demo credentials
    if (!user) {
      setUser({
        ...INITIAL_USER,
        email: email || INITIAL_USER.email,
      });
    }
    return true;
  };

  const signup = (email: string, pass: string, name: string, phone: string) => {
    const names = name.split(' ');
    const firstName = names[0] || 'Worker';
    const lastName = names.slice(1).join(' ') || 'Applicant';

    const newUser: WorkerUser = {
      id: `usr-${Date.now()}`,
      email,
      fullName: name,
      phone,
      tradeTitle: 'General Staffing Candidate',
      status: 'Applied',
      availableThisWeek: true,
      bankName: '',
      accountType: 'Checking',
      routingNumber: '',
      accountNumberMasked: '',
    };

    const newApp: ApplicationData = {
      firstName,
      lastName,
      preferredName: firstName,
      email,
      phone,
      address: '',
      city: '',
      state: '',
      zipCode: '',
      ssnLast4: '',
      dob: '',
      emergencyName: '',
      emergencyRelation: '',
      emergencyPhone: '',
      smsConsent: true,
      skills: [],
      workHistory: [],
      parsedFromResume: false,
      industryInterests: [],
      shiftPreferences: ['1st Shift (Day)'],
      minHourlyRate: 20,
      commuteRadiusMiles: 20,
      hasOwnTransportation: true,
      willingToTravel: false,
      w4FilingStatus: 'Single',
      w4MultipleJobs: false,
      w4DependentsClaimed: 0,
      w4ExtraWithholding: 0,
      w4Signature: '',
      w4SignDate: '',
      i9CitizenshipStatus: 'citizen',
      i9Signature: '',
      i9SignDate: '',
      idDocumentUploaded: false,
      secondaryDocumentUploaded: false,
      consentBackgroundCheck: false,
      backgroundSignature: '',
      backgroundSignDate: '',
      consentDrugTest: false,
      drugTestSignature: '',
      drugTestSignDate: '',
      consentNoFees: false,
      noFeesSignature: '',
      noFeesSignDate: '',
      consentAgencyPolicies: false,
      policiesSignature: '',
      policiesSignDate: '',
      currentStep: 1,
      isSubmitted: false,
    };

    setUser(newUser);
    setApplication(newApp);
    setAssignment(null);
  };

  const logout = () => {
    // Save state is retained in localStorage!
    setUser(null);
  };

  const toggleAvailability = (enabled: boolean) => {
    if (!user) return;
    setUser({ ...user, availableThisWeek: enabled });
  };

  const confirmForTomorrow = () => {
    if (!assignment) return;
    setAssignment({
      ...assignment,
      confirmedForTomorrow: true,
      confirmedTimestamp: 'Confirmed just now',
    });
    try {
      confetti({ particleCount: 40, spread: 60, origin: { y: 0.8 } });
    } catch (e) {
      // ignore
    }
  };

  const markOnMyWay = () => {
    if (!assignment) return;
    const nowTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setAssignment({
      ...assignment,
      onMyWay: true,
      onMyWayTimestamp: `En route reported at ${nowTime}`,
    });
    // Add record to filed forms as notification ticket to supervisor & agency
    const formRecord: FiledFormRecord = {
      id: `form-route-${Date.now()}`,
      type: 'Running-Late Ticket',
      filedAt: `Today at ${nowTime}`,
      status: 'Delivered to Supervisor & Agency',
      details: {
        note: `Worker clicked "I'm on my way" for shift starting at ${assignment.startTime}`,
        supervisor: assignment.supervisorName,
        site: assignment.siteAddress,
      },
      resolutionNotes: 'Agency dispatch logged worker en route status.',
    };
    setForms((prev) => [formRecord, ...prev]);
  };

  const saveApplicationStep = (partial: Partial<ApplicationData>, nextStep?: number) => {
    setApplication((prev) => {
      const updated = {
        ...prev,
        ...partial,
        currentStep: nextStep ?? prev.currentStep,
      };
      return updated;
    });
  };

  const submitApplication = () => {
    const timestamp = new Date().toLocaleString();
    setApplication((prev) => ({
      ...prev,
      isSubmitted: true,
      submittedAt: timestamp,
      currentStep: 6,
    }));
    if (user) {
      setUser((prev) => (prev ? { ...prev, status: 'Applied' } : null));
    }
    try {
      confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
    } catch (e) {
      // ignore
    }
  };

  const scheduleInterview = (slot: InterviewSlot) => {
    if (!user) return;
    setUser({
      ...user,
      interviewSlot: slot,
      status: user.status === 'Applied' || user.status === 'Screened' ? 'Interview' : user.status,
    });
    // Add interview system confirmation message
    const newMsg: MessageThreadItem = {
      id: `msg-${Date.now()}`,
      sender: 'system',
      senderName: 'Employ Avenue Scheduling Bot',
      content: `Video Interview confirmed with ${slot.recruiterName} for ${slot.date} at ${slot.time}. Meeting link added to your dashboard!`,
      timestamp: 'Just now',
    };
    setMessages((prev) => [...prev, newMsg]);
    try {
      confetti({ particleCount: 50, spread: 60, origin: { y: 0.7 } });
    } catch (e) {
      // ignore
    }
  };

  const applyToJob = (jobId: string) => {
    setJobs((prev) =>
      prev.map((job) =>
        job.id === jobId
          ? { ...job, applied: true, appliedDate: 'Just now' }
          : job
      )
    );
    try {
      confetti({ particleCount: 50, spread: 60, origin: { y: 0.7 } });
    } catch (e) {
      // ignore
    }
  };

  const flagHoursDispute = (disputeData: Omit<HoursDispute, 'id' | 'submittedAt' | 'status'>) => {
    const newDispute: HoursDispute = {
      ...disputeData,
      id: `disp-${Date.now()}`,
      submittedAt: new Date().toLocaleString(),
      status: 'Open',
    };
    setDisputes((prev) => [newDispute, ...prev]);

    // Mark corresponding entry in hours list
    setHours((prev) =>
      prev.map((h) => (h.id === disputeData.entryId ? { ...h, status: 'Disputed' } : h))
    );
  };

  const fileForm = (type: FiledFormRecord['type'], details: Record<string, any>) => {
    const newForm: FiledFormRecord = {
      id: `form-${Date.now()}`,
      type,
      filedAt: new Date().toLocaleString(),
      details,
      status: 'Delivered to Supervisor & Agency',
    };
    setForms((prev) => [newForm, ...prev]);

    // Add notification in chat thread
    const notifyMsg: MessageThreadItem = {
      id: `msg-form-${Date.now()}`,
      sender: 'system',
      senderName: 'Employ Avenue Dispatch Bot',
      content: `New ${type} filed. Delivered simultaneously to site supervisor and agency dispatch. Record #${newForm.id} saved to your vault.`,
      timestamp: 'Just now',
    };
    setMessages((prev) => [...prev, notifyMsg]);
  };

  const sendMessage = (content: string) => {
    if (!content.trim() || !user) return;
    const workerMsg: MessageThreadItem = {
      id: `msg-${Date.now()}`,
      sender: 'worker',
      senderName: user.fullName,
      content: content.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setMessages((prev) => [...prev, workerMsg]);

    // Simulate realistic agency dispatcher reply after 1.2s
    setTimeout(() => {
      const replies = [
        "Got it, Marcus! Dispatch has logged this. Let us know if you need any adjustments to your shift or PPE.",
        "Thanks for the update. Sarah and the floor supervisor have been notified. Have a safe shift!",
        "Message received. Your paperwork is active and our roster coordinator has noted this on your file.",
      ];
      const botMsg: MessageThreadItem = {
        id: `msg-reply-${Date.now()}`,
        sender: 'recruiter',
        senderName: 'Sarah Jenkins (Employ Avenue Senior Recruiter)',
        avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
        content: replies[Math.floor(Math.random() * replies.length)],
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, botMsg]);
    }, 1200);
  };

  const acceptOffer = (offerId: string) => {
    const offer = offers.find((o) => o.id === offerId);
    if (!offer) return;

    setOffers((prev) =>
      prev.map((o) => (o.id === offerId ? { ...o, status: 'Accepted' } : o))
    );

    // Update assignment card directly!
    if (offer.assignmentDetails) {
      const newAssignment: Assignment = {
        id: `asg-${Date.now()}`,
        jobTitle: offer.title,
        clientName: offer.clientName,
        siteAddress: offer.assignmentDetails.siteAddress || offer.location,
        dockOrGate: offer.assignmentDetails.dockOrGate || 'Main Dispatch Bay',
        startTime: offer.assignmentDetails.startTime || '06:30 AM',
        endTime: offer.assignmentDetails.endTime || '03:00 PM',
        startDate: offer.startDate,
        endDate: 'Ongoing assignment',
        hourlyRate: offer.hourlyRate,
        supervisorName: offer.supervisor,
        supervisorPhone: offer.assignmentDetails.supervisorPhone || '(555) 300-8900',
        supervisorEmail: offer.assignmentDetails.supervisorEmail || 'dispatch@employavenue.work',
        dressCode: offer.assignmentDetails.dressCode || [
          'Steel-toe boots',
          'High-vis safety vest',
          'Work gloves',
        ],
        requiredItems: offer.assignmentDetails.requiredItems || [
          'Government Photo ID',
          'Water container',
        ],
        parkingNotes: offer.assignmentDetails.parkingNotes || 'Employee Visitor Lot A',
        specialInstructions:
          offer.assignmentDetails.specialInstructions ||
          'Report to Main Gate 15 minutes prior to shift start.',
        confirmedForTomorrow: false,
        onMyWay: false,
        status: 'Active',
      };
      setAssignment(newAssignment);
    }

    try {
      confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
    } catch (e) {
      // ignore
    }
  };

  const declineOffer = (offerId: string) => {
    setOffers((prev) =>
      prev.map((o) => (o.id === offerId ? { ...o, status: 'Declined' } : o))
    );
  };

  const addGoal = (goalData: Omit<CareerGoal, 'id' | 'isCompleted'>) => {
    const newGoal: CareerGoal = {
      ...goalData,
      id: `goal-${Date.now()}`,
      isCompleted: false,
    };
    setGoals((prev) => [newGoal, ...prev]);
  };

  const toggleGoal = (goalId: string) => {
    setGoals((prev) =>
      prev.map((g) => (g.id === goalId ? { ...g, isCompleted: !g.isCompleted } : g))
    );
  };

  const deleteGoal = (goalId: string) => {
    setGoals((prev) => prev.filter((g) => g.id !== goalId));
  };

  const addReferral = (
    refData: Omit<Referral, 'id' | 'referredDate' | 'status' | 'rewardAmount' | 'rewardPaid'>
  ) => {
    const newRef: Referral = {
      ...refData,
      id: `ref-${Date.now()}`,
      referredDate: 'Today',
      status: 'Invited',
      rewardAmount: 100.0,
      rewardPaid: false,
    };
    setReferrals((prev) => [newRef, ...prev]);
    try {
      confetti({ particleCount: 50, spread: 60, origin: { y: 0.7 } });
    } catch (e) {
      // ignore
    }
  };

  const updatePayMethod = (
    bankName: string,
    accountType: 'Checking' | 'Savings',
    routing: string,
    account: string
  ) => {
    if (!user) return;
    const masked = '••••••••' + account.slice(-4);
    setUser({
      ...user,
      bankName,
      accountType,
      routingNumber: routing,
      accountNumberMasked: masked,
    });
  };

  const updateProfileInfo = (
    fullName: string,
    phone: string,
    email: string,
    tradeTitle: string,
    profilePic?: string
  ) => {
    if (!user) return;
    setUser({
      ...user,
      fullName,
      phone,
      email,
      tradeTitle,
      ...(profilePic !== undefined ? { profilePic } : {}),
    });
  };

  const uploadDocument = (doc: Omit<DocumentRecord, 'id' | 'uploadDate'>) => {
    const newDoc: DocumentRecord = {
      ...doc,
      id: `doc-${Date.now()}`,
      uploadDate: new Date().toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      }),
    };
    setDocuments((prev) => [newDoc, ...prev]);
  };

  const setUserStatus = (status: ApplicationStatus) => {
    if (!user) return;
    setUser({ ...user, status });
  };

  const loadDemoAccount = (preset: 'marcus' | 'fresh' | 'applied') => {
    if (preset === 'marcus') {
      setUser(INITIAL_USER);
      setApplication(INITIAL_APPLICATION);
      setAssignment(INITIAL_ASSIGNMENT);
      setOffers(INITIAL_OFFERS);
      setJobs(INITIAL_JOB_OPENINGS);
    } else if (preset === 'fresh') {
      const freshUser: WorkerUser = {
        id: 'usr-fresh-01',
        email: 'alex.taylor@example.com',
        fullName: 'Alex Taylor',
        phone: '(555) 449-1122',
        tradeTitle: 'New Candidate',
        status: 'Applied',
        availableThisWeek: true,
        bankName: '',
        accountType: 'Checking',
        routingNumber: '',
        accountNumberMasked: '',
      };
      setUser(freshUser);
      setApplication({
        firstName: 'Alex',
        lastName: 'Taylor',
        preferredName: 'Alex',
        email: 'alex.taylor@example.com',
        phone: '(555) 449-1122',
        address: '',
        city: '',
        state: '',
        zipCode: '',
        ssnLast4: '',
        dob: '',
        emergencyName: '',
        emergencyRelation: '',
        emergencyPhone: '',
        smsConsent: true,
        skills: [],
        workHistory: [],
        parsedFromResume: false,
        industryInterests: [],
        shiftPreferences: [],
        minHourlyRate: 20,
        commuteRadiusMiles: 25,
        hasOwnTransportation: true,
        willingToTravel: false,
        w4FilingStatus: 'Single',
        w4MultipleJobs: false,
        w4DependentsClaimed: 0,
        w4ExtraWithholding: 0,
        w4Signature: '',
        w4SignDate: '',
        i9CitizenshipStatus: 'citizen',
        i9Signature: '',
        i9SignDate: '',
        idDocumentUploaded: false,
        secondaryDocumentUploaded: false,
        consentBackgroundCheck: false,
        backgroundSignature: '',
        backgroundSignDate: '',
        consentDrugTest: false,
        drugTestSignature: '',
        drugTestSignDate: '',
        consentNoFees: false,
        noFeesSignature: '',
        noFeesSignDate: '',
        consentAgencyPolicies: false,
        policiesSignature: '',
        policiesSignDate: '',
        currentStep: 1,
        isSubmitted: false,
      });
      setAssignment(null);
    } else if (preset === 'applied') {
      setUser({
        ...INITIAL_USER,
        status: 'On the Roster',
      });
    }
  };

  return (
    <WorkforceContext.Provider
      value={{
        user,
        application,
        assignment,
        jobs,
        hours,
        disputes,
        payStubs,
        documents,
        forms,
        messages,
        offers,
        goals,
        referrals,
        completeness,
        login,
        signup,
        logout,
        toggleAvailability,
        confirmForTomorrow,
        markOnMyWay,
        saveApplicationStep,
        submitApplication,
        scheduleInterview,
        applyToJob,
        flagHoursDispute,
        fileForm,
        sendMessage,
        acceptOffer,
        declineOffer,
        addGoal,
        toggleGoal,
        deleteGoal,
        addReferral,
        updatePayMethod,
        updateProfileInfo,
        uploadDocument,
        setUserStatus,
        loadDemoAccount,
        language,
        setLanguage,
      }}
    >
      {children}
    </WorkforceContext.Provider>
  );
};

export const useWorkforce = () => {
  const context = useContext(WorkforceContext);
  if (!context) {
    throw new Error('useWorkforce must be used within a WorkforceProvider');
  }
  return context;
};
